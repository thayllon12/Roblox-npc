package com.devai.assistant.ui.screens

import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devai.assistant.overlay.OverlayService
import com.devai.assistant.service.AssistantForegroundService
import com.devai.assistant.storage.SettingsRepository
import com.devai.assistant.ui.components.GlassCard
import com.devai.assistant.ui.theme.Cyan
import com.devai.assistant.ui.theme.DeepBlack
import com.devai.assistant.ui.theme.ElectricBlue
import com.devai.assistant.ui.theme.TextMuted
import com.devai.assistant.ui.theme.TextPrimary
import com.devai.assistant.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: SettingsRepository,
    onBack: () -> Unit,
    onTestGemini: (String) -> Unit = {},
    onImportModel: (Uri) -> Unit = {},
    onDownloadModel: (String) -> Unit = {},
    modelStatus: String = "",
    modelBusy: Boolean = false
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val provider by settings.provider.collectAsState(initial = "qwen")
    val fallback by settings.fallbackEnabled.collectAsState(initial = true)
    val ttsEnabled by settings.ttsEnabled.collectAsState(initial = true)
    val wakeEnabled by settings.wakeWordEnabled.collectAsState(initial = true)
    val ttsRate by settings.ttsRate.collectAsState(initial = 1.0f)
    val wakeThreshold by settings.wakeThreshold.collectAsState(initial = 0.55f)
    val temperature by settings.temperature.collectAsState(initial = 0.7f)
    val geminiModel by settings.geminiModel.collectAsState(initial = "gemini-3.8-live")
    val overlayEnabled by settings.overlayEnabled.collectAsState(initial = false)
    val serviceEnabled by settings.serviceEnabled.collectAsState(initial = false)

    var apiKeyInput by remember { mutableStateOf(settings.getApiKey() ?: "") }
    var showKey by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }
    var modelUrl by remember { mutableStateOf("") }
    val modelPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let(onImportModel) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = TextPrimary)
            }
            Text("Configurações", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(16.dp))

        // ---- IA ----
        SectionTitle("Inteligência Artificial")
        GlassCard {
            Text("Provedor", color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProviderChip("Qwen Local", provider == "qwen") {
                    scope.launch { settings.setProvider("qwen") }
                }
                ProviderChip("Gemini Live", provider == "gemini") {
                    scope.launch { settings.setProvider("gemini") }
                }
            }
            Spacer(Modifier.height(12.dp))
            SettingSwitch("Fallback automático para Qwen", fallback) {
                scope.launch { settings.setFallbackEnabled(it) }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---- Modelo local ----
        SectionTitle("Modelo local (Qwen)")
        GlassCard {
            Text("Temperatura: ${"%.2f".format(temperature)}", color = TextSecondary, fontSize = 13.sp)
            Slider(
                value = temperature,
                onValueChange = { scope.launch { settings.setTemperature(it) } },
                valueRange = 0.1f..1.5f,
                colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = ElectricBlue)
            )
            Spacer(Modifier.height(14.dp))
            Text("Instalar modelo GGUF", color = TextPrimary, fontWeight = FontWeight.Medium)
            Text(
                "Baixe usando um link HTTPS direto ou importe um arquivo salvo no celular.",
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = modelUrl,
                onValueChange = { modelUrl = it },
                label = { Text("Link direto do modelo .gguf") },
                placeholder = { Text("https://.../modelo.gguf") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = TextMuted,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = TextSecondary,
                    cursorColor = Cyan
                )
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onDownloadModel(modelUrl.trim()) },
                    enabled = !modelBusy && modelUrl.startsWith("https://", ignoreCase = true),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) { Text(if (modelBusy) "Processando..." else "Baixar pela web") }
                Button(
                    onClick = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                    enabled = !modelBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2A3A))
                ) { Text("Importar do celular") }
            }
            if (modelStatus.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(modelStatus, color = Cyan, fontSize = 12.sp)
            }
            Text(
                "Use somente links diretos para arquivos .gguf. O download pode consumir bastante internet e armazenamento.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---- Gemini ----
        SectionTitle("Gemini Live")
        GlassCard {
            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("API Key") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(
                            if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = TextMuted,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = TextSecondary,
                    cursorColor = Cyan
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        settings.saveApiKey(apiKeyInput)
                        statusMsg = "API Key salva com segurança"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) { Text("Salvar") }
                Button(
                    onClick = {
                        settings.clearApiKey()
                        apiKeyInput = ""
                        statusMsg = "API Key removida"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A1A1A))
                ) { Text("Remover") }
                Button(
                    onClick = {
                        if (apiKeyInput.isNotBlank()) {
                            settings.saveApiKey(apiKeyInput)
                            onTestGemini(apiKeyInput)
                            statusMsg = "Testando conexão…"
                        } else statusMsg = "Informe a API Key"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2A3A))
                ) { Text("Testar") }
            }
            if (statusMsg.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(statusMsg, color = Cyan, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text("Modelo: $geminiModel", color = TextMuted, fontSize = 12.sp)
        }

        Spacer(Modifier.height(12.dp))

        // ---- Voz ----
        SectionTitle("Voz")
        GlassCard {
            SettingSwitch("Resposta falada (TTS)", ttsEnabled) {
                scope.launch { settings.setTtsEnabled(it) }
            }
            SettingSwitch("Wake word \"Hey Dev AI\"", wakeEnabled) {
                scope.launch { settings.setWakeWordEnabled(it) }
            }
            Spacer(Modifier.height(8.dp))
            Text("Velocidade TTS: ${"%.1f".format(ttsRate)}x", color = TextSecondary, fontSize = 13.sp)
            Slider(
                value = ttsRate,
                onValueChange = { scope.launch { settings.setTtsRate(it) } },
                valueRange = 0.5f..2.0f,
                colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = ElectricBlue)
            )
            Text(
                "Frases de ativação: “Hey Dev” e “Ok Dev”. O reconhecimento usa o Vosk PT-BR instalado no próprio aplicativo.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---- Sistema ----
        SectionTitle("Sistema")
        GlassCard {
            SettingSwitch("Serviço em segundo plano", serviceEnabled) {
                scope.launch {
                    settings.setServiceEnabled(it)
                    if (it) AssistantForegroundService.start(context)
                    else AssistantForegroundService.stop(context)
                }
            }
            SettingSwitch("Orb flutuante", overlayEnabled) {
                scope.launch {
                    settings.setOverlayEnabled(it)
                    if (it) {
                        if (Settings.canDrawOverlays(context)) {
                            OverlayService.start(context)
                        } else {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    } else {
                        OverlayService.stop(context)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---- Sobre ----
        SectionTitle("Sobre")
        GlassCard {
            Text("DEV AI ASSISTANT", color = TextPrimary, fontWeight = FontWeight.Medium)
            Text("Versão 1.1.0", color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Qwen local · Vosk PT-BR · ativação por voz · Gemini Live · Overlay",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        title.uppercase(),
        color = Cyan,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ProviderChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = ElectricBlue.copy(alpha = 0.35f),
            selectedLabelColor = Cyan,
            containerColor = Color(0x22FFFFFF),
            labelColor = TextSecondary
        ),
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 14.sp)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Cyan,
                checkedTrackColor = ElectricBlue.copy(alpha = 0.5f)
            )
        )
    }
}
