package com.devai.assistant.voice

import android.content.Context
import android.util.Log
import com.devai.assistant.localmodel.LocalLlmEngine
import com.devai.assistant.wakeword.WakeWordDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Orquestra: wake word (opcional) → escuta (Vosk) → LLM → TTS
 */
class VoiceAssistantController(
    context: Context,
    private val llmEngine: LocalLlmEngine
) {
    enum class Phase {
        IDLE,
        WAITING_WAKE,   // Escutando "Hey Dev AI"
        LISTENING,      // Vosk ativo
        RECOGNIZING,
        THINKING,
        SPEAKING,
        ERROR
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val recognizer = VoskSpeechRecognizer(context)
    val tts = TtsEngine(context)
    val wakeWord = WakeWordDetector(context)

    private val _phase = MutableStateFlow(Phase.IDLE)
    val phase: StateFlow<Phase> = _phase.asStateFlow()

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()

    private val _reply = MutableStateFlow("")
    val reply: StateFlow<String> = _reply.asStateFlow()

    private var ttsEnabled = true
    private var wakeWordEnabled = true

    init {
        scope.launch {
            if (recognizer.isModelInstalled()) {
                recognizer.loadModel()
            }
            if (wakeWord.hasClassifierModel()) {
                wakeWord.loadModel()
            }
        }
    }

    fun setTtsEnabled(enabled: Boolean) {
        ttsEnabled = enabled
        tts.setEnabled(enabled)
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        wakeWordEnabled = enabled
        if (!enabled) {
            wakeWord.stop()
            recognizer.stopListening()
            if (_phase.value == Phase.WAITING_WAKE) _phase.value = Phase.IDLE
        }
    }

    /**
     * Inicia escuta do wake word (se modelo disponível).
     * Ao detectar, inicia automaticamente o Vosk.
     */
    fun startWakeWordListening() {
        if (!wakeWordEnabled) return
        if (recognizer.state.value != VoskSpeechRecognizer.State.READY) {
            scope.launch {
                if (recognizer.isModelInstalled() && recognizer.loadModel()) {
                    beginVoskWakeLoop()
                } else {
                    _phase.value = Phase.ERROR
                }
            }
            return
        }
        beginVoskWakeLoop()
    }

    /**
     * Detecção de "Hey Dev" / "Ok Dev" usando o próprio reconhecimento Vosk.
     * Não depende de um classificador ONNX que não vinha no pacote.
     */
    private fun beginVoskWakeLoop() {
        if (!wakeWordEnabled || recognizer.state.value != VoskSpeechRecognizer.State.READY) return
        _phase.value = Phase.WAITING_WAKE
        recognizer.startListening { spoken ->
            val normalized = java.text.Normalizer.normalize(
                spoken.lowercase(java.util.Locale("pt", "BR")),
                java.text.Normalizer.Form.NFD
            ).replace(Regex("\\p{M}+"), "")
                .replace(Regex("[^a-z0-9 ]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()

            val wakeDetected = listOf("hey dev", "ei dev", "ok dev", "okay dev", "oi dev")
                .any { normalized.contains(it) }

            recognizer.stopListening()
            if (wakeDetected) {
                Log.i(TAG, "Wake phrase detected: $spoken")
                startListening()
            } else {
                scope.launch {
                    kotlinx.coroutines.delay(250)
                    beginVoskWakeLoop()
                }
            }
        }
    }

    fun startListening() {
        if (_phase.value == Phase.LISTENING || _phase.value == Phase.THINKING) return
        if (recognizer.state.value != VoskSpeechRecognizer.State.READY) {
            _phase.value = Phase.ERROR
            return
        }
        _transcript.value = ""
        _reply.value = ""
        _phase.value = Phase.LISTENING
        recognizer.startListening { finalText -> onSpeechFinal(finalText) }
    }

    fun stopListening() {
        recognizer.stopListening()
        if (_phase.value == Phase.LISTENING) {
            resumeWakeOrIdle()
        }
    }

    private fun onSpeechFinal(text: String) {
        recognizer.stopListening()
        _transcript.value = text
        _phase.value = Phase.THINKING

        scope.launch {
            val prompt = buildPrompt(text)
            val answer = llmEngine.generate(prompt, temperature = 0.7f, maxTokens = 256)
            if (answer.isNullOrBlank()) {
                _reply.value = llmEngine.lastError.value ?: "Não consegui gerar uma resposta."
                resumeWakeOrIdle()
                return@launch
            }
            _reply.value = answer
            if (ttsEnabled) {
                _phase.value = Phase.SPEAKING
                tts.speak(answer) { resumeWakeOrIdle() }
            } else {
                resumeWakeOrIdle()
            }
        }
    }

    private fun resumeWakeOrIdle() {
        if (wakeWordEnabled && recognizer.state.value == VoskSpeechRecognizer.State.READY) {
            beginVoskWakeLoop()
        } else {
            _phase.value = Phase.IDLE
        }
    }

    private fun buildPrompt(userText: String): String {
        return """Você é o DEV AI ASSISTANT, um assistente pessoal inteligente e prestativo.
Responda em português brasileiro de forma clara e concisa.

Usuário: $userText
Assistente:"""
    }

    fun stopSpeaking() {
        tts.stop()
        if (_phase.value == Phase.SPEAKING) resumeWakeOrIdle()
    }

    fun cancelAll() {
        stopListening()
        stopSpeaking()
        wakeWord.stop()
        llmEngine.stopGeneration()
        _phase.value = Phase.IDLE
    }

    fun release() {
        cancelAll()
        recognizer.release()
        tts.release()
        wakeWord.release()
        scope.cancel()
    }

    companion object {
        private const val TAG = "VoiceAssistantController"
    }
}
