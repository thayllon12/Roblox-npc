package com.devai.assistant.ui.screens

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.devai.assistant.localmodel.LocalLlmEngine
import com.devai.assistant.localmodel.ModelInfo
import com.devai.assistant.ui.components.OrbState
import com.devai.assistant.voice.VoiceAssistantController
import com.devai.assistant.voice.VoskSpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = LocalLlmEngine(application)
    private val voice = VoiceAssistantController(application, engine)

    private val _orbState = MutableStateFlow(OrbState.WAITING)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _statusMessage = MutableStateFlow("Aguardando \"Hey Dev AI\"")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _importedModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    val importedModels: StateFlow<List<ModelInfo>> = _importedModels.asStateFlow()

    private val _generationResult = MutableStateFlow<String?>(null)
    val generationResult: StateFlow<String?> = _generationResult.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _voskModelReady = MutableStateFlow(false)
    val voskModelReady: StateFlow<Boolean> = _voskModelReady.asStateFlow()

    val engineState = engine.state
    val currentModel = engine.currentModel
    val lastError = engine.lastError

    val voicePhase = voice.phase
    val transcript = voice.transcript
    val reply = voice.reply
    val partialText = voice.recognizer.partialText
    val voskState = voice.recognizer.state
    val voskError = voice.recognizer.lastError
    val wakeWordState = voice.wakeWord.state
    val wakeWordScore = voice.wakeWord.lastScore
    val wakeWordModel = voice.wakeWord.modelName

    init {
        viewModelScope.launch {
            engine.initialize()
            refreshModelList()
            _voskModelReady.value = voice.recognizer.isModelInstalled()
            if (_voskModelReady.value) {
                voice.recognizer.loadModel()
                _statusMessage.value = "Vosk PT-BR pronto"
            } else {
                _isBusy.value = true
                _statusMessage.value = "Preparando reconhecimento de voz (download inicial)…"
                val installed = voice.recognizer.downloadAndInstallModel { downloaded, total ->
                    val mb = downloaded / (1024 * 1024)
                    val totalMb = if (total > 0) total / (1024 * 1024) else 31
                    _statusMessage.value = "Baixando Vosk: ${mb} / ${totalMb} MB"
                }
                _voskModelReady.value = installed
                _statusMessage.value = if (installed) "Vosk PT-BR instalado e pronto"
                    else (voice.recognizer.lastError.value ?: "Não foi possível baixar o Vosk")
                _isBusy.value = false
            }
        }

        viewModelScope.launch {
            combine(
                engine.state,
                engine.currentModel,
                voice.phase,
                voice.recognizer.state
            ) { llmState, model, vPhase, voskSt ->
                arrayOf(llmState, model, vPhase, voskSt)
            }.collect { arr ->
                val llmState = arr[0] as LocalLlmEngine.State
                val model = arr[1] as ModelInfo?
                val vPhase = arr[2] as VoiceAssistantController.Phase
                val voskSt = arr[3] as VoskSpeechRecognizer.State

                when {
                    vPhase == VoiceAssistantController.Phase.LISTENING -> {
                        _orbState.value = OrbState.LISTENING
                        _statusMessage.value = "Escutando…"
                    }
                    vPhase == VoiceAssistantController.Phase.THINKING -> {
                        _orbState.value = OrbState.THINKING
                        _statusMessage.value = "Pensando…"
                    }
                    vPhase == VoiceAssistantController.Phase.SPEAKING -> {
                        _orbState.value = OrbState.RESPONDING
                        _statusMessage.value = "Respondendo…"
                    }
                    llmState == LocalLlmEngine.State.LOADING_MODEL -> {
                        _orbState.value = OrbState.PROCESSING
                        _statusMessage.value = "Carregando modelo…"
                    }
                    llmState == LocalLlmEngine.State.GENERATING -> {
                        _orbState.value = OrbState.THINKING
                        _statusMessage.value = "Pensando…"
                    }
                    llmState == LocalLlmEngine.State.ERROR -> {
                        _orbState.value = OrbState.ERROR
                        _statusMessage.value = engine.lastError.value ?: "Erro"
                    }
                    voskSt == VoskSpeechRecognizer.State.MODEL_MISSING -> {
                        _orbState.value = OrbState.WAITING
                        _statusMessage.value = "Importe o modelo Vosk PT-BR"
                    }
                    llmState == LocalLlmEngine.State.MODEL_LOADED -> {
                        _orbState.value = OrbState.WAITING
                        _statusMessage.value = "Pronto — toque em Escutar"
                    }
                    llmState == LocalLlmEngine.State.READY -> {
                        _orbState.value = OrbState.WAITING
                        _statusMessage.value = if (model == null)
                            "Importe um GGUF e o modelo Vosk"
                        else
                            "Modelo LLM pronto"
                    }
                    else -> {
                        _orbState.value = OrbState.INACTIVE
                        _statusMessage.value = "Inicializando…"
                    }
                }
            }
        }
    }

    fun refreshModelList() {
        _importedModels.value = engine.listImportedModels()
    }

    fun importFromUri(uri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val context = getApplication<Application>()
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "model.gguf"
                val temp = File(context.cacheDir, "import_${System.currentTimeMillis()}.gguf")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temp).use { output -> input.copyTo(output) }
                } ?: run {
                    _statusMessage.value = "Não foi possível ler o arquivo"
                    return@launch
                }
                val info = engine.importGguf(temp, displayName = name)
                temp.delete()
                if (info != null) {
                    refreshModelList()
                    _statusMessage.value = "Importado: ${info.displayName} (${info.formattedSize()})"
                    loadModel(info)
                } else {
                    _statusMessage.value = engine.lastError.value ?: "Falha na importação"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Erro: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun downloadModelFromUrl(rawUrl: String) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val parsed = Uri.parse(rawUrl.trim())
                require(parsed.scheme.equals("https", ignoreCase = true)) {
                    "Use um link HTTPS direto para o arquivo GGUF."
                }
                require(parsed.lastPathSegment?.endsWith(".gguf", ignoreCase = true) == true) {
                    "O link precisa apontar diretamente para um arquivo .gguf."
                }

                val context = getApplication<Application>()
                val temp = File(context.cacheDir, "download_${System.currentTimeMillis()}.gguf")
                withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val connection = URL(rawUrl.trim()).openConnection().apply {
                        connectTimeout = 20000
                        readTimeout = 60000
                        useCaches = false
                    }
                    connection.getInputStream().use { input ->
                        FileOutputStream(temp).use { output ->
                            val buffer = ByteArray(1024 * 1024)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                total += count
                                require(total <= 8L * 1024L * 1024L * 1024L) {
                                    "O modelo excede o limite de 8 GB."
                                }
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                }

                val info = engine.importGguf(temp, displayName = parsed.lastPathSegment)
                temp.delete()
                if (info != null) {
                    refreshModelList()
                    _statusMessage.value = "Modelo baixado: ${info.displayName}"
                    loadModel(info)
                } else {
                    _statusMessage.value = engine.lastError.value ?: "Arquivo GGUF inválido."
                }
            } catch (e: Exception) {
                _statusMessage.value = "Falha no download: ${e.message ?: "erro desconhecido"}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun importVoskZip(uri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val context = getApplication<Application>()
                val temp = File(context.cacheDir, "vosk_import.zip")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temp).use { output -> input.copyTo(output) }
                } ?: run {
                    _statusMessage.value = "Não foi possível ler o ZIP"
                    return@launch
                }
                val ok = voice.recognizer.installModelFromZip(temp)
                temp.delete()
                _voskModelReady.value = ok
                _statusMessage.value = if (ok) "Modelo Vosk PT-BR instalado"
                else (voice.recognizer.lastError.value ?: "Falha ao instalar Vosk")
            } catch (e: Exception) {
                _statusMessage.value = "Erro Vosk: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun loadModel(info: ModelInfo) {
        viewModelScope.launch {
            _isBusy.value = true
            engine.load(info)
            _isBusy.value = false
        }
    }

    fun unloadModel() {
        viewModelScope.launch { engine.unload() }
    }

    fun removeModel(info: ModelInfo) {
        viewModelScope.launch {
            engine.removeModel(info)
            refreshModelList()
        }
    }

    fun testGenerate(prompt: String = "Olá, você é o DEV AI ASSISTANT. Responda em português de forma curta.") {
        viewModelScope.launch {
            _generationResult.value = null
            val result = engine.generate(prompt, maxTokens = 128)
            _generationResult.value = result ?: (engine.lastError.value ?: "Sem resposta")
        }
    }

    fun stopGeneration() {
        engine.stopGeneration()
        voice.stopSpeaking()
    }

    fun startListening() {
        voice.startListening()
    }

    fun stopListening() {
        voice.stopListening()
    }

    fun cancelVoice() {
        voice.cancelAll()
    }

    fun setTtsEnabled(enabled: Boolean) {
        voice.setTtsEnabled(enabled)
    }

    fun startWakeWord() {
        voice.startWakeWordListening()
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        voice.setWakeWordEnabled(enabled)
    }

    fun importWakeWordOnnx(uri: android.net.Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val context = getApplication<Application>()
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val ok = voice.wakeWord.importClassifierFromStream(input)
                    _statusMessage.value = if (ok) "Modelo wake word importado" else (voice.wakeWord.lastError.value ?: "Falha")
                }
            } catch (e: Exception) {
                _statusMessage.value = "Erro wake word: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }
}
