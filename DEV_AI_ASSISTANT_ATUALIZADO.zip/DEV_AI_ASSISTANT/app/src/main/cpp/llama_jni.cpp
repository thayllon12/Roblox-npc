#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <cstring>

#define LOG_TAG "DevAiLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#if USE_REAL_LLAMA

#include "llama.h"

// Estado global protegido por mutex
static std::mutex g_mutex;
static llama_model*   g_model   = nullptr;
static llama_context* g_ctx     = nullptr;
static std::atomic<bool> g_stop_requested{false};
static std::string g_model_path;
static int g_n_ctx = 2048;

static void free_resources_locked() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    g_model_path.clear();
}

#endif // USE_REAL_LLAMA

extern "C" {

// ---------------------------------------------------------------------------
// initBackend
// ---------------------------------------------------------------------------
JNIEXPORT jboolean JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_initBackend(
        JNIEnv* env, jclass, jstring nativeLibDir) {

#if USE_REAL_LLAMA
    const char* path = env->GetStringUTFChars(nativeLibDir, nullptr);
    LOGI("initBackend: loading backends from %s", path ? path : "(null)");

    // Carrega backends dinâmicos (ggml-cpu-*.so) se GGML_BACKEND_DL estiver ativo
    if (path && path[0] != '\0') {
        ggml_backend_load_all_from_path(path);
    }

    llama_backend_init();
    env->ReleaseStringUTFChars(nativeLibDir, path);
    LOGI("llama backend initialized");
    return JNI_TRUE;
#else
    LOGE("initBackend: build sem llama.cpp não é suportado");
    (void)env; (void)nativeLibDir;
    return JNI_FALSE;
#endif
}

// ---------------------------------------------------------------------------
// loadModel
// ---------------------------------------------------------------------------
JNIEXPORT jboolean JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_loadModel(
        JNIEnv* env, jclass,
        jstring modelPath,
        jint nCtx,
        jint nGpuLayers) {

#if USE_REAL_LLAMA
    const char* path = env->GetStringUTFChars(modelPath, nullptr);
    if (!path) {
        LOGE("loadModel: null path");
        return JNI_FALSE;
    }

    std::lock_guard<std::mutex> lock(g_mutex);
    free_resources_locked();

    LOGI("loadModel: %s  n_ctx=%d  n_gpu_layers=%d", path, nCtx, nGpuLayers);

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = nGpuLayers; // 0 = CPU only (mais estável em mobile)

    g_model = llama_model_load_from_file(path, mparams);
    if (!g_model) {
        LOGE("Failed to load model from %s", path);
        env->ReleaseStringUTFChars(modelPath, path);
        return JNI_FALSE;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx   = nCtx > 0 ? nCtx : 2048;
    cparams.n_batch = 512;
    // Em dispositivos móveis preferimos menos threads para não aquecer demais
    cparams.n_threads = 4;
    cparams.n_threads_batch = 4;

    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("Failed to create context");
        llama_model_free(g_model);
        g_model = nullptr;
        env->ReleaseStringUTFChars(modelPath, path);
        return JNI_FALSE;
    }

    g_model_path = path;
    g_n_ctx = cparams.n_ctx;
    g_stop_requested = false;

    env->ReleaseStringUTFChars(modelPath, path);
    LOGI("Model loaded successfully. ctx=%d", g_n_ctx);
    return JNI_TRUE;
#else
    LOGE("loadModel: backend llama.cpp indisponível");
    (void)env; (void)modelPath; (void)nCtx; (void)nGpuLayers;
    return JNI_FALSE;
#endif
}

// ---------------------------------------------------------------------------
// isModelLoaded
// ---------------------------------------------------------------------------
JNIEXPORT jboolean JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_isModelLoaded(JNIEnv*, jclass) {
#if USE_REAL_LLAMA
    std::lock_guard<std::mutex> lock(g_mutex);
    return (g_model != nullptr && g_ctx != nullptr) ? JNI_TRUE : JNI_FALSE;
#else
    return JNI_FALSE;
#endif
}

// ---------------------------------------------------------------------------
// unloadModel
// ---------------------------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_unloadModel(JNIEnv*, jclass) {
#if USE_REAL_LLAMA
    std::lock_guard<std::mutex> lock(g_mutex);
    LOGI("unloadModel");
    free_resources_locked();
#else
    LOGE("unloadModel: backend indisponível");
#endif
}

// ---------------------------------------------------------------------------
// requestStop
// ---------------------------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_requestStop(JNIEnv*, jclass) {
#if USE_REAL_LLAMA
    g_stop_requested = true;
    LOGI("stop requested");
#else
    LOGE("requestStop: backend indisponível");
#endif
}

// ---------------------------------------------------------------------------
// generate — geração síncrona (chamar de background thread)
// Retorna o texto gerado ou null em caso de erro.
// ---------------------------------------------------------------------------
JNIEXPORT jstring JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_generate(
        JNIEnv* env, jclass,
        jstring promptJ,
        jfloat temperature,
        jint maxTokens,
        jfloat topP) {

#if USE_REAL_LLAMA
    const char* prompt = env->GetStringUTFChars(promptJ, nullptr);
    if (!prompt) return nullptr;

    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) {
        LOGE("generate: model not loaded");
        env->ReleaseStringUTFChars(promptJ, prompt);
        return nullptr;
    }

    g_stop_requested = false;

    // Tokeniza
    const int n_prompt_tokens = -llama_tokenize(
        llama_model_get_vocab(g_model),
        prompt, strlen(prompt),
        nullptr, 0, true, true);

    if (n_prompt_tokens <= 0) {
        LOGE("tokenize failed");
        env->ReleaseStringUTFChars(promptJ, prompt);
        return nullptr;
    }

    std::vector<llama_token> tokens(n_prompt_tokens);
    llama_tokenize(
        llama_model_get_vocab(g_model),
        prompt, strlen(prompt),
        tokens.data(), tokens.size(),
        true, true);

    env->ReleaseStringUTFChars(promptJ, prompt);

    // Limpa o KV cache
    llama_kv_cache_clear(g_ctx);

    // Avalia o prompt
    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    if (llama_decode(g_ctx, batch) != 0) {
        LOGE("llama_decode (prompt) failed");
        return nullptr;
    }

    // Sampler simples
    auto sparams = llama_sampler_chain_default_params();
    llama_sampler* smpl = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(topP, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string result;
    result.reserve(maxTokens * 4);

    for (int i = 0; i < maxTokens; ++i) {
        if (g_stop_requested) {
            LOGI("generation stopped by user");
            break;
        }

        llama_token new_token = llama_sampler_sample(smpl, g_ctx, -1);

        if (llama_vocab_is_eog(llama_model_get_vocab(g_model), new_token)) {
            break;
        }

        char buf[256];
        int n = llama_token_to_piece(
            llama_model_get_vocab(g_model),
            new_token, buf, sizeof(buf), 0, true);
        if (n > 0) {
            result.append(buf, n);
        }

        // Decode o novo token
        batch = llama_batch_get_one(&new_token, 1);
        if (llama_decode(g_ctx, batch) != 0) {
            LOGE("llama_decode (token) failed");
            break;
        }
    }

    llama_sampler_free(smpl);

    LOGI("generated %zu chars", result.size());
    return env->NewStringUTF(result.c_str());
#else
    LOGE("generate: backend llama.cpp indisponível");
    (void)env; (void)promptJ; (void)temperature; (void)maxTokens; (void)topP;
    return nullptr;
#endif
}

// ---------------------------------------------------------------------------
// getModelInfo — retorna string "name|params|quant" ou null
// ---------------------------------------------------------------------------
JNIEXPORT jstring JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_getModelInfo(JNIEnv* env, jclass) {
#if USE_REAL_LLAMA
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return nullptr;

    // Informações básicas (a API de metadados pode variar; usamos path + ctx)
    std::string info = g_model_path + "|ctx=" + std::to_string(g_n_ctx);
    return env->NewStringUTF(info.c_str());
#else
    return nullptr;
#endif
}

// ---------------------------------------------------------------------------
// freeBackend
// ---------------------------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_devai_assistant_localmodel_LlamaNative_freeBackend(JNIEnv*, jclass) {
#if USE_REAL_LLAMA
    std::lock_guard<std::mutex> lock(g_mutex);
    free_resources_locked();
    llama_backend_free();
    LOGI("backend freed");
#else
    LOGE("freeBackend: backend indisponível");
#endif
}

} // extern "C"
