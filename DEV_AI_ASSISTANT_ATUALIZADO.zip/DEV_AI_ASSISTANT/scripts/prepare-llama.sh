#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLAMA_DIR="$ROOT_DIR/app/src/main/cpp/llama.cpp"
LLAMA_TAG="${LLAMA_CPP_TAG:-b4510}"

if [[ -f "$LLAMA_DIR/CMakeLists.txt" ]]; then
  echo "llama.cpp já está disponível em $LLAMA_DIR"
  exit 0
fi

mkdir -p "$(dirname "$LLAMA_DIR")"
git clone --depth 1 --branch "$LLAMA_TAG" https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"
