# DEV AI ASSISTANT

Assistente pessoal de inteligência artificial por voz para Android.

**Versão:** 1.0.0-phase-g  
**Plataforma:** Android 8.0+ (API 26), otimizado para arm64-v8a (POCO X7 Pro / Dimensity)

---

## O que está implementado

| Módulo | Status | Observações |
|--------|--------|-------------|
| Interface premium (Compose + Orb animada) | ✅ | 8 estados, glassmorphism, tema azul |
| IA local (llama.cpp + GGUF) | ✅ (infra) | JNI + engine; requer submodule llama.cpp |
| Importação / gerenciamento de modelos GGUF | ✅ | SAF + validação |
| Vosk (PT-BR offline STT) | ✅ (infra) | Modelo baixado pelo usuário |
| TTS nativo Android | ✅ | Velocidade configurável |
| Wake word "Hey Dev AI" | ✅ (infra) | ONNX Runtime; modelo precisa ser treinado |
| Gemini Live (WebSocket) | ✅ (cliente) | gemini-3.8-live, áudio+texto, API Key própria |
| Fallback Qwen ↔ Gemini | ✅ | Configurável |
| Settings + DataStore | ✅ | Preferências persistentes |
| API Key protegida | ✅ | EncryptedSharedPreferences + Keystore |
| Foreground Service (microfone) | ✅ | Notificação persistente |
| Overlay / Orb flutuante | ✅ | Arrastável, SYSTEM_ALERT_WINDOW |
| GitHub Actions (build APK) | ✅ | `.github/workflows/build.yml` |

---

## Requisitos externos (não incluídos no ZIP)

1. **llama.cpp** (submodule)  
   ```bash
   git submodule add https://github.com/ggml-org/llama.cpp.git app/src/main/cpp/llama.cpp
   git submodule update --init --recursive
   ```
   Sem ele o app roda em modo STUB (UI + resposta de demonstração).

2. **Modelo GGUF recomendado**  
   [Qwen3-0.6B-Q8_0.gguf](https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/blob/main/Qwen3-0.6B-Q8_0.gguf) (~639 MB, Apache-2.0)  
   Importe pelo seletor de arquivos dentro do app.

3. **Modelo Vosk PT-BR**  
   Baixe de https://alphacephei.com/vosk/models (ex.: `vosk-model-small-pt-0.3`)  
   Coloque em `files/vosk-model/` ou use o fluxo de importação do app.

4. **Wake word personalizado**  
   Treine com openWakeWord (ver `docs/PHASE_D_WAKEWORD.md`) e importe o `.onnx`.

5. **API Key Gemini**  
   Gere em https://aistudio.google.com/app/apikey  
   Cole em Configurações → Gemini Live. Nunca é embutida no APK.

---

## Como abrir e compilar

### Android Studio
1. Extraia o ZIP
2. (Opcional) Adicione o submodule llama.cpp
3. Abra a pasta `DEV_AI_ASSISTANT` no Android Studio (Ladybug / 2024.2+)
4. Sync Gradle (JDK 17, SDK 35, NDK + CMake)
5. Execute em dispositivo API 26+ (preferencialmente arm64)

### GitHub Actions
1. Faça push do projeto para um repositório GitHub
2. O workflow `.github/workflows/build.yml` gera o APK debug
3. Baixe o artifact `DEV-AI-ASSISTANT-debug`

### Gradle local
```bash
# Gere o wrapper se necessário
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

---

## Fluxo de uso

1. Conceda microfone e (opcional) notificações / overlay
2. Importe um GGUF e/ou configure a API Key do Gemini
3. Importe modelos Vosk e wake word se desejar ativação por voz
4. Toque na orb ou diga **“Hey Dev AI”** (quando o modelo de wake word estiver instalado)
5. Fale o comando → o assistente processa (Qwen offline ou Gemini Live) → responde por voz e texto

---

## Arquitetura de pacotes

```
com.devai.assistant
├── localmodel/     ← llama.cpp JNI + engine GGUF
├── voice/          ← Vosk + TTS + VoiceAssistantController
├── wakeword/       ← ONNX openWakeWord-style
├── gemini/         ← GeminiLiveClient (WebSocket)
├── service/        ← Foreground Service
├── overlay/        ← Orb flutuante
├── storage/        ← DataStore + EncryptedSharedPreferences
├── ui/             ← Compose (Main + Settings + Orb)
└── cpp/            ← CMake + llama_jni.cpp
```

---

## Limitações conhecidas

- O modelo de wake word **“Hey Dev AI”** não está pré-treinado no pacote (treinamento necessário).
- llama.cpp precisa ser adicionado como submodule para inferência real.
- Modelos Vosk e GGUF não são embutidos (tamanho proibitivo).
- Gemini Live em dispositivos exige internet e API Key válida; o áudio bidirecional completo depende de permissões e do estado da sessão.
- Overlay e Foreground Service respeitam as restrições do Android 14+ e dos fabricantes (HyperOS pode limitar background).
- Não há assinatura de release no CI (keystore nunca é commitada).

---

## Licenças (principais)

| Componente | Licença |
|------------|---------|
| Código do app | A definir pelo autor |
| llama.cpp | MIT |
| Vosk | Apache 2.0 |
| ONNX Runtime | MIT |
| Qwen models | Apache 2.0 (verificar card) |
| Jetpack / AndroidX | Apache 2.0 |
| OkHttp | Apache 2.0 |

---

## Documentação adicional

- `docs/PHASE_B_LLAMA.md` — integração llama.cpp
- `docs/PHASE_C_VOICE.md` — Vosk + TTS
- `docs/PHASE_D_WAKEWORD.md` — treinamento e integração do wake word

---

**Prioridade do projeto:** funcionalidade real, estabilidade, desempenho e interface premium.


## Atualização de voz e interface (1.1.0)

- Os cartões `GlassCard` agora organizam os controles em coluna; os elementos deixam de se sobrepor.
- O primeiro início baixa o modelo Vosk PT-BR para o armazenamento privado do aplicativo e o instala automaticamente.
- A ativação por voz em primeiro plano reconhece as frases "Hey Dev", "Ei Dev", "Ok Dev" e "Okay Dev" usando o Vosk instalado.
- O botão manual da tela principal foi renomeado para "Falar agora".

Limitações que continuam explícitas:
- A pasta `app/src/main/cpp/llama.cpp` não está incluída no ZIP. O CMake original seleciona o backend STUB quando ela está ausente. Portanto, baixar um GGUF não habilita inferência real até que o backend llama.cpp seja integrado e compilado.
- O serviço de microfone em segundo plano precisa ser ativado pelo usuário nas configurações do aplicativo e depende das permissões do Android. O comportamento de escuta contínua em segundo plano não deve ser iniciado silenciosamente.
- O reconhecimento de wake phrase por Vosk depende do que o modelo transcreve; não é um detector acústico dedicado e pode exigir ajuste no aparelho.


## Atualização de manutenção — 1.2.0

- A logo DEVEx enviada foi adicionada como recurso oficial do app, launcher, splash screen compatível com Android 8+ e núcleo visual da orb.
- A extração do ZIP Vosk agora ocorre em diretório temporário, bloqueia caminhos ZIP que escapem da pasta privada e valida os arquivos essenciais antes de substituir o modelo existente.
- O CMake não permite mais compilar silenciosamente um backend STUB. A compilação exige o código real do llama.cpp.
- Foi adicionado `scripts/prepare-llama.sh` para obter a revisão fixada `b4510` do llama.cpp.
- Foi adicionado `.github/workflows/android-build.yml` para compilar o APK Debug e publicar o Artifact no GitHub Actions.
- NDK 26.1.10909125 e versão do app 1.2.0 foram fixados.

### Limitações que ainda impedem declarar o app como concluído

1. O ZIP de origem não contém o código-fonte do llama.cpp nem um APK compilado. O backend JNI já existente usa a API C do llama.cpp, mas a compatibilidade desse código com a revisão externa `b4510` ainda precisa ser confirmada por uma compilação real no Android NDK.
2. Não foi fornecido modelo GGUF Qwen, e o download do Qwen ainda é acionado manualmente por URL nas configurações. A instalação automática de Qwen na primeira execução com consentimento e progresso não está implementada.
3. O Vosk PT-BR é baixado automaticamente, mas a detecção de frase de ativação continua dependente da transcrição Vosk. O classificador ONNX não vem acompanhado de modelo treinado e seu pipeline de features não equivale a um detector de wake word pronto.
4. O callback de teste do Gemini Live na Activity está vazio. Portanto, não se deve considerar o teste de conexão Gemini integrado à tela concluído.
5. Não foi possível compilar ou executar o app neste ambiente: não há Gradle instalado, Android SDK/NDK ou dispositivo Android disponível. O APK e os testes físicos não foram produzidos.

### Verificações realizadas nesta revisão

- Inspeção da lista completa dos 44 arquivos originais do ZIP.
- Revisão estática do Gradle, Manifest, JNI/CMake, serviço, Vosk, telas Compose e recursos.
- Verificação da presença dos novos recursos de logo, workflow e script de preparação.
- Não foram executados `assembleDebug`, inferência Qwen, testes de áudio, testes Gemini ou testes em aparelho.
