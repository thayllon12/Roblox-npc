extends SceneTree
## Testes headless. Execução:
##   godot --headless --path . -s res://tests/run_tests.gd
## Sai com código 1 se algum teste falhar (o workflow do GitHub Actions usa isso).

var failures := 0
var passes := 0


func _init() -> void:
	_test_generator_routes()
	_test_gap_formula()
	_test_powerups()
	_test_catalog()
	print("")
	print("Testes: %d ok, %d falha(s)" % [passes, failures])
	quit(1 if failures > 0 else 0)


func _check(cond: bool, msg: String) -> void:
	if cond:
		passes += 1
		print("  OK    " + msg)
	else:
		failures += 1
		printerr("  ERRO  " + msg)


func _test_generator_routes() -> void:
	print("Gerador procedural:")
	var speeds := [420.0, 600.0, 780.0]
	for seed_i in range(24):
		var gen := SegmentGenerator.new(1000 + seed_i)
		var speed: float = speeds[seed_i % speeds.size()]
		var segs: Array = []
		var start := 0.0
		for i in 80:
			var diff := clampf(float(i) / 60.0, 0.0, 1.0)
			var seg := gen.generate(start, speed, diff)
			segs.append(seg)
			start = float(seg["end"])
		var errs := SegmentGenerator.validate(segs, speed)
		_check(errs.is_empty(), "seed %d, velocidade %.0f: rotas válidas" % [seed_i, speed])
		for e in errs:
			printerr("         " + e)


func _test_gap_formula() -> void:
	print("Distância mínima entre obstáculos:")
	var g := SegmentGenerator.min_gap_for(420.0)
	_check(g >= 420.0 * 1.3 * 0.85 - 0.01 and g <= 900.0, "gap em 420 px/s = %.0f px" % g)
	var g_max := SegmentGenerator.min_gap_for(780.0)
	_check(g_max <= 900.0, "gap em 780 px/s não excede o limite (%.0f px)" % g_max)
	var time_gap := g / (420.0 * 1.3)
	_check(time_gap >= 0.8, "tempo entre obstáculos com impulso ativo: %.2f s" % time_gap)


func _test_powerups() -> void:
	print("Power-ups:")
	var p := PowerupState.new()
	p.add_slot("magnet")
	p.add_slot("shield")
	p.add_slot("speed")
	_check(p.slots.size() == PowerupState.MAX_SLOTS, "slots limitados a %d" % PowerupState.MAX_SLOTS)
	_check(p.slots[0] == "shield", "o slot mais antigo é descartado ao encher")
	var first := p.activate()
	_check(first == "shield" and p.is_active("shield"), "ativação consome o slot e ativa o efeito")
	_check(p.activate() == "", "cooldown bloqueia ativação imediata")
	p.tick(PowerupState.COOLDOWN + 0.1)
	p.tick(10000.0)
	_check(not p.is_active("shield") or p.time_left("shield") > 0.0, "efeito expira com o tempo")
	var q := PowerupState.new()
	q.add_slot("speed")
	q.activate()
	q.tick(GameCatalog.POWERUPS["speed"]["duration"] + 0.1)
	_check(not q.is_active("speed"), "impulso expira após a duração")


func _test_catalog() -> void:
	print("Catálogo:")
	_check(not GameCatalog.find_item("leon_golden").is_empty(), "skin dourada existe")
	_check(GameCatalog.find_item("inexistente").is_empty(), "item inexistente retorna vazio")
	var ids := {}
	var dup := false
	for item in GameCatalog.SHOP:
		if ids.has(item["id"]):
			dup = true
		ids[item["id"]] = true
	_check(not dup, "IDs da loja são únicos")
	for key in GameCatalog.POWERUP_KEYS:
		_check(GameCatalog.POWERUPS.has(key), "power-up %s tem definição" % key)
