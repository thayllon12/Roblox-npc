#!/usr/bin/env python3
"""Generate original pixel-art style sprites for Leon Rush (CC0 / original)."""
from PIL import Image, ImageDraw
import os

ROOT = os.path.join(os.path.dirname(__file__), "..", "assets")
SCALE = 4  # pixel art upscale


def save(img: Image.Image, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Nearest-neighbor upscale for crisp pixels
    big = img.resize((img.width * SCALE, img.height * SCALE), Image.NEAREST)
    big.save(path)
    print("  ", path)


def new(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))


# ── Palette ──────────────────────────────────────────────
BODY = (242, 180, 64, 255)
BODY_D = (210, 140, 40, 255)
MANE = (200, 100, 25, 255)
MANE_D = (160, 70, 15, 255)
OUTLINE = (40, 25, 10, 255)
EYE = (20, 20, 25, 255)
WHITE = (255, 255, 255, 255)
NOSE = (60, 40, 30, 255)
TAIL_TIP = (30, 25, 20, 255)


def draw_leon_frame(pose: str) -> Image.Image:
    """16x20 base leon facing right."""
    img = new(20, 22)
    d = ImageDraw.Draw(img)

    def px(x, y, c):
        d.point((x, y), fill=c)

    def box(x0, y0, x1, y1, c):
        d.rectangle([x0, y0, x1, y1], fill=c)

    # Body
    box(6, 8, 14, 16, BODY)
    box(6, 8, 7, 16, BODY_D)  # shade

    # Head
    box(10, 3, 17, 10, BODY)
    box(10, 3, 11, 10, BODY_D)

    # Mane (behind/around head)
    if pose != "slide":
        box(8, 1, 15, 5, MANE)
        box(7, 2, 9, 7, MANE)
        box(14, 2, 18, 6, MANE)
        box(8, 1, 9, 2, MANE_D)
    else:
        box(8, 4, 16, 8, MANE)

    # Eyes
    if pose != "death":
        px(14, 5, WHITE)
        px(15, 5, EYE)
        px(16, 5, WHITE)
        px(17, 5, EYE)
    else:
        # X eyes
        px(14, 5, EYE)
        px(16, 5, EYE)

    # Nose
    px(17, 7, NOSE)

    # Legs depending on pose
    if pose == "idle":
        box(7, 16, 9, 20, BODY_D)
        box(12, 16, 14, 20, BODY_D)
    elif pose == "run1":
        box(6, 16, 8, 20, BODY_D)
        box(13, 15, 15, 19, BODY_D)
    elif pose == "run2":
        box(8, 15, 10, 19, BODY_D)
        box(12, 16, 14, 20, BODY_D)
    elif pose == "run3":
        box(7, 16, 9, 20, BODY_D)
        box(13, 14, 15, 18, BODY_D)
    elif pose == "jump":
        box(7, 15, 9, 18, BODY_D)
        box(12, 15, 14, 18, BODY_D)
        # stretched body hint
        box(6, 7, 14, 15, BODY)
    elif pose == "fall":
        box(7, 16, 9, 19, BODY_D)
        box(12, 16, 14, 19, BODY_D)
    elif pose == "slide":
        box(4, 12, 16, 16, BODY)
        box(3, 13, 5, 15, BODY_D)  # front
        box(14, 11, 18, 14, MANE)  # mane back
        # legs tucked
        box(8, 15, 10, 17, BODY_D)
        box(12, 15, 14, 17, BODY_D)
    elif pose == "hurt":
        box(7, 16, 9, 19, BODY_D)
        box(12, 16, 14, 19, BODY_D)
        # flash-ish outline
        box(5, 7, 15, 16, (255, 100, 80, 180))

    # Tail
    if pose == "slide":
        box(1, 12, 4, 14, BODY)
        px(1, 11, TAIL_TIP)
    else:
        box(3, 10, 6, 12, BODY)
        px(3, 9, TAIL_TIP)
        px(2, 10, TAIL_TIP)

    # Outline sparse
    for x in range(20):
        for y in range(22):
            p = img.getpixel((x, y))
            if p[3] == 0:
                continue
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < 20 and 0 <= ny < 22:
                    if img.getpixel((nx, ny))[3] == 0:
                        # soft outline only on outer
                        pass

    return img


def gen_leon():
    print("Leon frames...")
    poses = ["idle", "run1", "run2", "run3", "jump", "fall", "slide", "hurt", "death"]
    for p in poses:
        save(draw_leon_frame(p), os.path.join(ROOT, "characters/leon", f"{p}.png"))


def gen_meat():
    print("Meat...")
    variants = {
        "common": (240, 110, 70),
        "golden": (255, 210, 40),
        "rare": (190, 80, 255),
        "special": (60, 240, 180),
        "energy": (80, 200, 255),
    }
    for name, col in variants.items():
        img = new(12, 12)
        d = ImageDraw.Draw(img)
        # bone-ish meat shape
        d.ellipse([2, 2, 10, 10], fill=col + (255,))
        d.ellipse([1, 4, 4, 8], fill=(240, 230, 210, 255))  # bone end
        d.ellipse([8, 4, 11, 8], fill=(240, 230, 210, 255))
        d.ellipse([4, 4, 8, 8], fill=tuple(max(0, c - 30) for c in col) + (255,))
        save(img, os.path.join(ROOT, "collectibles", f"meat_{name}.png"))


def gen_obstacles():
    print("Obstacles...")
    # Rock
    img = new(14, 12)
    d = ImageDraw.Draw(img)
    d.ellipse([1, 2, 13, 11], fill=(120, 115, 110, 255))
    d.ellipse([3, 3, 8, 7], fill=(150, 145, 140, 255))
    save(img, os.path.join(ROOT, "obstacles", "rock.png"))

    # Log
    img = new(16, 10)
    d = ImageDraw.Draw(img)
    d.rectangle([1, 2, 15, 8], fill=(130, 80, 35, 255))
    d.ellipse([0, 2, 3, 8], fill=(150, 100, 50, 255))
    d.ellipse([13, 2, 16, 8], fill=(100, 60, 25, 255))
    d.line([4, 3, 12, 3], fill=(90, 50, 20, 255))
    save(img, os.path.join(ROOT, "obstacles", "log.png"))

    # Thorns / bush
    img = new(14, 12)
    d = ImageDraw.Draw(img)
    d.ellipse([2, 5, 12, 11], fill=(50, 120, 40, 255))
    for x, y in [(3, 3), (6, 1), (9, 3), (5, 4), (8, 4), (11, 5)]:
        d.line([7, 8, x, y], fill=(30, 90, 25, 255))
        d.point((x, y), fill=(200, 60, 40, 255))
    save(img, os.path.join(ROOT, "obstacles", "thorns.png"))

    # Crystal
    img = new(12, 16)
    d = ImageDraw.Draw(img)
    d.polygon([(6, 0), (11, 8), (8, 15), (4, 15), (1, 8)], fill=(160, 100, 230, 255))
    d.polygon([(6, 0), (11, 8), (6, 10)], fill=(200, 160, 255, 255))
    save(img, os.path.join(ROOT, "obstacles", "crystal.png"))

    # Low barrier
    img = new(18, 8)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 2, 17, 7], fill=(100, 70, 40, 255))
    d.rectangle([0, 2, 17, 3], fill=(130, 95, 55, 255))
    save(img, os.path.join(ROOT, "obstacles", "low_barrier.png"))


def gen_powerups():
    print("Power-ups...")
    colors = {
        "meat_magnet": (255, 140, 40),
        "shield": (80, 180, 255),
        "speed_boost": (255, 230, 60),
        "meat_multiplier": (230, 70, 220),
        "invincibility": (255, 245, 150),
        "mega_jump": (80, 255, 140),
    }
    icons = {
        "meat_magnet": "M",
        "shield": "O",
        "speed_boost": ">",
        "meat_multiplier": "x",
        "invincibility": "*",
        "mega_jump": "^",
    }
    for name, col in colors.items():
        img = new(14, 14)
        d = ImageDraw.Draw(img)
        d.ellipse([1, 1, 12, 12], fill=col + (255,))
        d.ellipse([3, 3, 10, 10], fill=tuple(min(255, c + 40) for c in col) + (255,))
        # simple symbol
        cx, cy = 7, 7
        if name == "shield":
            d.arc([3, 3, 10, 11], 0, 180, fill=(255, 255, 255, 220), width=1)
        elif name == "speed_boost":
            d.polygon([(4, 4), (10, 7), (4, 10)], fill=(40, 40, 20, 255))
        elif name == "mega_jump":
            d.polygon([(7, 3), (10, 9), (4, 9)], fill=(20, 80, 40, 255))
        elif name == "meat_magnet":
            d.rectangle([5, 4, 8, 10], fill=(255, 255, 255, 200))
            d.arc([3, 6, 10, 12], 200, 340, fill=(255, 255, 255, 200), width=1)
        elif name == "meat_multiplier":
            d.line([4, 4, 10, 10], fill=(255, 255, 255, 220), width=2)
            d.line([10, 4, 4, 10], fill=(255, 255, 255, 220), width=2)
        else:  # invincibility
            for a in range(0, 360, 45):
                import math
                x = int(7 + 4 * math.cos(math.radians(a)))
                y = int(7 + 4 * math.sin(math.radians(a)))
                d.point((x, y), fill=(255, 255, 255, 255))
            d.ellipse([5, 5, 9, 9], fill=(255, 255, 200, 255))
        save(img, os.path.join(ROOT, "powerups", f"{name}.png"))


def gen_ui():
    print("UI...")
    # App icon 48x48 base
    img = new(32, 32)
    d = ImageDraw.Draw(img)
    d.ellipse([2, 2, 29, 29], fill=(40, 120, 60, 255))
    # mini leon face
    d.ellipse([8, 8, 24, 24], fill=BODY)
    d.ellipse([6, 6, 14, 14], fill=MANE)
    d.ellipse([18, 6, 26, 14], fill=MANE)
    d.point((14, 14), fill=EYE)
    d.point((18, 14), fill=EYE)
    d.ellipse([15, 16, 17, 18], fill=NOSE)
    save(img, os.path.join(ROOT, "ui", "icon.png"))

    # Meat icon for HUD
    img = new(10, 10)
    d = ImageDraw.Draw(img)
    d.ellipse([1, 1, 8, 8], fill=(240, 110, 70, 255))
    d.ellipse([0, 3, 2, 6], fill=(240, 230, 210, 255))
    d.ellipse([7, 3, 9, 6], fill=(240, 230, 210, 255))
    save(img, os.path.join(ROOT, "ui", "meat_icon.png"))


def gen_ground():
    print("Ground tiles...")
    biomes = {
        "jungle": (55, 130, 55),
        "savanna": (160, 140, 70),
        "cave": (70, 65, 80),
        "volcanic": (70, 40, 35),
        "ruins": (110, 105, 90),
    }
    for name, col in biomes.items():
        img = new(16, 16)
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, 15, 15], fill=col + (255,))
        # noise
        import random
        rng = random.Random(hash(name) & 0xFFFFFFFF)
        for _ in range(20):
            x, y = rng.randint(0, 15), rng.randint(0, 15)
            c = tuple(max(0, min(255, v + rng.randint(-15, 15))) for v in col) + (255,)
            d.point((x, y), fill=c)
        save(img, os.path.join(ROOT, "environments", f"ground_{name}.png"))


if __name__ == "__main__":
    gen_leon()
    gen_meat()
    gen_obstacles()
    gen_powerups()
    gen_ui()
    gen_ground()
    print("Done.")
