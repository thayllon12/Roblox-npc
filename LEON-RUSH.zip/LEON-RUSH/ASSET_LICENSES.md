# Licenças e autoria dos recursos

Este arquivo registra a origem e a licença de todos os recursos usados pelo Leon Rush.

## Resumo

| Tipo | Origem | Licença | Autor |
|---|---|---|---|
| Personagem Leon | Desenhado por código em `scripts/player/leon.gd` | Propriedade do projeto | Equipe Leon Rush |
| Carne, orbes e power-ups | Desenhados por código em `scripts/gameplay/collectible.gd` | Propriedade do projeto | Equipe Leon Rush |
| Obstáculos e cenários | Desenhados por código em `scripts/gameplay/obstacle.gd` e `sky_backdrop.gd` | Propriedade do projeto | Equipe Leon Rush |
| Interface | Controles criados por código em `scripts/ui/` | Propriedade do projeto | Equipe Leon Rush |
| Ícone (`icon.svg`) | Criado manualmente em SVG | Propriedade do projeto | Equipe Leon Rush |
| Sons e efeitos | Sintetizados por código em `scripts/core/audio_manager.gd` | Propriedade do projeto | Equipe Leon Rush |
| Música (menu e jogo) | Sintetizada por código em `scripts/core/audio_manager.gd` | Propriedade do projeto | Equipe Leon Rush |
| Fontes | Fonte padrão embutida no Godot Engine | Ver a licença distribuída com o Godot Engine (não verificada individualmente) | Godot Engine contributors |

## Situação atual

- **Nenhum asset de terceiros é usado nesta versão.** Não há imagens, sons, músicas ou fontes baixados de outros sites.
- Todo o visual e o áudio são gerados em tempo de execução pelo próprio código do jogo, o que elimina a necessidade de rastrear licenças externas.
- Não há uso de propriedade intelectual de outros jogos, incluindo Banana Kong. Leon, a carne, os biomas, os obstáculos e a interface foram criados especificamente para este projeto.

## Como registrar um novo asset

Antes de adicionar qualquer arquivo em `assets/`, preencha uma linha nesta tabela:

| Arquivo | Origem (URL) | Data de acesso | Licença (texto exato) | Autor | Modificações |
|---|---|---|---|---|---|
| (exemplo) `assets/ui/botao.png` | https://... | 2026-01-01 | CC0 1.0 | Nome | Redimensionado |

Regras:

1. Use somente recursos com licença CC0 ou licença permissiva confirmada na página oficial do recurso. Não presuma licença.
2. Não use imagens encontradas por busca de imagens sem conferir a licença.
3. Não use assets comerciais sem autorização escrita.
4. Se a licença for desconhecida ou ambígua, não inclua o arquivo.
5. Para licenças que exigem atribuição (CC-BY), inclua o crédito no menu de créditos antes de publicar.

## Fontes recomendadas para CC0 verificável

- Kenney (kenney.nl): pacotes sob CC0. Confira a licença de cada pacote.
- Poly Haven (polyhaven.com): texturas e modelos sob CC0.
- OpenGameArt (opengameart.org): use somente recursos com a licença indicada individualmente como CC0.
- AmbientCG (ambientcg.com): confira a licença de cada recurso.
