extends Area2D
class_name PowerUp
## World pickup that grants a temporary ability to Leon.

enum PowerUpType { MEAT_MAGNET, SHIELD, SPEED_BOOST, MEAT_MULTIPLIER, INVINCIBILITY, MEGA_JUMP }

@export var powerup_type: PowerUpType = PowerUpType.SHIELD
@export var duration: float = 6.0
@export var float_amplitude: float = 8.0
@export var float_speed: float = 2.8

var base_y: float = 0.0
var time: float = 0.0
var is_collected: bool = false

const TYPE_COLORS := {
	PowerUpType.MEAT_MAGNET: Color(1.0, 0.55, 0.2),
	PowerUpType.SHIELD: Color(0.35, 0.75, 1.0),
	PowerUpType.SPEED_BOOST: Color(1.0, 0.9, 0.25),
	PowerUpType.MEAT_MULTIPLIER: Color(0.9, 0.3, 0.85),
	PowerUpType.INVINCIBILITY: Color(1.0, 0.95, 0.6),
	PowerUpType.MEGA_JUMP: Color(0.4, 1.0, 0.55),
}

const TYPE_DURATION := {
	PowerUpType.MEAT_MAGNET: 8.0,
	PowerUpType.SHIELD: 999.0,  # until hit
	PowerUpType.SPEED_BOOST: 5.0,
	PowerUpType.MEAT_MULTIPLIER: 10.0,
	PowerUpType.INVINCIBILITY: 4.5,
	PowerUpType.MEGA_JUMP: 7.0,
}

func _ready() -> void:
	base_y = position.y
	duration = TYPE_DURATION.get(powerup_type, 6.0)
	body_entered.connect(_on_body_entered)
	_apply_visual()

func _apply_visual() -> void:
	var visual := get_node_or_null("Visual")
	if visual is Sprite2D:
		return
	if visual is ColorRect:
		visual.color = TYPE_COLORS.get(powerup_type, Color.WHITE)

func _process(delta: float) -> void:
	if is_collected:
		return
	time += delta
	position.y = base_y + sin(time * float_speed) * float_amplitude
	rotation = sin(time * 2.0) * 0.2
	scale = Vector2.ONE * (1.0 + sin(time * 4.0) * 0.06)

func _on_body_entered(body: Node2D) -> void:
	if is_collected:
		return
	if body is Leon or body.is_in_group("player"):
		collect()

func collect() -> void:
	if is_collected:
		return
	is_collected = true
	var type_str := type_to_string(powerup_type)
	EventBus.powerup_activated.emit(type_str, duration)
	# Hide
	for child in get_children():
		if child is CanvasItem:
			child.visible = false
	await get_tree().create_timer(0.15).timeout
	queue_free()

static func type_to_string(t: PowerUpType) -> String:
	match t:
		PowerUpType.MEAT_MAGNET: return "meat_magnet"
		PowerUpType.SHIELD: return "shield"
		PowerUpType.SPEED_BOOST: return "speed_boost"
		PowerUpType.MEAT_MULTIPLIER: return "meat_multiplier"
		PowerUpType.INVINCIBILITY: return "invincibility"
		PowerUpType.MEGA_JUMP: return "mega_jump"
	return "shield"

static func string_to_type(s: String) -> PowerUpType:
	match s:
		"meat_magnet": return PowerUpType.MEAT_MAGNET
		"shield": return PowerUpType.SHIELD
		"speed_boost": return PowerUpType.SPEED_BOOST
		"meat_multiplier": return PowerUpType.MEAT_MULTIPLIER
		"invincibility": return PowerUpType.INVINCIBILITY
		"mega_jump": return PowerUpType.MEGA_JUMP
	return PowerUpType.SHIELD
