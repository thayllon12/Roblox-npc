extends Node
## Tracks active power-ups and applies/removes their effects.

var active: Dictionary = {}  # type_string -> remaining_time (float), shield uses huge time

@onready var player: Leon = null

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	EventBus.powerup_activated.connect(_on_powerup_activated)
	EventBus.powerup_expired.connect(_on_external_expire)
	EventBus.game_started.connect(_on_game_started)
	EventBus.game_over.connect(_on_game_over)

func _on_external_expire(type: String) -> void:
	# e.g. shield broken by player
	if active.has(type):
		active.erase(type)

func setup(player_ref: Leon) -> void:
	player = player_ref

var _magnet_tick: float = 0.0

func _process(delta: float) -> void:
	if not GameManager.is_playing():
		return
	var expired: Array[String] = []
	for type_str in active.keys():
		if type_str == "shield":
			continue
		active[type_str] = float(active[type_str]) - delta
		if active[type_str] <= 0.0:
			expired.append(type_str)
	for t in expired:
		_expire(t)

	# Keep magnet attracting newly spawned meats
	if active.has("meat_magnet"):
		_magnet_tick -= delta
		if _magnet_tick <= 0.0:
			_magnet_tick = 0.4
			_activate_magnet_on_nearby()

func _on_powerup_activated(type: String, duration: float) -> void:
	# Refresh or add
	active[type] = duration
	_apply_effect(type)
	# Meat magnet special: attract nearby meats
	if type == "meat_magnet" and player:
		_activate_magnet_on_nearby()

func _apply_effect(type: String) -> void:
	match type:
		"meat_multiplier":
			GameManager.multiplier = 2.0
		"meat_magnet":
			pass  # handled per-frame / on activate
		_:
			pass  # player already listens to EventBus

func _expire(type: String) -> void:
	if not active.has(type):
		return
	active.erase(type)
	match type:
		"meat_multiplier":
			GameManager.multiplier = 1.0
		"meat_magnet":
			pass
	EventBus.powerup_expired.emit(type)

func force_expire(type: String) -> void:
	_expire(type)

func is_active(type: String) -> bool:
	return active.has(type)

func get_remaining(type: String) -> float:
	return float(active.get(type, 0.0))

func get_active_list() -> Array:
	return active.keys()

func _activate_magnet_on_nearby() -> void:
	if not player:
		return
	# Find meats in the world and activate magnet
	var root := player.get_tree().current_scene
	if not root:
		return
	_magnet_recursive(root)

func _magnet_recursive(node: Node) -> void:
	if node is Meat and not node.is_collected:
		node.activate_magnet(player)
	for child in node.get_children():
		_magnet_recursive(child)

func _on_game_started() -> void:
	active.clear()
	GameManager.multiplier = 1.0

func _on_game_over(_score: int, _distance: float, _meat: int) -> void:
	# Clean all
	var keys := active.keys()
	for t in keys:
		_expire(t)
	active.clear()
