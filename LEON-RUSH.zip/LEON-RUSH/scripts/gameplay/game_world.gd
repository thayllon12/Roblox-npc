extends Node2D
## Main gameplay scene — final integrated loop.

@onready var player: Leon = $Leon
@onready var camera: Camera2D = $Camera2D
@onready var world_gen: Node2D = $WorldGenerator
@onready var input_handler: Node = $InputHandler
@onready var hud: CanvasLayer = $HUD
@onready var pause_menu: Control = $PauseLayer/PauseMenu
@onready var game_over_screen: Control = $GameOverLayer/GameOver
@onready var background: ColorRect = $ParallaxBG/Background

@onready var distance_label: Label = $HUD/TopBar/DistanceLabel
@onready var meat_label: Label = $HUD/TopBar/MeatLabel
@onready var score_label: Label = $HUD/TopBar/ScoreLabel
@onready var mult_label: Label = $HUD/TopBar/MultLabel
@onready var powerup_label: Label = $HUD/PowerupBar/PowerupLabel
@onready var biome_label: Label = $HUD/TopBar/BiomeLabel

var powerup_manager: Node = null
var biome_manager: Node = null
var mission_manager: Node = null
var shop_data: Node = null
var shake_time: float = 0.0
var shake_intensity: float = 0.0
var base_cam_offset := Vector2(260, -70)

func _ready() -> void:
	# Managers
	powerup_manager = preload("res://scripts/gameplay/powerup_manager.gd").new()
	powerup_manager.name = "PowerUpManager"
	add_child(powerup_manager)
	powerup_manager.setup(player)

	biome_manager = preload("res://scripts/procedural/biome_manager.gd").new()
	biome_manager.name = "BiomeManager"
	add_child(biome_manager)
	biome_manager.setup(world_gen, background)

	mission_manager = preload("res://scripts/progression/mission_manager.gd").new()
	mission_manager.name = "MissionManager"
	add_child(mission_manager)

	shop_data = preload("res://scripts/progression/shop_data.gd").new()
	add_child(shop_data)
	shop_data.apply_skin_to_leon(player)

	# Signals
	input_handler.jump_requested.connect(_on_jump)
	input_handler.slide_requested.connect(_on_slide)
	player.died.connect(_on_player_died)
	EventBus.game_paused.connect(_on_paused)
	EventBus.game_resumed.connect(_on_resumed)
	EventBus.game_over.connect(_on_game_over)
	EventBus.distance_updated.connect(_on_distance_updated)
	EventBus.meat_collected.connect(_on_meat_collected)
	EventBus.score_updated.connect(_on_score_updated)
	EventBus.powerup_activated.connect(_on_powerup_ui)
	EventBus.powerup_expired.connect(_on_powerup_expired_ui)
	EventBus.obstacle_hit.connect(_on_obstacle_hit)
	EventBus.biome_changed.connect(_on_biome_changed)

	_connect_button(pause_menu, "VBox/ContinueBtn", _on_continue)
	_connect_button(pause_menu, "VBox/RestartBtn", _on_restart)
	_connect_button(pause_menu, "VBox/MenuBtn", _on_main_menu)
	_connect_button(game_over_screen, "VBox/RetryBtn", _on_restart)
	_connect_button(game_over_screen, "VBox/HomeBtn", _on_main_menu)

	world_gen.start(player)
	GameManager.start_game()
	_refresh_powerup_ui()
	if biome_label:
		biome_label.text = biome_manager.get_display_name()

func _connect_button(root: Node, path: String, callable: Callable) -> void:
	var btn = root.get_node_or_null(path)
	if btn:
		btn.pressed.connect(callable)

func _process(delta: float) -> void:
	if GameManager.is_playing():
		GameManager.add_distance(delta)
		GameManager.sync_speed_from_player(player.get_run_speed())

		var target_cam := Vector2(player.position.x + base_cam_offset.x, player.position.y + base_cam_offset.y)
		if shake_time > 0.0:
			shake_time -= delta
			var offset := Vector2(
				randf_range(-shake_intensity, shake_intensity),
				randf_range(-shake_intensity, shake_intensity)
			)
			camera.position = camera.position.lerp(target_cam + offset, 10.0 * delta)
			shake_intensity = max(0.0, shake_intensity - delta * 20.0)
		else:
			camera.position = camera.position.lerp(target_cam, 8.0 * delta)

		_refresh_powerup_ui()

func _on_jump() -> void:
	player.jump()
	if mission_manager and mission_manager.has_method("register_jump"):
		mission_manager.register_jump()

func _on_slide() -> void:
	player.slide()

func _on_player_died() -> void:
	_shake(12.0, 0.35)
	GameManager.end_game()

func _on_obstacle_hit() -> void:
	_shake(8.0, 0.2)

func _shake(intensity: float, duration: float) -> void:
	shake_intensity = intensity
	shake_time = duration

func _on_paused() -> void:
	if pause_menu:
		pause_menu.visible = true

func _on_resumed() -> void:
	if pause_menu:
		pause_menu.visible = false

func _on_game_over(score: int, distance: float, meat: int) -> void:
	if game_over_screen:
		game_over_screen.visible = true
		_set_label(game_over_screen, "VBox/ScoreLabel", "Score: %d" % score)
		_set_label(game_over_screen, "VBox/DistanceLabel", "Distance: %.0f m" % distance)
		_set_label(game_over_screen, "VBox/MeatLabel", "Meat: %d" % meat)
		var is_record := distance >= SaveManager.get_best_distance() - 0.01
		var record_l = game_over_screen.get_node_or_null("VBox/RecordLabel")
		if record_l:
			record_l.visible = is_record
			record_l.text = "NEW RECORD!" if is_record else ""

func _set_label(root: Node, path: String, text: String) -> void:
	var l = root.get_node_or_null(path)
	if l:
		l.text = text

func _on_distance_updated(distance: float) -> void:
	if distance_label:
		distance_label.text = "%.0f m" % distance

func _on_meat_collected(_amount: int, _type: String) -> void:
	if meat_label:
		meat_label.text = "Meat: %d" % GameManager.meat_collected

func _on_score_updated(score: int) -> void:
	if score_label:
		score_label.text = "Score: %d" % score
	if mult_label:
		if GameManager.multiplier > 1.01:
			mult_label.text = "x%.0f" % GameManager.multiplier
			mult_label.visible = true
		else:
			mult_label.visible = false

func _on_powerup_ui(_type: String, _duration: float) -> void:
	_refresh_powerup_ui()

func _on_powerup_expired_ui(_type: String) -> void:
	_refresh_powerup_ui()

func _on_biome_changed(biome_name: String) -> void:
	if biome_label and biome_manager:
		biome_label.text = biome_manager.get_display_name()

func _refresh_powerup_ui() -> void:
	if not powerup_label or not powerup_manager:
		return
	var list: Array = powerup_manager.get_active_list()
	if list.is_empty():
		powerup_label.text = ""
		return
	var parts: PackedStringArray = []
	for t in list:
		var rem: float = powerup_manager.get_remaining(t)
		if t == "shield":
			parts.append("SHIELD")
		else:
			parts.append("%s %.0fs" % [str(t).replace("_", " ").to_upper(), rem])
	powerup_label.text = " | ".join(parts)

func _on_continue() -> void:
	GameManager.resume_game()

func _on_restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_main_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main/main_menu.tscn")
