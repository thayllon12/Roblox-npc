class_name GameWorld
extends Node2D
## Controla a corrida. O cenário é "rolado" pela variável scrolled: cada objeto tem uma posição
## fixa na pista (track) e sua posição na tela é calculada a partir do quanto já rolou.
## Ao pausar, a árvore inteira é pausada pelo Main; este nó não processa nada fora de RUNNING.

signal run_ended(result: Dictionary)

const GROUND_Y := 560.0
const LEON_X := 240.0
const BASE_SPEED := 420.0
const MAX_SPEED := 780.0
const BOOST_MULT := 1.3
const PX_PER_M := 40.0
const SPAWN_AHEAD := 1600.0
const MAGNET_RANGE := 300.0
const DEATH_DELAY := 1.2
const MENU_DRIFT := 90.0

enum Mode { IDLE, RUNNING, DYING, OVER }

var mode: Mode = Mode.IDLE
var powers := PowerupState.new()
var scrolled := 0.0
var meat_units := 0
var golden := 0
var jumps := 0
var powerups_used := 0
var streak := 0
var max_streak := 0
var run_time := 0.0
var points := 0.0

var bg: SkyBackdrop
var stage: Node2D
var leon: Leon
var fx: ParticleFX

var obstacles_live: Array = []
var collectibles_live: Array = []
var obstacle_pool: ObjectPool
var collectible_pool: ObjectPool

var _generator: SegmentGenerator
var _next_track := 0.0
var _combo_timer := 0.0
var _shake := 0.0
var _invuln := 0.0
var _death_timer := 0.0
var _obstacle_container: Node2D
var _collectible_container: Node2D


func _ready() -> void:
	bg = SkyBackdrop.new()
	add_child(bg)
	stage = Node2D.new()
	add_child(stage)
	_obstacle_container = Node2D.new()
	stage.add_child(_obstacle_container)
	_collectible_container = Node2D.new()
	stage.add_child(_collectible_container)
	fx = ParticleFX.new()
	stage.add_child(fx)
	leon = Leon.new()
	stage.add_child(leon)
	leon.position = Vector2(LEON_X, GROUND_Y)
	leon.fx = fx
	leon.landed.connect(_on_landed)

	obstacle_pool = ObjectPool.new(_obstacle_container, func() -> Node: return Obstacle.new(), 16)
	collectible_pool = ObjectPool.new(_collectible_container, func() -> Node: return Collectible.new(), 40)
	leon.set_loadout(Save.loadout())
	_refresh_bg()


# ---------- Controle externo (chamado pelo Main) ----------

func is_running() -> bool:
	return mode == Mode.RUNNING


func start_run() -> void:
	_release_all()
	scrolled = 0.0
	_next_track = 0.0
	_generator = SegmentGenerator.new()
	leon.reset()
	leon.set_loadout(Save.loadout())
	powers.reset()
	meat_units = 0
	golden = 0
	jumps = 0
	powerups_used = 0
	streak = 0
	max_streak = 0
	run_time = 0.0
	points = 0.0
	_combo_timer = 0.0
	_shake = 0.0
	_invuln = 0.0
	_death_timer = 0.0
	fx.clear()
	var quality := clampi(int(Save.get_setting("quality")), 0, 2)
	fx.quality_scale = [0.4, 0.7, 1.0][quality]
	mode = Mode.RUNNING
	_spawn_ahead()
	_layout()


func stop_run() -> void:
	_release_all()
	scrolled = 0.0
	_next_track = 0.0
	mode = Mode.IDLE
	leon.reset()
	leon.set_loadout(Save.loadout())
	fx.clear()


func jump() -> void:
	if mode != Mode.RUNNING:
		return
	if leon.request_jump():
		jumps += 1
		Audio.play("jump")


func slide() -> void:
	if mode != Mode.RUNNING:
		return
	leon.request_slide()


## Ativa o power-up guardado no slot (botão ESPECIAL ou toque).
func activate_special() -> void:
	if mode != Mode.RUNNING:
		return
	var kind := powers.activate()
	if kind == "":
		return
	powerups_used += 1
	Audio.play("powerup")
	fx.emit_burst(leon.position + Vector2(0, -70), Color(str(GameCatalog.POWERUPS[kind]["color"])), 26, 340.0, 0.7, 6.0)
	_shake = maxf(_shake, 4.0)


# ---------- Dados para o HUD ----------

func distance_m() -> float:
	return scrolled / PX_PER_M


func combo_mult() -> int:
	return clampi(1 + streak / 6, 1, 5)


func current_speed() -> float:
	var s := _base_speed()
	return s * (BOOST_MULT if powers.is_active("speed") else 1.0)


func _base_speed() -> float:
	return lerpf(BASE_SPEED, MAX_SPEED, 1.0 - exp(-distance_m() / 1200.0))


# ---------- Loop ----------

func _process(delta: float) -> void:
	var dt := minf(delta, 1.0 / 30.0)
	match mode:
		Mode.IDLE:
			scrolled += MENU_DRIFT * dt
			leon.speed_ratio = 0.8
			leon.step(dt)
		Mode.RUNNING:
			_tick_running(dt)
		Mode.DYING:
			_death_timer -= dt
			leon.step(dt)
			if _death_timer <= 0.0:
				mode = Mode.OVER
				run_ended.emit(_result())
		_:
			pass
	_refresh_bg()
	_apply_shake(dt)


func _tick_running(dt: float) -> void:
	run_time += dt
	scrolled += current_speed() * dt
	powers.tick(dt)
	_invuln = maxf(0.0, _invuln - dt)
	_combo_timer -= dt
	if _combo_timer <= 0.0:
		streak = 0

	var speed_ratio := current_speed() / BASE_SPEED
	leon.speed_ratio = speed_ratio
	leon.jump_mult = 1.35 if powers.is_active("megajump") else 1.0
	leon.shield = powers.is_active("shield")
	leon.invincible = powers.is_active("invincibility")
	leon.step(dt)

	_spawn_ahead()
	_layout()
	_update_magnet(dt)
	_check_obstacles()
	if mode != Mode.RUNNING:
		return
	_check_collectibles()
	_recycle()


# ---------- Spawn e layout ----------

func _spawn_ahead() -> void:
	while _next_track < scrolled + SPAWN_AHEAD:
		var diff := clampf(distance_m() / 2500.0, 0.0, 1.0)
		var seg := _generator.generate(_next_track, _base_speed(), diff)
		_instantiate(seg)
		_next_track = float(seg["end"])


func _instantiate(seg: Dictionary) -> void:
	for o in seg["obstacles"]:
		var ob := obstacle_pool.acquire() as Obstacle
		ob.setup(str(o["kind"]), float(o["track"]))
		obstacles_live.append(ob)
	for m in seg["meats"]:
		var c := collectible_pool.acquire() as Collectible
		c.setup_meat(str(m["kind"]), float(m["track"]), float(m["h"]))
		collectibles_live.append(c)
	for orb in seg["orbs"]:
		var co := collectible_pool.acquire() as Collectible
		co.setup_orb(str(orb["kind"]), float(orb["track"]), float(orb["h"]))
		collectibles_live.append(co)


func _layout() -> void:
	for o in obstacles_live:
		o.position = Vector2(LEON_X + o.track - scrolled, GROUND_Y)
	for c in collectibles_live:
		c.position = Vector2(LEON_X + c.track - scrolled, GROUND_Y - c.h) + c.pull


func _update_magnet(dt: float) -> void:
	var magnet := powers.is_active("magnet")
	var target := leon.position + Vector2(0, -50)
	for c in collectibles_live:
		var base := Vector2(LEON_X + c.track - scrolled, GROUND_Y - c.h)
		if magnet and base.distance_to(target) < MAGNET_RANGE:
			c.pull = c.pull.move_toward(target - base, 1000.0 * dt)
		else:
			c.pull = c.pull.move_toward(Vector2.ZERO, 600.0 * dt)


# ---------- Colisões ----------

func _check_obstacles() -> void:
	var hit := leon.hit_rect()
	for o in obstacles_live.duplicate():
		if not hit.intersects(o.world_rect()):
			continue
		if leon.invincible:
			_remove_obstacle(o)
			fx.emit_burst(o.position + Vector2(0, -40), Color("#ffd60a"), 14, 260.0, 0.5, 5.0)
			return
		if _invuln > 0.0:
			return
		if powers.is_active("shield"):
			powers.consume_shield()
			_remove_obstacle(o)
			_invuln = 1.0
			_shake = 10.0
			Audio.play("hit")
			fx.emit_burst(leon.position + Vector2(0, -60), Color("#80ed99"), 22, 300.0, 0.6, 5.0)
			return
		_die()
		return


func _check_collectibles() -> void:
	var hit := leon.hit_rect()
	for c in collectibles_live.duplicate():
		var cr := Rect2(c.position - Vector2(22, 22), Vector2(44, 44))
		if hit.intersects(cr):
			_collect(c)


func _collect(c: Collectible) -> void:
	_remove_collectible(c)
	if c.is_orb:
		powers.add_slot(c.kind)
		Audio.play("powerup")
		fx.emit_burst(c.position, Color(str(GameCatalog.POWERUPS[c.kind]["color"])), 22, 260.0, 0.6, 5.0)
		return
	var base_value := int(GameCatalog.MEAT[c.kind]["value"])
	var units := base_value * (2 if powers.is_active("multiplier") else 1)
	streak += 1
	max_streak = maxi(max_streak, streak)
	_combo_timer = 2.5
	meat_units += units
	if c.kind == "golden":
		golden += 1
	points += float(units * combo_mult() * 10)
	Audio.play("collect")
	fx.emit_burst(c.position, Color(str(GameCatalog.MEAT[c.kind]["color"])), 10, 200.0, 0.45, 5.0)


func _on_landed(impact: float) -> void:
	if impact > 260.0:
		Audio.play("land")


func _die() -> void:
	mode = Mode.DYING
	_death_timer = DEATH_DELAY
	leon.die()
	_shake = 16.0
	Audio.play("hit")
	Audio.play("gameover")
	fx.emit_burst(leon.position + Vector2(0, -60), Color("#ffdd66"), 36, 460.0, 0.8, 6.0)
	if bool(Save.get_setting("vibration")):
		Input.vibrate_handheld(250)


func _result() -> Dictionary:
	return {
		"distance": snappedf(distance_m(), 0.1),
		"meat": meat_units,
		"score": score(),
		"jumps": jumps,
		"powerups": powerups_used,
		"golden": golden,
		"time": run_time,
		"combo": max_streak,
	}


func score() -> int:
	return int(distance_m()) + int(points)


# ---------- Limpeza e pool ----------

func _recycle() -> void:
	for o in obstacles_live.duplicate():
		if o.position.x < -160.0:
			_remove_obstacle(o)
	for c in collectibles_live.duplicate():
		if c.position.x < -120.0:
			_remove_collectible(c)


func _remove_obstacle(o: Obstacle) -> void:
	obstacles_live.erase(o)
	obstacle_pool.release(o)


func _remove_collectible(c: Collectible) -> void:
	collectibles_live.erase(c)
	collectible_pool.release(c)


func _release_all() -> void:
	for o in obstacles_live:
		obstacle_pool.release(o)
	obstacles_live.clear()
	for c in collectibles_live:
		collectible_pool.release(c)
	collectibles_live.clear()


# ---------- Visual ----------

func _refresh_bg() -> void:
	var d := distance_m()
	var idx := BiomeDB.index_for(d)
	var frac := fmod(d, BiomeDB.BIOME_LEN) / BiomeDB.BIOME_LEN
	var prev := (idx - 1 + BiomeDB.BIOMES.size()) % BiomeDB.BIOMES.size()
	var t := 1.0 if idx == 0 else clampf(frac / 0.2, 0.0, 1.0)
	bg.set_state(prev, idx, t, scrolled)


func _apply_shake(dt: float) -> void:
	_shake = maxf(0.0, _shake - dt * 40.0)
	if _shake > 0.0:
		stage.position = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake
	else:
		stage.position = Vector2.ZERO
