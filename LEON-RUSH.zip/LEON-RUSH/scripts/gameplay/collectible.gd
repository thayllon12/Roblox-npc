class_name Collectible
extends Node2D
## Carne (coletável principal) ou orbe de power-up. Pode ser atraído pelo ímã.

var kind := "common"
var is_orb := false
var track := 0.0
var h := 0.0
var pull := Vector2.ZERO
var _t := 0.0


func setup_meat(k: String, t: float, height: float) -> void:
	_setup(k, t, height, false)


func setup_orb(k: String, t: float, height: float) -> void:
	_setup(k, t, height, true)


func _setup(k: String, t: float, height: float, orb: bool) -> void:
	kind = k
	track = t
	h = height
	is_orb = orb
	pull = Vector2.ZERO
	_t = randf() * TAU
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta * 3.0
	queue_redraw()


func _draw() -> void:
	var bob := sin(_t) * 4.0
	var col: Color
	if is_orb:
		col = Color(GameCatalog.POWERUPS[kind]["color"])
		draw_circle(Vector2(0, bob), 30.0, Color(col, 0.2))
		draw_circle(Vector2(0, bob), 18.0, col)
		draw_arc(Vector2(0, bob), 23.0, 0.0, TAU, 24, Color.WHITE, 2.5)
		draw_arc(Vector2(0, bob), 10.0, 0.4, 2.6, 8, Color(1, 1, 1, 0.8), 2.5)
		return

	col = Color(GameCatalog.MEAT[kind]["color"])
	draw_circle(Vector2(0, bob), 26.0, Color(col.lightened(0.5), 0.25))
	# Osso
	draw_line(Vector2(12, bob), Vector2(23, bob - 6), Color(0.96, 0.94, 0.88), 4.0)
	draw_circle(Vector2(24, bob - 8), 3.5, Color(0.96, 0.94, 0.88))
	draw_circle(Vector2(24, bob - 3), 3.5, Color(0.96, 0.94, 0.88))
	# Carne
	draw_colored_polygon(_ellipse(Vector2(0, bob), 16.0, 11.0), col)
	draw_colored_polygon(_ellipse(Vector2(-4, bob - 3), 8.0, 4.0), col.lightened(0.3))
	draw_line(Vector2(-6, bob + 4), Vector2(4, bob + 2), col.darkened(0.3), 1.5)

	if kind == "golden" and sin(_t * 2.0) > 0.4:
		draw_line(Vector2(-22, bob - 14), Vector2(-14, bob - 14), Color.WHITE, 2.0)
		draw_line(Vector2(-18, bob - 18), Vector2(-18, bob - 10), Color.WHITE, 2.0)


static func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 16:
		var a := TAU * float(i) / 16.0
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	return pts
