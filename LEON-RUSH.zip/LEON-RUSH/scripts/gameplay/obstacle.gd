extends Area2D
class_name Obstacle
## Damages the player on contact. Supports slide-under.

@export var damage: int = 1
@export var can_slide_under: bool = false
@export var can_jump_over: bool = true

func _ready() -> void:
	monitoring = true
	monitorable = true
	body_entered.connect(_on_body_entered)
	collision_layer = 2
	collision_mask = 1

func _on_body_entered(body: Node2D) -> void:
	if body is Leon:
		var leon := body as Leon
		if can_slide_under and leon.is_sliding:
			return
		leon.take_damage()
		EventBus.obstacle_hit.emit()
