class_name Obstacle
extends Node2D
## Obstáculo com formato definido por altura inferior/superior (em px acima do chão).
## Obstáculos "branch" ficam no alto: é preciso deslizar por baixo deles.

const SHAPES := {
	"rock": {"w": 70.0, "bottom": 0.0, "top": 62.0},
	"log": {"w": 150.0, "bottom": 0.0, "top": 46.0},
	"spike": {"w": 52.0, "bottom": 0.0, "top": 34.0},
	"branch": {"w": 130.0, "bottom": 62.0, "top": 122.0},
}

var kind := "rock"
var track := 0.0
var _w := 70.0
var _bottom := 0.0
var _top := 62.0


func setup(k: String, t: float) -> void:
	kind = k
	track = t
	var s: Dictionary = SHAPES[k]
	_w = float(s["w"])
	_bottom = float(s["bottom"])
	_top = float(s["top"])
	queue_redraw()


## Retângulo de colisão em coordenadas do mundo. A posição é a base no chão.
func world_rect() -> Rect2:
	return Rect2(position.x - _w * 0.5, position.y - _top, _w, _top - _bottom)


func _draw() -> void:
	match kind:
		"rock":
			var pts := PackedVector2Array([
				Vector2(-_w * 0.5, 0), Vector2(-_w * 0.42, -_top * 0.55), Vector2(-_w * 0.12, -_top),
				Vector2(_w * 0.2, -_top * 0.92), Vector2(_w * 0.5, -_top * 0.4), Vector2(_w * 0.5, 0),
			])
			draw_colored_polygon(pts, Color("#7d7a80"))
			draw_colored_polygon(PackedVector2Array([
				Vector2(-_w * 0.12, -_top), Vector2(_w * 0.2, -_top * 0.92), Vector2(0, -_top * 0.4),
			]), Color("#a09ca3"))
		"log":
			draw_rect(Rect2(-_w * 0.5, -_top, _w, _top), Color("#8b5a2b"))
			draw_circle(Vector2(-_w * 0.5, -_top * 0.5), _top * 0.5, Color("#c08a4e"))
			draw_arc(Vector2(-_w * 0.5, -_top * 0.5), _top * 0.3, 0.0, TAU, 16, Color("#6b4423"), 2.0)
		"spike":
			for i in 3:
				var x := -_w * 0.5 + (float(i) + 0.5) * _w / 3.0
				draw_colored_polygon(PackedVector2Array([
					Vector2(x - 9, 0), Vector2(x, -_top), Vector2(x + 9, 0),
				]), Color("#6a994e"))
		"branch":
			draw_rect(Rect2(-_w * 0.5, -_top, _w, 16.0), Color("#6b4423"))
			for i in 5:
				var lx := -_w * 0.5 + 16.0 + float(i) * (_w - 32.0) / 4.0
				draw_circle(Vector2(lx, -_top + 24.0 + float(i % 2) * 12.0), 15.0, Color("#2d6a4f"))
