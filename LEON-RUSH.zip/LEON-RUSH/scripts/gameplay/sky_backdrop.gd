class_name SkyBackdrop
extends Node2D
## Céu em gradiente, colinas em parallax, decoração do bioma e partículas ambientais.

const W := 1280.0
const H := 720.0
const GROUND := 560.0

var prev_i := 0
var cur_i := 0
var blend := 1.0
var scroll := 0.0


func set_state(prev: int, cur: int, t: float, s: float) -> void:
	prev_i = prev
	cur_i = cur
	blend = t
	scroll = s
	queue_redraw()


func _c(key: String) -> Color:
	var a := Color(str(BiomeDB.BIOMES[prev_i][key]))
	var b := Color(str(BiomeDB.BIOMES[cur_i][key]))
	return a.lerp(b, blend)


func _draw() -> void:
	var top := _c("sky_top")
	var bot := _c("sky_bottom")
	for i in 12:
		var y0 := GROUND * float(i) / 12.0
		var y1 := GROUND * float(i + 1) / 12.0
		draw_rect(Rect2(0, y0, W, y1 - y0 + 1.0), top.lerp(bot, float(i) / 11.0))
	_hills(scroll * 0.12, _c("far"), 400.0, 70.0, 0.006)
	_decor(scroll * 0.35)
	_hills(scroll * 0.3, _c("near"), 480.0, 50.0, 0.011)
	draw_rect(Rect2(0, GROUND, W, H - GROUND), _c("ground"))
	var stripe := _c("accent")
	for i in 14:
		var x := fposmod(float(i) * 110.0 - scroll, W + 110.0) - 55.0
		draw_rect(Rect2(x, GROUND + 14.0, 60.0, 6.0), Color(stripe, 0.35))
	_particles()


func _hills(off: float, col: Color, base_y: float, amp: float, freq: float) -> void:
	var pts := PackedVector2Array()
	var x := -40.0
	while x <= W + 40.0:
		pts.append(Vector2(x, base_y - amp * (0.5 + 0.5 * sin(x * freq + off * 0.02))))
		x += 32.0
	pts.append(Vector2(W + 40.0, H))
	pts.append(Vector2(-40.0, H))
	draw_colored_polygon(pts, col)


func _decor(off: float) -> void:
	for i in 10:
		var x := fposmod(float(i) * 150.0 - off, W + 150.0) - 60.0
		match cur_i:
			0:
				draw_rect(Rect2(x - 6.0, 430.0, 12.0, 130.0), Color("#4a2c12"))
				draw_circle(Vector2(x, 420.0), 46.0, Color("#2d6a4f"))
			1:
				draw_rect(Rect2(x - 5.0, 440.0, 10.0, 120.0), Color("#7f4f24"))
				draw_rect(Rect2(x - 40.0, 428.0, 80.0, 14.0), Color("#588157"))
			2:
				var sz := 18.0 + float(i % 3) * 6.0
				draw_colored_polygon(PackedVector2Array([
					Vector2(x - sz, 0), Vector2(x + sz, 0), Vector2(x, 120.0 + float(i % 3) * 20.0),
				]), Color("#3a3f5c"))
				draw_colored_polygon(PackedVector2Array([
					Vector2(x, 470.0), Vector2(x + 14.0, 500.0), Vector2(x, 530.0), Vector2(x - 14.0, 500.0),
				]), Color("#8ecae6"))
			3:
				var smoke_y := 380.0 - fposmod(off * 0.5 + float(i) * 31.0, 90.0)
				draw_circle(Vector2(x, smoke_y), 22.0, Color(0.3, 0.25, 0.25, 0.6))
				draw_rect(Rect2(x - 30.0, 500.0, 60.0, 60.0), Color("#2a0f0f"))
			4:
				draw_rect(Rect2(x - 12.0, 340.0, 24.0, 220.0), Color("#d4a373"))
				draw_rect(Rect2(x - 20.0, 330.0, 40.0, 12.0), Color("#e9c46a"))


func _particles() -> void:
	var t := Time.get_ticks_msec() / 1000.0
	var col := _c("particle")
	for i in 36:
		var y := fposmod(float(i) * 53.1 + t * (18.0 + float(i % 5) * 6.0), H)
		var x := fposmod(float(i) * 97.3 - scroll * 0.25 - t * 10.0, W)
		draw_circle(Vector2(x, y), 2.0 + float(i % 3), Color(col, 0.5))
