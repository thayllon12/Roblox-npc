class_name BiomeDB
extends RefCounted
## Biomas trocam a cada BIOME_LEN metros, com transição suave de cores.

const BIOME_LEN := 600.0

const BIOMES := [
	{"name": "Selva", "sky_top": "#1b4332", "sky_bottom": "#74c69d", "far": "#2d6a4f", "near": "#1b4332", "ground": "#386641", "accent": "#b7e4c7", "particle": "#d8f3dc"},
	{"name": "Savana", "sky_top": "#f4a261", "sky_bottom": "#ffe8a1", "far": "#e76f51", "near": "#bc6c25", "ground": "#dda15e", "accent": "#fefae0", "particle": "#fefae0"},
	{"name": "Caverna", "sky_top": "#0b0c1e", "sky_bottom": "#2b2d42", "far": "#3a3f5c", "near": "#22233a", "ground": "#4a4e69", "accent": "#8ecae6", "particle": "#90e0ef"},
	{"name": "Vulcão", "sky_top": "#2b0a0a", "sky_bottom": "#ff7b00", "far": "#4a1c1c", "near": "#1f0f0f", "ground": "#3d2b2b", "accent": "#ff4d00", "particle": "#ffb703"},
	{"name": "Ruínas", "sky_top": "#3c2f2f", "sky_bottom": "#e9c46a", "far": "#6d597a", "near": "#355070", "ground": "#7f5539", "accent": "#ffcb77", "particle": "#f4e285"},
]


static func index_for(distance_m: float) -> int:
	return int(distance_m / BIOME_LEN) % BIOMES.size()


static func name_for(index: int) -> String:
	return str(BIOMES[index]["name"])
