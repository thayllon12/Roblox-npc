extends Area2D
class_name Meat
## Collectible meat piece with float animation and magnet support.

enum MeatType { COMMON, GOLDEN, RARE, SPECIAL, ENERGY }

@export var meat_type: MeatType = MeatType.COMMON
@export var value: int = 1
@export var float_amplitude: float = 7.0
@export var float_speed: float = 3.2

var base_y: float = 0.0
var time: float = 0.0
var is_collected: bool = false
var magnet_active: bool = false
var magnet_target: Node2D = null

func _ready() -> void:
	base_y = position.y
	body_entered.connect(_on_body_entered)
	_apply_type_visual()

func _apply_type_visual() -> void:
	match meat_type:
		MeatType.COMMON:
			value = 1
		MeatType.GOLDEN:
			value = 5
		MeatType.RARE:
			value = 10
		MeatType.SPECIAL:
			value = 25
		MeatType.ENERGY:
			value = 3

func _process(delta: float) -> void:
	if is_collected:
		return
	time += delta
	position.y = base_y + sin(time * float_speed) * float_amplitude
	rotation = sin(time * 1.6) * 0.18

	if magnet_active and is_instance_valid(magnet_target):
		var dir := (magnet_target.global_position - global_position).normalized()
		position += dir * 480.0 * delta
		base_y = position.y

func _on_body_entered(body: Node2D) -> void:
	if is_collected:
		return
	if body is Leon or body.is_in_group("player"):
		collect(body)

func collect(collector: Node2D = null) -> void:
	if is_collected:
		return
	is_collected = true

	var parts := get_node_or_null("CollectParticles") as GPUParticles2D
	if parts:
		parts.emitting = true

	if collector and collector.has_method("collect_meat"):
		collector.collect_meat(value, _type_to_string())
	else:
		GameManager.add_meat(value, _type_to_string())

	for child in get_children():
		if child is ColorRect or child is Sprite2D:
			child.visible = false

	await get_tree().create_timer(0.35).timeout
	queue_free()

func _type_to_string() -> String:
	match meat_type:
		MeatType.COMMON: return "common"
		MeatType.GOLDEN: return "golden"
		MeatType.RARE: return "rare"
		MeatType.SPECIAL: return "special"
		MeatType.ENERGY: return "energy"
	return "common"

func activate_magnet(target: Node2D) -> void:
	magnet_active = true
	magnet_target = target
