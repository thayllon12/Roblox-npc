extends Node
## Touch swipe + keyboard input for Leon.

signal jump_requested
signal slide_requested
signal special_requested

@export var swipe_threshold: float = 36.0
@export var max_swipe_time: float = 0.32
@export var min_swipe_distance: float = 28.0

var touch_start_pos: Vector2 = Vector2.ZERO
var touch_start_time: float = 0.0
var is_touching: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func _input(event: InputEvent) -> void:
	# Always allow pause
	if event.is_action_pressed("pause"):
		if GameManager.get_state() == GameManager.GameState.PLAYING:
			GameManager.pause_game()
		elif GameManager.get_state() == GameManager.GameState.PAUSED:
			GameManager.resume_game()
		return

	if GameManager.get_state() != GameManager.GameState.PLAYING:
		return

	# Keyboard
	if event.is_action_pressed("jump"):
		jump_requested.emit()
	elif event.is_action_pressed("slide"):
		slide_requested.emit()
	elif event.is_action_pressed("special"):
		special_requested.emit()

	# Touch
	if event is InputEventScreenTouch:
		_handle_touch(event)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var fake := InputEventScreenTouch.new()
		fake.pressed = event.pressed
		fake.position = event.position
		_handle_touch(fake)

func _handle_touch(event: InputEventScreenTouch) -> void:
	if event.pressed:
		is_touching = true
		touch_start_pos = event.position
		touch_start_time = Time.get_ticks_msec() / 1000.0
	else:
		if not is_touching:
			return
		is_touching = false
		var elapsed: float = (Time.get_ticks_msec() / 1000.0) - touch_start_time
		if elapsed > max_swipe_time:
			return
		var delta: Vector2 = event.position - touch_start_pos
		var abs_x := absf(delta.x)
		var abs_y := absf(delta.y)

		if abs_y >= min_swipe_distance and abs_y > abs_x * 0.85:
			if delta.y < 0.0:
				jump_requested.emit()
			else:
				slide_requested.emit()
		elif abs_x < swipe_threshold * 0.4 and abs_y < swipe_threshold * 0.4:
			# Short tap — reserved for special / context
			special_requested.emit()
