extends Node2D
## Swaps Leon sprite frames based on character state.

@onready var sprite: Sprite2D = $Sprite2D
@onready var leon: Leon = get_parent() as Leon

var frames: Dictionary = {}
var run_index: int = 0
var run_timer: float = 0.0
const RUN_FRAME_TIME := 0.09

func _ready() -> void:
	_load_frames()
	if leon:
		leon.state_changed.connect(_on_state_changed)
	_on_state_changed(leon.state if leon else Leon.State.IDLE)

func _load_frames() -> void:
	var base := "res://assets/characters/leon/"
	var names := ["idle", "run1", "run2", "run3", "jump", "fall", "slide", "hurt", "death"]
	for n in names:
		var path := base + n + ".png"
		if ResourceLoader.exists(path):
			frames[n] = load(path)

func _process(delta: float) -> void:
	if not leon or not sprite:
		return
	if leon.state == Leon.State.RUNNING:
		run_timer += delta
		if run_timer >= RUN_FRAME_TIME:
			run_timer = 0.0
			run_index = (run_index + 1) % 3
			_set_frame(["run1", "run2", "run3"][run_index])

func _on_state_changed(new_state: Leon.State) -> void:
	run_timer = 0.0
	match new_state:
		Leon.State.IDLE:
			_set_frame("idle")
		Leon.State.RUNNING:
			_set_frame("run1")
		Leon.State.JUMPING:
			_set_frame("jump")
		Leon.State.FALLING:
			_set_frame("fall")
		Leon.State.SLIDING:
			_set_frame("slide")
		Leon.State.HURT:
			_set_frame("hurt")
		Leon.State.DEAD:
			_set_frame("death")

func _set_frame(name: String) -> void:
	if frames.has(name) and sprite:
		sprite.texture = frames[name]
		sprite.centered = true
		sprite.offset = Vector2(0, -8)
