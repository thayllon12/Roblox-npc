class_name InputController
extends Node
## Converte toques, swipes, teclado e mouse em ações do jogo.
## Sempre ativo (process_mode ALWAYS) para funcionar também com o jogo pausado.

signal jump_requested
signal slide_requested
signal tap_requested
signal pause_requested

const SWIPE_MIN := 42.0    ## px mínimos para contar como swipe
const TAP_MAX := 24.0      ## px máximos de movimento para contar como toque

var _pressed := false
var _press_pos := Vector2.ZERO


func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key != null:
		if key.pressed and not key.echo:
			match key.keycode:
				KEY_UP, KEY_W:
					jump_requested.emit()
				KEY_DOWN, KEY_S:
					slide_requested.emit()
				KEY_SPACE, KEY_E:
					tap_requested.emit()
				KEY_ESCAPE, KEY_P:
					pause_requested.emit()
		return

	var pos := Vector2.ZERO
	var pressed_now := false
	var released_now := false
	var touch := event as InputEventScreenTouch
	var mouse := event as InputEventMouseButton
	if touch != null:
		pos = touch.position
		pressed_now = touch.pressed
		released_now = not touch.pressed
	elif mouse != null and mouse.button_index == MOUSE_BUTTON_LEFT:
		pos = mouse.position
		pressed_now = mouse.pressed
		released_now = not mouse.pressed
	else:
		return

	if pressed_now:
		_pressed = true
		_press_pos = pos
	elif released_now and _pressed:
		_pressed = false
		_classify(pos - _press_pos)


func _classify(delta: Vector2) -> void:
	if delta.length() < TAP_MAX:
		tap_requested.emit()
		return
	var vertical_dominant := absf(delta.y) >= absf(delta.x)
	if vertical_dominant and absf(delta.y) >= SWIPE_MIN:
		if delta.y < 0.0:
			jump_requested.emit()
		else:
			slide_requested.emit()
		return
	# Movimento curto e diagonal: tolerância a erros de toque, tratado como toque.
	tap_requested.emit()
