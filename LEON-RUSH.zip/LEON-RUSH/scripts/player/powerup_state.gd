class_name PowerupState
extends RefCounted
## Orbes coletados ficam guardados em slots. O botão ESPECIAL ativa o primeiro slot,
## com cooldown entre ativações. Efeitos ativos têm duração que é contada a cada frame.

const MAX_SLOTS := 2
const COOLDOWN := 3.0

var slots: Array = []
var active: Dictionary = {}
var cooldown := 0.0


func reset() -> void:
	slots.clear()
	active.clear()
	cooldown = 0.0


func tick(delta: float) -> void:
	cooldown = maxf(0.0, cooldown - delta)
	for kind in active.keys():
		active[kind] -= delta
		if active[kind] <= 0.0:
			active.erase(kind)


func add_slot(kind: String) -> void:
	if slots.size() >= MAX_SLOTS:
		slots.pop_front()
	slots.append(kind)


func can_activate() -> bool:
	return not slots.is_empty() and cooldown <= 0.0


## Ativa o primeiro power-up guardado. Retorna o tipo ativado ou "" se não for possível.
func activate() -> String:
	if not can_activate():
		return ""
	var kind: String = slots.pop_front()
	active[kind] = float(GameCatalog.POWERUPS[kind]["duration"])
	cooldown = COOLDOWN
	return kind


func is_active(kind: String) -> bool:
	return active.has(kind)


func time_left(kind: String) -> float:
	return float(active.get(kind, 0.0))


func consume_shield() -> void:
	active.erase("shield")
