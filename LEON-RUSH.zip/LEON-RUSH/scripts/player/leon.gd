extends CharacterBody2D
class_name Leon
## Main player character — Leon the Lion.
## Full state machine with polished platformer physics for endless runner.

signal died
signal collected_meat(amount: int, type: String)
signal hit_obstacle
signal state_changed(new_state: State)

enum State { IDLE, RUNNING, JUMPING, FALLING, SLIDING, HURT, DEAD }

# --- Tunable physics ---
@export_group("Movement")
@export var run_speed: float = 320.0
@export var jump_force: float = 680.0
@export var gravity: float = 2100.0
@export var fall_gravity_multiplier: float = 1.35
@export var max_fall_speed: float = 1400.0

@export_group("Jump Feel")
@export var coyote_time: float = 0.12
@export var jump_buffer_time: float = 0.12
@export var max_jumps: int = 1

@export_group("Slide")
@export var slide_duration: float = 0.55
@export var slide_speed_bonus: float = 40.0

@export_group("Visual")
@export var squash_amount: float = 0.18
@export var stretch_amount: float = 0.12

# --- Runtime state ---
var state: State = State.IDLE
var jumps_remaining: int = 1
var is_sliding: bool = false
var slide_timer: float = 0.0
var coyote_timer: float = 0.0
var jump_buffer_timer: float = 0.0
var is_invincible: bool = false
var has_shield: bool = false
var speed_multiplier: float = 1.0
var base_jump_force: float = 680.0

# Visual references
@onready var body_visual: ColorRect = $BodyVisual
@onready var mane: ColorRect = $Mane
@onready var tail: ColorRect = $Tail
@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var slide_collision: CollisionShape2D = $SlideCollision
@onready var dust_particles: GPUParticles2D = $DustParticles
@onready var land_particles: GPUParticles2D = $LandParticles
@onready var anim_player: AnimationPlayer = $AnimationPlayer

# Secondary motion
var mane_offset: float = 0.0
var tail_offset: float = 0.0
var visual_scale: Vector2 = Vector2.ONE
var target_visual_scale: Vector2 = Vector2.ONE

func _ready() -> void:
	base_jump_force = jump_force
	_set_state(State.IDLE)
	EventBus.powerup_activated.connect(_on_powerup_activated)
	EventBus.powerup_expired.connect(_on_powerup_expired)
	# Ensure collision layers
	collision_layer = 1
	collision_mask = 8 | 2  # ground + obstacles

func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	_update_timers(delta)
	_apply_gravity(delta)
	_apply_horizontal_movement()
	_try_buffered_jump()
	move_and_slide()
	_post_move_checks()
	_update_secondary_motion(delta)
	_update_visual_squash(delta)
	_update_particles()

func _update_timers(delta: float) -> void:
	if is_on_floor():
		coyote_timer = coyote_time
		jumps_remaining = max_jumps
	else:
		coyote_timer = max(0.0, coyote_timer - delta)

	jump_buffer_timer = max(0.0, jump_buffer_timer - delta)

	if is_sliding:
		slide_timer -= delta
		if slide_timer <= 0.0:
			_end_slide()

func _apply_gravity(delta: float) -> void:
	if is_on_floor() and state != State.JUMPING:
		return
	var g := gravity
	if velocity.y > 0.0:
		g *= fall_gravity_multiplier
	velocity.y += g * delta
	velocity.y = min(velocity.y, max_fall_speed)

func _apply_horizontal_movement() -> void:
	if state == State.DEAD or state == State.HURT:
		velocity.x = 0.0
		return
	# Base speed + difficulty scaling from GameManager
	var difficulty_bonus := clampf(GameManager.difficulty_level * 8.0, 0.0, 280.0)
	var target_speed := (run_speed + difficulty_bonus) * speed_multiplier
	if is_sliding:
		target_speed += slide_speed_bonus
	velocity.x = target_speed

func _try_buffered_jump() -> void:
	if jump_buffer_timer > 0.0 and (coyote_timer > 0.0 or jumps_remaining > 0):
		_do_jump()

func jump() -> void:
	# Public method called by input
	if state == State.DEAD or state == State.HURT:
		return
	jump_buffer_timer = jump_buffer_time
	_try_buffered_jump()

func _do_jump() -> void:
	if jumps_remaining <= 0 and coyote_timer <= 0.0:
		return
	velocity.y = -jump_force
	jumps_remaining = max(0, jumps_remaining - 1)
	coyote_timer = 0.0
	jump_buffer_timer = 0.0
	if is_sliding:
		_end_slide()
	_set_state(State.JUMPING)
	target_visual_scale = Vector2(1.0 - stretch_amount, 1.0 + stretch_amount * 1.4)

func slide() -> void:
	if state == State.DEAD or state == State.HURT:
		return
	if not is_on_floor() and coyote_timer <= 0.0:
		return
	if is_sliding:
		return
	is_sliding = true
	slide_timer = slide_duration
	_set_state(State.SLIDING)
	collision.disabled = true
	slide_collision.disabled = false
	target_visual_scale = Vector2(1.0 + squash_amount * 1.2, 1.0 - squash_amount)

func _end_slide() -> void:
	is_sliding = false
	collision.disabled = false
	slide_collision.disabled = true
	if is_on_floor():
		_set_state(State.RUNNING)
	else:
		_set_state(State.FALLING)
	target_visual_scale = Vector2.ONE

func _post_move_checks() -> void:
	if state == State.DEAD:
		return
	if is_on_floor():
		if state == State.FALLING or state == State.JUMPING:
			_land()
		elif state != State.SLIDING and state != State.RUNNING:
			_set_state(State.RUNNING)
	else:
		if velocity.y > 80.0 and state != State.SLIDING:
			_set_state(State.FALLING)
		elif velocity.y < -10.0 and state != State.JUMPING and state != State.SLIDING:
			_set_state(State.JUMPING)

func _land() -> void:
	if is_sliding:
		return
	_set_state(State.RUNNING)
	target_visual_scale = Vector2(1.0 + squash_amount, 1.0 - squash_amount * 0.8)
	if land_particles:
		land_particles.restart()
		land_particles.emitting = true

func take_damage() -> void:
	if is_invincible or state == State.DEAD:
		return
	if has_shield:
		has_shield = false
		EventBus.powerup_expired.emit("shield")
		# brief invincibility after shield break
		is_invincible = true
		get_tree().create_timer(0.6).timeout.connect(func(): is_invincible = false)
		return
	_set_state(State.HURT)
	die()

func die() -> void:
	_set_state(State.DEAD)
	velocity = Vector2.ZERO
	is_sliding = false
	collision.disabled = false
	slide_collision.disabled = true
	if dust_particles:
		dust_particles.emitting = false
	died.emit()
	EventBus.player_died.emit()

func collect_meat(amount: int = 1, meat_type: String = "common") -> void:
	collected_meat.emit(amount, meat_type)
	GameManager.add_meat(amount, meat_type)

func _set_state(new_state: State) -> void:
	if state == new_state:
		return
	state = new_state
	state_changed.emit(new_state)

func _update_secondary_motion(delta: float) -> void:
	# Mane and tail lag behind for secondary motion feel
	var speed_factor := clampf(velocity.x / 400.0, 0.3, 1.5)
	mane_offset = lerp(mane_offset, -velocity.y * 0.012 * speed_factor, 12.0 * delta)
	tail_offset = lerp(tail_offset, velocity.y * 0.018 * speed_factor, 9.0 * delta)
	if mane:
		mane.position.y = -78.0 + mane_offset
		mane.rotation = mane_offset * 0.04
	if tail:
		tail.position.y = -20.0 + tail_offset * 0.5
		tail.rotation = tail_offset * 0.06

func _update_visual_squash(delta: float) -> void:
	visual_scale = visual_scale.lerp(target_visual_scale, 14.0 * delta)
	target_visual_scale = target_visual_scale.lerp(Vector2.ONE, 6.0 * delta)
	var vis := get_node_or_null("Visual") as Node2D
	if vis:
		vis.scale = visual_scale
		vis.position.y = 8.0 * (1.0 - visual_scale.y)
	elif body_visual:
		body_visual.scale = visual_scale
		body_visual.position.y = -64.0 * visual_scale.y + (64.0 * (1.0 - visual_scale.y))
	if mane and mane.visible:
		mane.scale = visual_scale

func _update_particles() -> void:
	if dust_particles:
		var should_emit := is_on_floor() and state == State.RUNNING and abs(velocity.x) > 50.0
		dust_particles.emitting = should_emit

func _on_powerup_activated(type: String, _duration: float) -> void:
	match type:
		"shield":
			has_shield = true
		"invincibility":
			is_invincible = true
		"speed_boost":
			speed_multiplier = 1.45
		"mega_jump":
			jump_force = base_jump_force * 1.35

func _on_powerup_expired(type: String) -> void:
	match type:
		"shield":
			has_shield = false
		"invincibility":
			is_invincible = false
		"speed_boost":
			speed_multiplier = 1.0
		"mega_jump":
			jump_force = base_jump_force

func get_run_speed() -> float:
	return run_speed * speed_multiplier
