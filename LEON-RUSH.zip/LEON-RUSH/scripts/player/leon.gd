class_name Leon
extends Node2D
## O leão. Corre no lugar (o mundo passa por ele), pula, desliza e morre.
## A posição de Leon é fixa na tela; a altura é controlada por física simples.
## O visual é desenhado por código, sem assets externos.

signal landed(impact: float)

enum State { RUN, JUMP, FALL, SLIDE, DEAD }

const GRAVITY := 2600.0
const JUMP_SPEED := 980.0
const FAST_FALL := 1500.0
const SLIDE_TIME := 0.7
const STAND_H := 92.0
const SLIDE_H := 40.0
const HIT_W := 50.0
const SLIDE_HIT_W := 58.0

var height := 0.0          ## px acima do chão
var vel := 0.0             ## px/s, positivo = subindo
var state: State = State.RUN
var slide_timer := 0.0
var jump_mult := 1.0
var shield := false
var invincible := false
var speed_ratio := 1.0
var loadout: Dictionary = {}
var fx: ParticleFX

var _anim := 0.0
var _phase := 0.0
var _squash := Vector2.ONE
var _flash := 0.0
var _dust_timer := 0.0


func reset() -> void:
	height = 0.0
	vel = 0.0
	state = State.RUN
	slide_timer = 0.0
	jump_mult = 1.0
	shield = false
	invincible = false
	_squash = Vector2.ONE
	_flash = 0.0
	rotation = 0.0
	queue_redraw()


func set_loadout(data: Dictionary) -> void:
	loadout = data
	queue_redraw()


func is_grounded() -> bool:
	return height <= 0.0 and vel == 0.0


## Pulo: só a partir do chão. Não existe pulo duplo. Retorna true se pulou.
func request_jump() -> bool:
	if state == State.DEAD or not is_grounded():
		return false
	vel = JUMP_SPEED * jump_mult
	state = State.JUMP
	slide_timer = 0.0
	_squash = Vector2(0.7, 1.35)
	return true


## Deslize no chão. No ar, vira uma queda rápida.
func request_slide() -> bool:
	if state == State.DEAD:
		return false
	if is_grounded():
		state = State.SLIDE
		slide_timer = SLIDE_TIME
		_squash = Vector2(1.25, 0.65)
	else:
		vel = -FAST_FALL
		state = State.FALL
	return true


func die() -> void:
	state = State.DEAD
	vel = 520.0
	_flash = 0.5


## Retângulo de colisão em coordenadas do mundo.
func hit_rect() -> Rect2:
	var sliding := state == State.SLIDE
	var h := SLIDE_H if sliding else STAND_H
	var w := SLIDE_HIT_W if sliding else HIT_W
	return Rect2(position.x - w * 0.5, position.y - height - h, w, h)


func step(delta: float) -> void:
	_anim += delta
	_squash = _squash.lerp(Vector2.ONE, minf(1.0, delta * 9.0))
	_flash = maxf(0.0, _flash - delta)

	if state == State.DEAD:
		rotation = minf(rotation + delta * 5.0, PI * 0.5)
		_apply_air(delta)
		queue_redraw()
		return

	if state == State.SLIDE:
		slide_timer -= delta
		if slide_timer <= 0.0:
			state = State.RUN

	if state == State.RUN and is_grounded():
		_phase += delta * 10.0 * speed_ratio
		_emit_dust(delta)

	_apply_air(delta)
	queue_redraw()


func _apply_air(delta: float) -> void:
	if height <= 0.0 and vel == 0.0:
		return
	vel -= GRAVITY * delta
	height += vel * delta
	if vel < 0.0 and state == State.JUMP:
		state = State.FALL
	if height <= 0.0:
		height = 0.0
		var impact := -vel
		vel = 0.0
		if state == State.DEAD:
			return
		if impact > 200.0:
			_squash = Vector2(1.3, 0.7)
			landed.emit(impact)
			_landing_fx()
		if state != State.SLIDE:
			state = State.RUN


func _emit_dust(delta: float) -> void:
	if fx == null:
		return
	_dust_timer -= delta
	if _dust_timer <= 0.0:
		_dust_timer = 0.11 / maxf(speed_ratio, 0.5)
		var col: Color = loadout.get("trail", Color("#e8c79a"))
		fx.emit_burst(position + Vector2(-34, -4), col, 2, 70.0, 0.35, 4.0)


func _landing_fx() -> void:
	if fx == null:
		return
	var col: Color = loadout.get("trail", Color("#e8c79a"))
	fx.emit_burst(position + Vector2(0, -2), col, 10, 170.0, 0.4, 4.5)


func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, _squash)
	var mane_c: Color = loadout.get("mane", Color("#b5651d"))
	var body_c: Color = loadout.get("body", Color("#e7a84b"))
	var lift := -height
	var running := state == State.RUN and height <= 0.0
	var bob := absf(sin(_phase)) * -5.0 if running else 0.0
	var c := Vector2(0.0, lift - 64.0 + bob)

	# Sombra no chão
	var shadow_r := clampf(60.0 - height * 0.15, 22.0, 60.0)
	draw_colored_polygon(_ellipse(Vector2(0, 2), shadow_r, 9.0), Color(0, 0, 0, 0.25))

	# Auras de power-up
	if invincible:
		draw_circle(c, 100.0, Color(1.0, 0.85, 0.2, 0.2 + 0.08 * sin(_anim * 12.0)))
	if shield:
		draw_arc(c, 96.0, 0.0, TAU, 48, Color(0.5, 1.0, 0.6, 0.85), 6.0)

	# Cauda com movimento secundário
	var sway := sin(_anim * 7.0) * 10.0
	var tb := c + Vector2(-44, 6)
	var tail := PackedVector2Array([tb, tb + Vector2(-26, -16 + sway * 0.4), tb + Vector2(-44, -40 + sway)])
	draw_polyline(tail, body_c.darkened(0.1), 9.0, true)
	draw_circle(tail[2], 12.0, mane_c)

	# Patas
	var stride := sin(_phase) * 14.0 if running else 0.0
	var hip_y := c.y + 28.0
	for leg in [Vector2(26, stride), Vector2(-22, -stride), Vector2(14, -stride * 0.5), Vector2(-8, stride * 0.5)]:
		var hip := Vector2(leg.x * 0.6, hip_y)
		var foot := Vector2(leg.x + leg.y * 0.5, lift - 4.0)
		draw_line(hip, foot, body_c.darkened(0.2), 16.0)
		draw_circle(foot, 9.5, body_c.darkened(0.3))

	# Corpo
	draw_colored_polygon(_ellipse(c, 54.0, 36.0), body_c)
	draw_colored_polygon(_ellipse(c + Vector2(4, 10), 32.0, 20.0), body_c.lightened(0.2))

	# Juba e cabeça
	var hd := c + Vector2(36, -28)
	for i in 20:
		var a := TAU * float(i) / 20.0
		var r := 44.0 + sin(float(i) * 2.3 + _anim * 3.0) * 4.0
		draw_circle(hd + Vector2(cos(a), sin(a)) * r, 17.0, mane_c)
	draw_circle(hd, 36.0, body_c)

	# Rosto
	var eye_y := hd.y - 6.0
	var show_x := state == State.DEAD or _flash > 0.0
	var blink := fmod(_anim, 3.4) < 0.1
	for ex in [-13.0, 13.0]:
		var ep := Vector2(hd.x + ex, eye_y)
		if show_x:
			draw_line(ep + Vector2(-6, -6), ep + Vector2(6, 6), Color.BLACK, 3.0)
			draw_line(ep + Vector2(-6, 6), ep + Vector2(6, -6), Color.BLACK, 3.0)
		elif blink:
			draw_line(ep + Vector2(-7, 0), ep + Vector2(7, 0), Color(0.15, 0.1, 0.05), 3.0)
		else:
			draw_circle(ep, 8.5, Color.WHITE)
			draw_circle(ep + Vector2(1.5, 1.5), 4.5, Color(0.1, 0.07, 0.04))
			draw_circle(ep + Vector2(3, -1), 1.6, Color.WHITE)
	draw_colored_polygon(_ellipse(hd + Vector2(0, 10), 18.0, 13.0), body_c.lightened(0.25))
	draw_colored_polygon(_ellipse(hd + Vector2(0, 6), 6.0, 4.5), Color(0.25, 0.14, 0.08))
	if state == State.JUMP or state == State.FALL:
		draw_circle(hd + Vector2(0, 19), 6.0, Color(0.5, 0.1, 0.15))
	else:
		draw_arc(hd + Vector2(0, 14), 8.0, 0.2, PI - 0.2, 10, Color(0.25, 0.14, 0.08), 2.5)

	# Acessórios
	var acc: String = loadout.get("accessory", "")
	if acc == "crown":
		var cp := hd + Vector2(-20, -34)
		var crown := PackedVector2Array([cp, cp + Vector2(0, -20), cp + Vector2(10, -8), cp + Vector2(20, -24), cp + Vector2(30, -8), cp + Vector2(40, -20), cp + Vector2(40, 0)])
		draw_colored_polygon(crown, Color("#ffd166"))
	elif acc == "bandana":
		draw_line(hd + Vector2(-34, -16), hd + Vector2(34, -12), Color("#e63946"), 9.0)
		draw_circle(hd + Vector2(36, -12), 6.0, Color("#e63946"))

	# Efeito de cauda estelar
	if loadout.get("effect", "") == "sparkle":
		for i in 3:
			var sp := hd + Vector2(cos(_anim * 2.0 + i * 2.1) * 62.0, sin(_anim * 3.0 + i * 1.7) * 50.0)
			draw_circle(sp, 3.0, Color(1, 1, 0.7, 0.85))

	# Flash de dano
	if _flash > 0.0:
		draw_colored_polygon(_ellipse(c, 60.0, 44.0), Color(1, 1, 1, _flash))


static func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 24:
		var a := TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	return pts
