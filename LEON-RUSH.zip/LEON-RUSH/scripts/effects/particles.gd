class_name ParticleFX
extends Node2D
## Partículas simples com limite máximo. A quantidade é reduzida conforme a qualidade gráfica.

const MAX_PARTICLES := 180

var quality_scale := 1.0
var _items: Array = []


func clear() -> void:
	_items.clear()
	queue_redraw()


func emit_burst(pos: Vector2, color: Color, count: int, speed: float, life: float, size: float) -> void:
	var n := maxi(1, int(round(float(count) * quality_scale)))
	for i in n:
		if _items.size() >= MAX_PARTICLES:
			_items.pop_front()
		var ang := randf() * TAU
		var v := Vector2(cos(ang), sin(ang)) * randf_range(0.3, 1.0) * speed
		_items.append({"p": pos, "v": v, "life": life, "max": life, "c": color, "s": size})


func _process(delta: float) -> void:
	if _items.is_empty():
		return
	for it in _items:
		it["life"] = float(it["life"]) - delta
		it["p"] = it["p"] + it["v"] * delta
		it["v"] = it["v"] * 0.96 + Vector2(0, 260.0) * delta
	_items = _items.filter(func(it): return float(it["life"]) > 0.0)
	queue_redraw()


func _draw() -> void:
	for it in _items:
		var a := float(it["life"]) / float(it["max"])
		draw_circle(it["p"], float(it["s"]) * (0.4 + 0.6 * a), Color(it["c"], a))
