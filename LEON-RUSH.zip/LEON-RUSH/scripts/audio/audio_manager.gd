extends Node
## Central audio controller. Uses AudioStreamPlayer nodes created at runtime.

var music_player: AudioStreamPlayer
var sfx_players: Array[AudioStreamPlayer] = []
const SFX_POOL_SIZE := 8

var music_enabled: bool = true
var sfx_enabled: bool = true
var music_volume: float = 0.8
var sfx_volume: float = 1.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_create_players()
	_load_settings()
	EventBus.settings_changed.connect(_on_settings_changed)

func _create_players() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.bus = "Master"
	add_child(music_player)

	for i in SFX_POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		sfx_players.append(p)

func _load_settings() -> void:
	music_enabled = SaveManager.get_setting("music_enabled", true)
	sfx_enabled = SaveManager.get_setting("sfx_enabled", true)
	music_volume = SaveManager.get_setting("music_volume", 0.8)
	sfx_volume = SaveManager.get_setting("sfx_volume", 1.0)
	_apply_volumes()

func _on_settings_changed() -> void:
	_load_settings()

func _apply_volumes() -> void:
	if music_player:
		music_player.volume_db = linear_to_db(music_volume) if music_enabled else -80.0
	for p in sfx_players:
		p.volume_db = linear_to_db(sfx_volume) if sfx_enabled else -80.0

func play_music(stream: AudioStream, fade: bool = true) -> void:
	if not music_enabled or stream == null:
		return
	if music_player.stream == stream and music_player.playing:
		return
	music_player.stream = stream
	music_player.play()

func stop_music() -> void:
	music_player.stop()

func play_sfx(stream: AudioStream, volume_scale: float = 1.0) -> void:
	if not sfx_enabled or stream == null:
		return
	for p in sfx_players:
		if not p.playing:
			p.stream = stream
			p.volume_db = linear_to_db(sfx_volume * volume_scale)
			p.play()
			return
	# All busy — reuse first
	sfx_players[0].stream = stream
	sfx_players[0].play()

func set_music_enabled(enabled: bool) -> void:
	music_enabled = enabled
	SaveManager.set_setting("music_enabled", enabled)
	SaveManager.save_game()
	_apply_volumes()

func set_sfx_enabled(enabled: bool) -> void:
	sfx_enabled = enabled
	SaveManager.set_setting("sfx_enabled", enabled)
	SaveManager.save_game()
	_apply_volumes()
