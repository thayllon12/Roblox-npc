extends Node
## Raiz do jogo. Liga o mundo de corrida, a entrada e todas as telas da interface.
## A pausa real é feita com get_tree().paused: tudo que é pausável congela, inclusive física e timers.

var world: GameWorld
var input: InputController
var menu: MainMenu
var hud: HUD
var pause_menu: PauseMenu
var game_over: GameOver
var shop: ShopScreen
var missions: MissionsScreen
var settings: SettingsScreen

var _ui: CanvasLayer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	world = GameWorld.new()
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(world)
	world.run_ended.connect(_on_run_ended)

	_ui = CanvasLayer.new()
	_ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_ui)

	input = InputController.new()
	input.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(input)
	input.jump_requested.connect(_on_jump)
	input.slide_requested.connect(_on_slide)
	input.tap_requested.connect(_on_tap)
	input.pause_requested.connect(_on_pause_key)

	menu = MainMenu.new()
	_ui.add_child(menu)
	menu.navigate.connect(_on_menu_navigate)

	hud = HUD.new()
	hud.world = world
	_ui.add_child(hud)
	hud.pause_pressed.connect(pause_game)
	hud.special_pressed.connect(world.activate_special)

	pause_menu = PauseMenu.new()
	_ui.add_child(pause_menu)
	pause_menu.resume_requested.connect(resume_game)
	pause_menu.restart_requested.connect(start_game)
	pause_menu.menu_requested.connect(go_menu)

	game_over = GameOver.new()
	_ui.add_child(game_over)
	game_over.retry_requested.connect(start_game)
	game_over.home_requested.connect(go_menu)

	shop = ShopScreen.new()
	_ui.add_child(shop)
	shop.back.connect(_show_menu)

	missions = MissionsScreen.new()
	_ui.add_child(missions)
	missions.back.connect(_show_menu)

	settings = SettingsScreen.new()
	_ui.add_child(settings)
	settings.back.connect(_show_menu)

	_show_menu()
	Audio.play_music("menu")


# ---------- Navegação ----------

func _on_menu_navigate(target: String) -> void:
	match target:
		"play":
			start_game()
		"shop":
			_show_screen(shop)
		"missions":
			_show_screen(missions)
		"settings":
			_show_screen(settings)


func _show_screen(screen: Control) -> void:
	for s in [menu, shop, missions, settings]:
		s.visible = s == screen
	hud.visible = false
	pause_menu.visible = false
	game_over.visible = false
	if screen.has_method("refresh"):
		screen.refresh()


func _show_menu() -> void:
	get_tree().paused = false
	_show_screen(menu)


func start_game() -> void:
	get_tree().paused = false
	Audio.set_music_paused(false)
	for s in [menu, shop, missions, settings, pause_menu, game_over]:
		s.visible = false
	hud.visible = true
	world.start_run()
	Audio.play_music("game")


func pause_game() -> void:
	if not world.is_running() or get_tree().paused:
		return
	get_tree().paused = true
	Audio.set_music_paused(true)
	pause_menu.visible = true


func resume_game() -> void:
	if not get_tree().paused:
		return
	get_tree().paused = false
	Audio.set_music_paused(false)
	pause_menu.visible = false


func go_menu() -> void:
	get_tree().paused = false
	world.stop_run()
	_show_menu()
	Audio.play_music("menu")


# ---------- Eventos de partida ----------

func _on_run_ended(res: Dictionary) -> void:
	hud.visible = false
	var info := Save.record_run(res)
	game_over.show_results(res, info)


# ---------- Entrada ----------

func _can_control() -> bool:
	return world.is_running() and not get_tree().paused


func _on_jump() -> void:
	if _can_control():
		world.jump()


func _on_slide() -> void:
	if _can_control():
		world.slide()


func _on_tap() -> void:
	if _can_control():
		world.activate_special()


func _on_pause_key() -> void:
	if get_tree().paused:
		resume_game()
	else:
		pause_game()
