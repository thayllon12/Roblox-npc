extends Node
## Daily-style mission system with persistent progress.

signal missions_updated

var missions: Array[Dictionary] = []

const MISSION_DEFS := [
	{"id": "collect_50", "desc": "Collect 50 meat", "target": 50, "reward": 30, "stat": "meat"},
	{"id": "collect_150", "desc": "Collect 150 meat", "target": 150, "reward": 80, "stat": "meat"},
	{"id": "run_200", "desc": "Run 200 meters", "target": 200, "reward": 40, "stat": "distance"},
	{"id": "run_500", "desc": "Run 500 meters", "target": 500, "reward": 100, "stat": "distance"},
	{"id": "jump_15", "desc": "Jump 15 times", "target": 15, "reward": 25, "stat": "jumps"},
	{"id": "use_3_powerups", "desc": "Use 3 power-ups", "target": 3, "reward": 50, "stat": "powerups"},
	{"id": "survive_60", "desc": "Survive 60 seconds", "target": 60, "reward": 60, "stat": "time"},
]

# Run session counters
var session := {
	"meat": 0,
	"distance": 0.0,
	"jumps": 0,
	"powerups": 0,
	"time": 0.0,
}

func _ready() -> void:
	_load_missions()
	EventBus.meat_collected.connect(_on_meat)
	EventBus.distance_updated.connect(_on_distance)
	EventBus.powerup_activated.connect(_on_powerup)
	EventBus.game_started.connect(_on_run_start)
	EventBus.game_over.connect(_on_run_end)

func _process(delta: float) -> void:
	if GameManager.is_playing():
		session["time"] += delta
		_check_stat("time", int(session["time"]))

func _load_missions() -> void:
	missions.clear()
	for def in MISSION_DEFS:
		var progress: int = SaveManager.get_mission_progress(def.id)
		var completed: bool = progress >= def.target
		var claimed: bool = SaveManager.get_mission_progress(def.id + "_claimed") >= 1
		missions.append({
			"id": def.id,
			"desc": def.desc,
			"target": def.target,
			"reward": def.reward,
			"stat": def.stat,
			"progress": mini(progress, def.target),
			"completed": completed,
			"claimed": claimed,
		})

func _on_run_start() -> void:
	session = {"meat": 0, "distance": 0.0, "jumps": 0, "powerups": 0, "time": 0.0}

func _on_run_end(_s: int, _d: float, _m: int) -> void:
	# Persist session gains into mission progress
	for m in missions:
		if m.claimed:
			continue
		var add := 0
		match m.stat:
			"meat": add = session.meat
			"distance": add = int(session.distance)
			"jumps": add = session.jumps
			"powerups": add = session.powerups
			"time": add = int(session.time)
		if add > 0:
			var new_p: int = mini(m.progress + add, m.target)
			m.progress = new_p
			SaveManager.set_mission_progress(m.id, new_p)
			if new_p >= m.target:
				m.completed = true
	SaveManager.save_game()
	missions_updated.emit()

func _on_meat(amount: int, _type: String) -> void:
	session.meat += amount
	_check_stat("meat", session.meat)

func _on_distance(d: float) -> void:
	session.distance = d
	_check_stat("distance", int(d))

func _on_powerup(_type: String, _dur: float) -> void:
	session.powerups += 1
	_check_stat("powerups", session.powerups)

func register_jump() -> void:
	session.jumps += 1
	_check_stat("jumps", session.jumps)

func _check_stat(stat: String, value: int) -> void:
	for m in missions:
		if m.stat != stat or m.claimed or m.completed:
			continue
		if value > m.progress:
			# Live update during run (will be saved on game over)
			m.progress = mini(value, m.target)
			if m.progress >= m.target:
				m.completed = true
	missions_updated.emit()

func claim_reward(mission_id: String) -> bool:
	for m in missions:
		if m.id == mission_id and m.completed and not m.claimed:
			m.claimed = true
			SaveManager.set_mission_progress(mission_id + "_claimed", 1)
			SaveManager.add_meat(m.reward)
			SaveManager.save_game()
			missions_updated.emit()
			return true
	return false

func get_missions() -> Array[Dictionary]:
	return missions
