extends Node
## Shop catalog and purchase logic for Leon skins.

const SKINS := [
	{
		"id": "default",
		"name": "Classic Leon",
		"price": 0,
		"body": Color(0.95, 0.72, 0.28),
		"mane": Color(0.78, 0.42, 0.12),
		"desc": "The original adventurer."
	},
	{
		"id": "golden",
		"name": "Golden Mane",
		"price": 100,
		"body": Color(1.0, 0.88, 0.35),
		"mane": Color(0.95, 0.7, 0.15),
		"desc": "Shiny and proud."
	},
	{
		"id": "shadow",
		"name": "Shadow Leon",
		"price": 150,
		"body": Color(0.25, 0.25, 0.3),
		"mane": Color(0.15, 0.15, 0.2),
		"desc": "Stealthy night hunter."
	},
	{
		"id": "crimson",
		"name": "Crimson King",
		"price": 200,
		"body": Color(0.85, 0.25, 0.2),
		"mane": Color(0.55, 0.1, 0.1),
		"desc": "Fierce and bold."
	},
	{
		"id": "arctic",
		"name": "Arctic Leon",
		"price": 250,
		"body": Color(0.85, 0.9, 0.95),
		"mane": Color(0.7, 0.8, 0.9),
		"desc": "Cool as ice."
	},
	{
		"id": "jungle_camo",
		"name": "Jungle Camo",
		"price": 180,
		"body": Color(0.4, 0.65, 0.3),
		"mane": Color(0.25, 0.45, 0.18),
		"desc": "Blends with the leaves."
	},
]

func get_skins() -> Array:
	return SKINS

func get_skin(id: String) -> Dictionary:
	for s in SKINS:
		if s.id == id:
			return s
	return SKINS[0]

func can_afford(id: String) -> bool:
	var skin := get_skin(id)
	return SaveManager.get_total_meat() >= int(skin.price)

func is_unlocked(id: String) -> bool:
	return SaveManager.is_skin_unlocked(id)

func purchase(id: String) -> bool:
	if is_unlocked(id):
		return false
	var skin := get_skin(id)
	var price: int = int(skin.price)
	if price <= 0:
		SaveManager.unlock_skin(id)
		SaveManager.save_game()
		return true
	if SaveManager.spend_meat(price):
		SaveManager.unlock_skin(id)
		SaveManager.save_game()
		return true
	return false

func select_skin(id: String) -> bool:
	if not is_unlocked(id):
		return false
	SaveManager.set_selected_skin(id)
	SaveManager.save_game()
	return true

func get_selected_id() -> String:
	return SaveManager.get_selected_skin()

func apply_skin_to_leon(leon: Node) -> void:
	var skin := get_skin(get_selected_id())
	var spr = leon.get_node_or_null("Visual/Sprite2D")
	if spr and spr is Sprite2D:
		if skin.id == "default":
			spr.modulate = Color.WHITE
		else:
			spr.modulate = skin.body
	var body = leon.get_node_or_null("BodyVisual")
	var mane = leon.get_node_or_null("Mane")
	var tail = leon.get_node_or_null("Tail")
	if body and body is ColorRect:
		body.color = skin.body
	if mane and mane is ColorRect:
		mane.color = skin.mane
	if tail and tail is ColorRect:
		tail.color = skin.body.lightened(0.05)
