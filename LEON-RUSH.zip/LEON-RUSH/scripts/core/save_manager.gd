extends Node
## Salvamento local (user://save.json). Autoload: Save.

const SAVE_FILE := "save.json"
const SAVE_PATH := "user://save.json"
const CORRUPT_PATH := "user://save.corrupt.json"
const SAVE_VERSION := 1

var data: Dictionary = {}


func _ready() -> void:
	load_data()


static func defaults() -> Dictionary:
	return {
		"version": SAVE_VERSION,
		"best_distance": 0.0,
		"best_meat": 0,
		"best_score": 0,
		"meat_balance": 0,
		"runs_played": 0,
		"owned": ["leon_default", "acc_none", "fx_dust"],
		"equipped": {"skin": "leon_default", "accessory": "acc_none", "effect": "fx_dust"},
		"claimed": [],
		"stats": {"meat": 0, "distance": 0.0, "jumps": 0, "powerups": 0, "golden": 0, "best_time": 0.0},
		"settings": {
			"music_on": true,
			"sfx_on": true,
			"music_volume": 0.8,
			"sfx_volume": 0.8,
			"quality": 1,
			"vibration": true,
		},
	}


func load_data() -> void:
	data = defaults()
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		push_warning("Não foi possível abrir o salvamento. Usando valores padrão.")
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		_quarantine_corrupt()
		return
	_merge(data, parsed)


func save_data() -> void:
	var tmp := SAVE_FILE + ".tmp"
	var f := FileAccess.open("user://" + tmp, FileAccess.WRITE)
	if f == null:
		push_error("Falha ao gravar o salvamento: %s" % error_string(FileAccess.get_open_error()))
		return
	f.store_string(JSON.stringify(data, "\t"))
	f.close()
	var dir := DirAccess.open("user://")
	if dir == null:
		return
	if dir.file_exists(SAVE_FILE):
		dir.remove(SAVE_FILE)
	dir.rename(tmp, SAVE_FILE)


func _quarantine_corrupt() -> void:
	push_warning("Salvamento corrompido. Uma cópia foi guardada e valores padrão foram usados.")
	var dir := DirAccess.open("user://")
	if dir:
		dir.copy(SAVE_FILE, CORRUPT_PATH.get_file())


static func _merge(target: Dictionary, source: Dictionary) -> void:
	for key in source:
		if not target.has(key):
			target[key] = source[key]
		elif typeof(target[key]) == TYPE_DICTIONARY and typeof(source[key]) == TYPE_DICTIONARY:
			_merge(target[key], source[key])
		elif _compatible(target[key], source[key]):
			target[key] = source[key]


static func _compatible(a: Variant, b: Variant) -> bool:
	var numeric := [TYPE_INT, TYPE_FLOAT]
	return typeof(a) == typeof(b) or (typeof(a) in numeric and typeof(b) in numeric)


# ---------- Configurações ----------

func get_setting(key: String) -> Variant:
	return data["settings"].get(key)


func set_setting(key: String, value: Variant) -> void:
	data["settings"][key] = value
	save_data()
	Audio.apply_settings()


# ---------- Loja ----------

func owns(item_id: String) -> bool:
	return data["owned"].has(item_id)


func is_equipped(item_id: String) -> bool:
	var item := GameCatalog.find_item(item_id)
	if item.is_empty():
		return false
	return data["equipped"].get(item["kind"], "") == item_id


func purchase(item_id: String, price: int) -> bool:
	if owns(item_id) or int(data["meat_balance"]) < price:
		return false
	data["meat_balance"] = int(data["meat_balance"]) - price
	data["owned"].append(item_id)
	save_data()
	return true


func equip(item_id: String) -> void:
	if not owns(item_id):
		return
	var item := GameCatalog.find_item(item_id)
	if item.is_empty():
		return
	data["equipped"][item["kind"]] = item_id
	save_data()


## Cores e cosméticos que o Leon usa na próxima partida.
func loadout() -> Dictionary:
	var eq: Dictionary = data["equipped"]
	var skin := GameCatalog.find_item(str(eq.get("skin", "leon_default")))
	if skin.is_empty():
		skin = GameCatalog.find_item("leon_default")
	var acc := GameCatalog.find_item(str(eq.get("accessory", "")))
	var fx := GameCatalog.find_item(str(eq.get("effect", "")))
	return {
		"mane": Color(skin["mane"]),
		"body": Color(skin["body"]),
		"trail": Color(skin["trail"]),
		"accessory": acc.get("value", ""),
		"effect": fx.get("value", ""),
	}


# ---------- Partidas e missões ----------

## Registra o resultado de uma partida. Retorna se houve novo recorde.
func record_run(res: Dictionary) -> Dictionary:
	var prev_best: int = int(data["best_score"])
	var new_record := int(res["score"]) > prev_best
	data["best_distance"] = maxf(float(data["best_distance"]), float(res["distance"]))
	data["best_meat"] = maxi(int(data["best_meat"]), int(res["meat"]))
	data["best_score"] = maxi(prev_best, int(res["score"]))
	data["meat_balance"] = int(data["meat_balance"]) + int(res["meat"])
	data["runs_played"] = int(data["runs_played"]) + 1

	var s: Dictionary = data["stats"]
	s["meat"] = int(s["meat"]) + int(res["meat"])
	s["distance"] = float(s["distance"]) + float(res["distance"])
	s["jumps"] = int(s["jumps"]) + int(res["jumps"])
	s["powerups"] = int(s["powerups"]) + int(res["powerups"])
	s["golden"] = int(s["golden"]) + int(res["golden"])
	s["best_time"] = maxf(float(s["best_time"]), float(res["time"]))
	save_data()
	return {"new_record": new_record, "prev_best": prev_best}


func is_claimed(mission_id: String) -> bool:
	return data["claimed"].has(mission_id)


## Resgata a recompensa de uma missão concluída. Retorna true se resgatou agora.
func claim(mission: Dictionary) -> bool:
	var value := float(data["stats"].get(mission["stat"], 0.0))
	if is_claimed(mission["id"]) or value < float(mission["goal"]):
		return false
	data["claimed"].append(mission["id"])
	data["meat_balance"] = int(data["meat_balance"]) + int(mission["reward"])
	save_data()
	return true


func reset_all() -> void:
	data = defaults()
	save_data()
	Audio.apply_settings()
