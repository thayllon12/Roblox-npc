extends Node
## Áudio gerado por código (sem arquivos externos, logo sem licenças a rastrear).
## Autoload: Audio.

const RATE := 22050
const SFX_POOL_SIZE := 8

var _sounds: Dictionary = {}
var _music: Dictionary = {}
var _music_player: AudioStreamPlayer
var _sfx_players: Array = []
var _next_sfx := 0
var _current_track := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_music_player = AudioStreamPlayer.new()
	add_child(_music_player)
	for i in SFX_POOL_SIZE:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_sfx_players.append(p)

	_sounds = {
		"jump": _sweep(360.0, 640.0, 0.12, 0.35),
		"land": _sweep(180.0, 90.0, 0.09, 0.4),
		"collect": _sweep(880.0, 1320.0, 0.07, 0.28),
		"powerup": _sweep(440.0, 1100.0, 0.28, 0.3),
		"hit": _noise(0.28, 0.45),
		"gameover": _sweep(420.0, 70.0, 0.9, 0.4),
		"button": _sweep(660.0, 760.0, 0.05, 0.22),
	}
	_music["menu"] = _loop([262, 330, 392, 330, 294, 349, 440, 349], 0.42)
	_music["game"] = _loop([392, 466, 523, 466, 440, 523, 587, 523], 0.2)
	apply_settings()


func play(sound: String) -> void:
	if not bool(Save.get_setting("sfx_on")) or not _sounds.has(sound):
		return
	var p: AudioStreamPlayer = _sfx_players[_next_sfx]
	_next_sfx = (_next_sfx + 1) % _sfx_players.size()
	p.stream = _sounds[sound]
	p.volume_db = _volume_db(float(Save.get_setting("sfx_volume")))
	p.play()


func play_music(track: String) -> void:
	_current_track = track
	_music_player.stop()
	if not bool(Save.get_setting("music_on")) or not _music.has(track):
		return
	_music_player.stream = _music[track]
	_music_player.volume_db = _volume_db(float(Save.get_setting("music_volume"))) - 6.0
	_music_player.play()


func set_music_paused(paused: bool) -> void:
	_music_player.stream_paused = paused


## Aplica volumes e liga/desliga imediatamente.
func apply_settings() -> void:
	if _music_player == null:
		return
	var on := bool(Save.get_setting("music_on"))
	_music_player.volume_db = _volume_db(float(Save.get_setting("music_volume"))) - 6.0
	if not on:
		_music_player.stop()
	elif not _music_player.playing and _current_track != "":
		play_music(_current_track)


func _volume_db(linear: float) -> float:
	return linear_to_db(maxf(0.001, linear))


func _to_wav(buf: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(buf.size() * 2)
	for i in buf.size():
		data.encode_s16(i * 2, clampi(int(buf[i] * 32767.0), -32768, 32767))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	if loop:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_end = buf.size()
	return wav


func _sweep(f0: float, f1: float, dur: float, vol: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var buf := PackedFloat32Array()
	buf.resize(n)
	var phase := 0.0
	for i in n:
		var k := float(i) / float(n)
		phase += TAU * lerpf(f0, f1, k) / RATE
		buf[i] = sin(phase) * vol * (1.0 - k) * (1.0 - k)
	return _to_wav(buf, false)


func _noise(dur: float, vol: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var buf := PackedFloat32Array()
	buf.resize(n)
	for i in n:
		var k := float(i) / float(n)
		buf[i] = randf_range(-1.0, 1.0) * vol * (1.0 - k)
	return _to_wav(buf, false)


func _loop(freqs: Array, note_len: float) -> AudioStreamWAV:
	var per := int(RATE * note_len)
	var buf := PackedFloat32Array()
	buf.resize(per * freqs.size())
	buf.fill(0.0)
	for n in freqs.size():
		var f: float = freqs[n]
		var phase := 0.0
		for i in per:
			var t := float(i) / RATE
			phase += TAU * f / RATE
			var env := exp(-t * 3.0)
			buf[n * per + i] += (sin(phase) * 0.5 + sin(phase * 2.0) * 0.12) * env * 0.5
	return _to_wav(buf, true)
