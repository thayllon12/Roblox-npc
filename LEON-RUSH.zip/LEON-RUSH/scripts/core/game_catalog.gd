class_name GameCatalog
extends RefCounted
## Dados estáticos do jogo: carnes, power-ups, loja e missões.

const MEAT := {
	"common": {"value": 1, "color": "#ff6b6b"},
	"golden": {"value": 3, "color": "#ffd166"},
	"energy": {"value": 2, "color": "#80ed99"},
	"rare": {"value": 5, "color": "#c77dff"},
	"special": {"value": 10, "color": "#4cc9f0"},
}

const POWERUPS := {
	"magnet": {"name": "Ímã de Carne", "duration": 8.0, "color": "#4cc9f0"},
	"shield": {"name": "Escudo", "duration": 9999.0, "color": "#80ed99"},
	"speed": {"name": "Impulso", "duration": 6.0, "color": "#ff9f1c"},
	"multiplier": {"name": "Carne Dobrada", "duration": 10.0, "color": "#f15bb5"},
	"invincibility": {"name": "Invencível", "duration": 6.0, "color": "#ffd60a"},
	"megajump": {"name": "Super Pulo", "duration": 8.0, "color": "#9b5de5"},
}

const POWERUP_KEYS := ["magnet", "shield", "speed", "multiplier", "invincibility", "megajump"]

## kind: skin | accessory | effect. Itens com "value" alteram o visual/efeito do Leon.
const SHOP := [
	{"id": "leon_default", "name": "Leon Clássico", "kind": "skin", "price": 0, "mane": "#b5651d", "body": "#e7a84b", "trail": "#e8c79a"},
	{"id": "leon_golden", "name": "Leon Dourado", "kind": "skin", "price": 150, "mane": "#f5c518", "body": "#ffd977", "trail": "#fff3a3"},
	{"id": "leon_night", "name": "Leon Noturno", "kind": "skin", "price": 220, "mane": "#2b3a67", "body": "#7f94c9", "trail": "#9fb4ff"},
	{"id": "leon_fire", "name": "Leon Flamejante", "kind": "skin", "price": 260, "mane": "#d62828", "body": "#f4a261", "trail": "#ff7f50"},
	{"id": "acc_none", "name": "Sem acessório", "kind": "accessory", "price": 0, "value": ""},
	{"id": "acc_crown", "name": "Coroa de Savana", "kind": "accessory", "price": 120, "value": "crown"},
	{"id": "acc_bandana", "name": "Bandana", "kind": "accessory", "price": 90, "value": "bandana"},
	{"id": "fx_dust", "name": "Poeira clássica", "kind": "effect", "price": 0, "value": ""},
	{"id": "fx_sparkle", "name": "Brilho estelar", "kind": "effect", "price": 180, "value": "sparkle"},
]

const MISSIONS := [
	{"id": "m_meat_100", "title": "Coletar 100 carnes no total", "stat": "meat", "goal": 100, "reward": 40},
	{"id": "m_meat_500", "title": "Coletar 500 carnes no total", "stat": "meat", "goal": 500, "reward": 120},
	{"id": "m_dist_500", "title": "Percorrer 500 metros no total", "stat": "distance", "goal": 500, "reward": 30},
	{"id": "m_dist_5000", "title": "Percorrer 5000 metros no total", "stat": "distance", "goal": 5000, "reward": 150},
	{"id": "m_jump_20", "title": "Pular 20 vezes no total", "stat": "jumps", "goal": 20, "reward": 35},
	{"id": "m_pu_3", "title": "Usar 3 power-ups no total", "stat": "powerups", "goal": 3, "reward": 50},
	{"id": "m_gold_25", "title": "Coletar 25 carnes douradas", "stat": "golden", "goal": 25, "reward": 80},
	{"id": "m_time_60", "title": "Sobreviver 60 segundos em uma partida", "stat": "best_time", "goal": 60, "reward": 60},
]


static func find_item(item_id: String) -> Dictionary:
	for item in SHOP:
		if item["id"] == item_id:
			return item
	return {}
