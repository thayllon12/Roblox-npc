extends Node
## Central game state manager.

enum GameState { MENU, PLAYING, PAUSED, GAME_OVER }

var current_state: GameState = GameState.MENU
var distance: float = 0.0
var meat_collected: int = 0
var score: int = 0
var multiplier: float = 1.0
var current_speed: float = 300.0
var base_speed: float = 300.0
var max_speed: float = 700.0
var speed_increase_rate: float = 2.5
var is_running: bool = false

# Difficulty curve
var difficulty_level: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func start_game() -> void:
	reset_run_stats()
	current_state = GameState.PLAYING
	is_running = true
	EventBus.game_started.emit()

func pause_game() -> void:
	if current_state == GameState.PLAYING:
		current_state = GameState.PAUSED
		get_tree().paused = true
		EventBus.game_paused.emit()

func resume_game() -> void:
	if current_state == GameState.PAUSED:
		current_state = GameState.PLAYING
		get_tree().paused = false
		EventBus.game_resumed.emit()

func end_game() -> void:
	current_state = GameState.GAME_OVER
	is_running = false
	get_tree().paused = false
	EventBus.game_over.emit(score, distance, meat_collected)
	_check_records()

func reset_run_stats() -> void:
	distance = 0.0
	meat_collected = 0
	score = 0
	multiplier = 1.0
	current_speed = base_speed
	difficulty_level = 0.0

func add_distance(delta: float) -> void:
	if not is_running:
		return
	# Convert world units to "meters" (approx 10 units = 1 m)
	distance += current_speed * delta * 0.085
	EventBus.distance_updated.emit(distance)
	_update_difficulty(delta)
	_update_score()

func sync_speed_from_player(player_speed: float) -> void:
	# Optional: keep difficulty speed and player speed loosely coupled
	current_speed = max(current_speed, player_speed)

func add_meat(amount: int = 1, meat_type: String = "common") -> void:
	var final_amount := int(amount * multiplier)
	meat_collected += final_amount
	EventBus.meat_collected.emit(final_amount, meat_type)
	_update_score()

func _update_score() -> void:
	score = int(distance * 10) + (meat_collected * 50)
	EventBus.score_updated.emit(score)

func _update_difficulty(delta: float) -> void:
	difficulty_level += delta * 0.05
	current_speed = clampf(base_speed + (difficulty_level * speed_increase_rate * 10.0), base_speed, max_speed)

func _check_records() -> void:
	var best_distance: float = SaveManager.get_best_distance()
	var best_score: int = SaveManager.get_best_score()
	var best_meat: int = SaveManager.get_best_meat()

	if distance > best_distance:
		SaveManager.set_best_distance(distance)
		EventBus.new_record.emit("distance", distance)
	if score > best_score:
		SaveManager.set_best_score(score)
		EventBus.new_record.emit("score", float(score))
	if meat_collected > best_meat:
		SaveManager.set_best_meat(meat_collected)
		EventBus.new_record.emit("meat", float(meat_collected))

	# Always add the meat earned this run to the player's total
	SaveManager.add_meat(meat_collected)
	SaveManager.save_game()

func get_state() -> GameState:
	return current_state

func is_playing() -> bool:
	return current_state == GameState.PLAYING
