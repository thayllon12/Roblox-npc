class_name ObjectPool
extends RefCounted
## Reutiliza nós em vez de criar e destruir durante a corrida.

var _parent: Node
var _factory: Callable
var _free: Array = []


func _init(parent: Node, factory: Callable, prewarm: int = 0) -> void:
	_parent = parent
	_factory = factory
	for i in prewarm:
		var n: Node = _factory.call()
		n.visible = false
		_parent.add_child(n)
		_free.append(n)


func acquire() -> Node:
	var n: Node
	if _free.is_empty():
		n = _factory.call()
		_parent.add_child(n)
	else:
		n = _free.pop_back()
	n.visible = true
	return n


func release(n: Node) -> void:
	n.visible = false
	_free.append(n)


func free_count() -> int:
	return _free.size()
