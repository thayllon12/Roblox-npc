extends Node
## Global event bus for decoupled communication between systems.

signal game_started
signal game_paused
signal game_resumed
signal game_over(score: int, distance: float, meat: int)
signal distance_updated(distance: float)
signal meat_collected(amount: int, type: String)
signal score_updated(score: int)
signal powerup_activated(type: String, duration: float)
signal powerup_expired(type: String)
signal biome_changed(biome_name: String)
signal obstacle_hit
signal player_died
signal new_record(record_type: String, value: float)
signal settings_changed
signal mission_progress(mission_id: String, current: int, target: int)
signal mission_completed(mission_id: String, reward: int)
