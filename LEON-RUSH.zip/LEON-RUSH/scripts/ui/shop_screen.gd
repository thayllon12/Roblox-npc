class_name ShopScreen
extends Control

signal back

var _list: VBoxContainer
var _balance: Label
var _feedback: Label


func _ready() -> void:
	UIKit.full_rect(self)
	UIKit.dim(self, 0.92)

	var margin := MarginContainer.new()
	UIKit.full_rect(margin)
	UIKit.set_margin(margin, 48)
	add_child(margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 20)
	head.add_child(UIKit.button("VOLTAR", func(): back.emit(), Vector2(160, 60)))
	head.add_child(UIKit.label("LOJA", 40, UIKit.COL_ACCENT))
	_balance = UIKit.label("", 26, Color("#ffd166"))
	head.add_child(_balance)
	root.add_child(head)

	_feedback = UIKit.label("", 22, UIKit.COL_MUTED)
	root.add_child(_feedback)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 12)
	scroll.add_child(_list)
	refresh()


func refresh() -> void:
	UIKit.clear_children(_list)
	_balance.text = "Carne: %d" % int(Save.data["meat_balance"])
	for item in GameCatalog.SHOP:
		_list.add_child(_row(item))


func _row(item: Dictionary) -> Control:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIKit.panel_style())
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 18)
	panel.add_child(h)

	var info := UIKit.label(str(item["name"]), 26)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(info)

	var id := str(item["id"])
	var btn: Button
	if Save.is_equipped(id):
		btn = UIKit.button("EQUIPADO", func(): pass, Vector2(260, 60))
		btn.disabled = true
	elif Save.owns(id):
		btn = UIKit.button("EQUIPAR", func(): _equip(id), Vector2(260, 60), true)
	else:
		btn = UIKit.button("COMPRAR (%d)" % int(item["price"]), func(): _buy(item), Vector2(260, 60), true)
	h.add_child(btn)
	return panel


func _buy(item: Dictionary) -> void:
	var id := str(item["id"])
	if Save.purchase(id, int(item["price"])):
		Save.equip(id)
		_feedback.text = "Comprado e equipado: %s" % item["name"]
	else:
		_feedback.text = "Saldo insuficiente."
	refresh()


func _equip(id: String) -> void:
	Save.equip(id)
	_feedback.text = "Equipado. Vale a partir da próxima partida."
	refresh()
