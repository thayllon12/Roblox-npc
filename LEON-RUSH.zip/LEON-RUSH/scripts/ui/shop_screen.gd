extends Control
## Shop UI — unlock and equip skins with meat.

@onready var meat_label: Label = $Top/MeatLabel
@onready var list: VBoxContainer = $Scroll/List
@onready var back_btn: Button = $Bottom/BackBtn
@onready var status_label: Label = $StatusLabel

var shop: Node

func _ready() -> void:
	shop = preload("res://scripts/progression/shop_data.gd").new()
	add_child(shop)
	back_btn.pressed.connect(_on_back)
	_refresh()

func _refresh() -> void:
	meat_label.text = "Meat: %d" % SaveManager.get_total_meat()
	for child in list.get_children():
		child.queue_free()
	await get_tree().process_frame

	for skin in shop.get_skins():
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 48)

		var swatch := ColorRect.new()
		swatch.custom_minimum_size = Vector2(40, 40)
		swatch.color = skin.body
		row.add_child(swatch)

		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var name_l := Label.new()
		name_l.text = skin.name
		var desc_l := Label.new()
		desc_l.text = skin.desc
		desc_l.add_theme_font_size_override("font_size", 12)
		info.add_child(name_l)
		info.add_child(desc_l)
		row.add_child(info)

		var btn := Button.new()
		btn.custom_minimum_size = Vector2(120, 40)
		var unlocked: bool = shop.is_unlocked(skin.id)
		var selected: bool = shop.get_selected_id() == skin.id
		if selected:
			btn.text = "EQUIPPED"
			btn.disabled = true
		elif unlocked:
			btn.text = "EQUIP"
			btn.pressed.connect(_on_equip.bind(skin.id))
		else:
			btn.text = "%d 🥩" % skin.price
			btn.pressed.connect(_on_buy.bind(skin.id))
		row.add_child(btn)
		list.add_child(row)

func _on_buy(id: String) -> void:
	if shop.purchase(id):
		status_label.text = "Unlocked!"
		shop.select_skin(id)
	else:
		status_label.text = "Not enough meat!"
	_refresh()

func _on_equip(id: String) -> void:
	shop.select_skin(id)
	status_label.text = "Equipped!"
	_refresh()

func _on_back() -> void:
	get_tree().change_scene_to_file("res://scenes/main/main_menu.tscn")
