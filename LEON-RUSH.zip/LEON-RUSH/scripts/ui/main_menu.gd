extends Control
## Main menu — entry point for Leon Rush.

@onready var play_btn: Button = $Center/VBox/PlayBtn
@onready var shop_btn: Button = $Center/VBox/ShopBtn
@onready var missions_btn: Button = $Center/VBox/MissionsBtn
@onready var settings_btn: Button = $Center/VBox/SettingsBtn
@onready var meat_label: Label = $TopBar/MeatLabel
@onready var record_label: Label = $TopBar/RecordLabel
@onready var version_label: Label = $VersionLabel

func _ready() -> void:
	play_btn.pressed.connect(_on_play)
	shop_btn.pressed.connect(_on_shop)
	missions_btn.pressed.connect(_on_missions)
	settings_btn.pressed.connect(_on_settings)
	_update_labels()

func _update_labels() -> void:
	meat_label.text = "Meat: %d" % SaveManager.get_total_meat()
	record_label.text = "Best: %.0f m" % SaveManager.get_best_distance()
	version_label.text = "v1.0.0"

func _on_play() -> void:
	get_tree().change_scene_to_file("res://scenes/main/game.tscn")

func _on_shop() -> void:
	get_tree().change_scene_to_file("res://scenes/ui/shop.tscn")

func _on_missions() -> void:
	get_tree().change_scene_to_file("res://scenes/ui/missions.tscn")

func _on_settings() -> void:
	get_tree().change_scene_to_file("res://scenes/ui/settings.tscn")
