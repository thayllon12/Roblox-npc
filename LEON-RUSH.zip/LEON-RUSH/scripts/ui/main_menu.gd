class_name MainMenu
extends Control
## Menu principal. O cenário e o Leon animados ficam visíveis atrás deste painel.

signal navigate(target: String)

var _meat_label: Label
var _best_label: Label


func _ready() -> void:
	UIKit.full_rect(self)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	var box := VBoxContainer.new()
	box.anchor_left = 0.58
	box.anchor_right = 0.95
	box.anchor_top = 0.08
	box.anchor_bottom = 0.92
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 14)
	add_child(box)

	box.add_child(UIKit.label("LEON RUSH", 64, UIKit.COL_ACCENT, HORIZONTAL_ALIGNMENT_CENTER))
	_meat_label = UIKit.label("", 26, Color("#ffd166"), HORIZONTAL_ALIGNMENT_CENTER)
	_best_label = UIKit.label("", 22, UIKit.COL_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(_meat_label)
	box.add_child(_best_label)

	var btn_size := Vector2(360, 76)
	box.add_child(UIKit.button("JOGAR", func(): navigate.emit("play"), btn_size, true))
	box.add_child(UIKit.button("LOJA", func(): navigate.emit("shop"), btn_size))
	box.add_child(UIKit.button("MISSÕES", func(): navigate.emit("missions"), btn_size))
	box.add_child(UIKit.button("CONFIGURAÇÕES", func(): navigate.emit("settings"), btn_size))
	refresh()


func refresh() -> void:
	_meat_label.text = "Carne: %d" % int(Save.data["meat_balance"])
	_best_label.text = "Recorde: %d pts · %d m" % [int(Save.data["best_score"]), int(float(Save.data["best_distance"]))]
