class_name GameOver
extends Control

signal retry_requested
signal home_requested

var _panel: PanelContainer
var _score_label: Label
var _new_label: Label
var _prev_label: Label
var _rows: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	UIKit.full_rect(self)
	UIKit.dim(self, 0.7)

	_panel = PanelContainer.new()
	_panel.add_theme_stylebox_override("panel", UIKit.panel_style())
	UIKit.center_box(_panel, 520, 540)
	_panel.pivot_offset = Vector2(260, 270)
	add_child(_panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	_panel.add_child(box)

	box.add_child(UIKit.label("FIM DE JOGO", 36, UIKit.COL_DANGER, HORIZONTAL_ALIGNMENT_CENTER))
	_score_label = UIKit.label("0", 60, UIKit.COL_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(_score_label)
	_new_label = UIKit.label("NOVO RECORDE!", 28, Color("#80ed99"), HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(_new_label)

	for key in ["Distância", "Carne coletada", "Melhor combo", "Pulos", "Tempo"]:
		var row := HBoxContainer.new()
		var name_label := UIKit.label(key, 22, UIKit.COL_MUTED)
		name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var value_label := UIKit.label("-", 22, UIKit.COL_TEXT, HORIZONTAL_ALIGNMENT_RIGHT)
		row.add_child(name_label)
		row.add_child(value_label)
		box.add_child(row)
		_rows[key] = value_label

	_prev_label = UIKit.label("", 20, UIKit.COL_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(_prev_label)

	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 16)
	box.add_child(buttons)
	buttons.add_child(UIKit.button("RETRY", func(): retry_requested.emit(), Vector2(200, 70), true))
	buttons.add_child(UIKit.button("HOME", func(): home_requested.emit(), Vector2(200, 70)))

	visible = false


func show_results(res: Dictionary, info: Dictionary) -> void:
	visible = true
	_rows["Distância"].text = "%d m" % int(res["distance"])
	_rows["Carne coletada"].text = str(res["meat"])
	_rows["Melhor combo"].text = "x%d" % int(res["combo"])
	_rows["Pulos"].text = str(res["jumps"])
	_rows["Tempo"].text = "%.0f s" % float(res["time"])
	_new_label.visible = bool(info["new_record"])
	_prev_label.text = "Recorde anterior: %d pontos" % int(info["prev_best"])
	_score_label.text = "0"

	var count := create_tween()
	count.tween_method(_set_score, 0.0, float(res["score"]), 0.9)

	_panel.scale = Vector2(0.6, 0.6)
	var pop := create_tween()
	pop.tween_property(_panel, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _set_score(v: float) -> void:
	_score_label.text = str(int(v))
