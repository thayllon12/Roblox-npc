class_name UIKit
extends RefCounted
## Fábrica de controles com o estilo visual do jogo.

const COL_ACCENT := Color("#fca311")
const COL_TEXT := Color("#f1f5f9")
const COL_MUTED := Color("#94a3b8")
const COL_BTN := Color("#1e293b")
const COL_DANGER := Color("#e63946")


static func full_rect(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


static func center_box(c: Control, w: float, h: float) -> void:
	c.anchor_left = 0.5
	c.anchor_right = 0.5
	c.anchor_top = 0.5
	c.anchor_bottom = 0.5
	c.offset_left = -w * 0.5
	c.offset_right = w * 0.5
	c.offset_top = -h * 0.5
	c.offset_bottom = h * 0.5


static func set_margin(m: MarginContainer, px: int) -> void:
	m.add_theme_constant_override("margin_left", px)
	m.add_theme_constant_override("margin_right", px)
	m.add_theme_constant_override("margin_top", px)
	m.add_theme_constant_override("margin_bottom", px)


static func clear_children(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


static func dim(parent: Control, alpha: float) -> void:
	var r := ColorRect.new()
	r.color = Color(0.02, 0.03, 0.07, alpha)
	full_rect(r)
	parent.add_child(r)


static func label(text: String, size: int = 22, color: Color = COL_TEXT, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text: String, on_press: Callable, min_size: Vector2 = Vector2(260, 64), accent: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 26)
	var base := COL_ACCENT if accent else COL_BTN
	b.add_theme_stylebox_override("normal", _box(base, 16))
	b.add_theme_stylebox_override("hover", _box(base.lightened(0.12), 16))
	b.add_theme_stylebox_override("pressed", _box(base.darkened(0.25), 16))
	b.add_theme_stylebox_override("disabled", _box(Color("#334155"), 16))
	b.add_theme_color_override("font_color", Color("#0f172a") if accent else COL_TEXT)
	b.add_theme_color_override("font_disabled_color", COL_MUTED)
	b.pressed.connect(func(): _press(on_press))
	return b


static func panel_style() -> StyleBoxFlat:
	var sb := _box(Color(0.06, 0.09, 0.16, 0.94), 22)
	sb.set_content_margin_all(18)
	sb.border_color = Color(0.99, 0.64, 0.07, 0.5)
	sb.set_border_width_all(2)
	return sb


## Insets (esquerda, topo, direita, base) da área segura, em pixels lógicos de 720 px de altura.
static func safe_insets() -> Vector4:
	var win := DisplayServer.window_get_size()
	if win.y <= 0:
		return Vector4.ZERO
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	var screen: Vector2i = DisplayServer.screen_get_size()
	if safe.size == Vector2i.ZERO or screen == Vector2i.ZERO:
		return Vector4.ZERO
	var s := 720.0 / float(win.y)
	return Vector4(
		float(safe.position.x) * s,
		float(safe.position.y) * s,
		float(screen.x - safe.end.x) * s,
		float(screen.y - safe.end.y) * s,
	)


static func _press(cb: Callable) -> void:
	Audio.play("button")
	cb.call()


static func _box(color: Color, radius: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(10)
	return sb
