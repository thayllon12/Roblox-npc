class_name PauseMenu
extends Control

signal resume_requested
signal restart_requested
signal menu_requested


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	UIKit.full_rect(self)
	UIKit.dim(self, 0.6)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIKit.panel_style())
	UIKit.center_box(panel, 440, 420)
	add_child(panel)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 16)
	panel.add_child(box)

	box.add_child(UIKit.label("PAUSA", 44, UIKit.COL_ACCENT, HORIZONTAL_ALIGNMENT_CENTER))
	var btn_size := Vector2(360, 72)
	box.add_child(UIKit.button("CONTINUAR", func(): resume_requested.emit(), btn_size, true))
	box.add_child(UIKit.button("REINICIAR", func(): restart_requested.emit(), btn_size))
	box.add_child(UIKit.button("MENU PRINCIPAL", func(): menu_requested.emit(), btn_size))
