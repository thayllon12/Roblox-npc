extends Control
## Settings menu — audio toggles and volumes.

@onready var music_check: CheckButton = $Center/VBox/MusicCheck
@onready var sfx_check: CheckButton = $Center/VBox/SfxCheck
@onready var music_slider: HSlider = $Center/VBox/MusicSlider
@onready var sfx_slider: HSlider = $Center/VBox/SfxSlider
@onready var back_btn: Button = $Center/VBox/BackBtn

func _ready() -> void:
	music_check.button_pressed = SaveManager.get_setting("music_enabled", true)
	sfx_check.button_pressed = SaveManager.get_setting("sfx_enabled", true)
	music_slider.value = SaveManager.get_setting("music_volume", 0.8)
	sfx_slider.value = SaveManager.get_setting("sfx_volume", 1.0)

	music_check.toggled.connect(_on_music_toggle)
	sfx_check.toggled.connect(_on_sfx_toggle)
	music_slider.value_changed.connect(_on_music_vol)
	sfx_slider.value_changed.connect(_on_sfx_vol)
	back_btn.pressed.connect(_on_back)

func _on_music_toggle(on: bool) -> void:
	AudioManager.set_music_enabled(on)

func _on_sfx_toggle(on: bool) -> void:
	AudioManager.set_sfx_enabled(on)

func _on_music_vol(v: float) -> void:
	SaveManager.set_setting("music_volume", v)
	SaveManager.save_game()
	EventBus.settings_changed.emit()

func _on_sfx_vol(v: float) -> void:
	SaveManager.set_setting("sfx_volume", v)
	SaveManager.save_game()
	EventBus.settings_changed.emit()

func _on_back() -> void:
	get_tree().change_scene_to_file("res://scenes/main/main_menu.tscn")
