class_name SettingsScreen
extends Control

signal back

var _list: VBoxContainer
var _confirm_reset: Button


func _ready() -> void:
	UIKit.full_rect(self)
	UIKit.dim(self, 0.92)

	var margin := MarginContainer.new()
	UIKit.full_rect(margin)
	UIKit.set_margin(margin, 48)
	add_child(margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)

	var head := HBoxContainer.new()
	head.add_child(UIKit.button("VOLTAR", func(): back.emit(), Vector2(160, 60)))
	head.add_child(UIKit.label("  CONFIGURAÇÕES", 40, UIKit.COL_ACCENT))
	root.add_child(head)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 16)
	scroll.add_child(_list)
	_build()


func _build() -> void:
	_toggle("Música ligada", "music_on")
	_slider("Volume da música", "music_volume")
	_toggle("Efeitos sonoros ligados", "sfx_on")
	_slider("Volume dos efeitos", "sfx_volume")
	_toggle("Vibração", "vibration")

	var q_row := HBoxContainer.new()
	q_row.add_child(UIKit.label("Qualidade gráfica", 26))
	var q := OptionButton.new()
	q.add_item("Baixa", 0)
	q.add_item("Média", 1)
	q.add_item("Alta", 2)
	q.custom_minimum_size = Vector2(260, 56)
	q.selected = clampi(int(Save.get_setting("quality")), 0, 2)
	q.item_selected.connect(func(i: int): Save.set_setting("quality", i))
	q_row.add_child(q)
	_list.add_child(q_row)

	var reset := UIKit.button("APAGAR PROGRESSO", func(): _confirm_reset.visible = true, Vector2(360, 64))
	_list.add_child(reset)
	_confirm_reset = UIKit.button("CONFIRMAR: APAGAR TUDO", func(): _do_reset(), Vector2(460, 64), false)
	_confirm_reset.add_theme_color_override("font_color", UIKit.COL_DANGER)
	_confirm_reset.visible = false
	_list.add_child(_confirm_reset)


func _toggle(text: String, key: String) -> void:
	var cb := CheckButton.new()
	cb.text = text
	cb.add_theme_font_size_override("font_size", 26)
	cb.button_pressed = bool(Save.get_setting(key))
	cb.toggled.connect(func(on: bool): Save.set_setting(key, on))
	_list.add_child(cb)


func _slider(text: String, key: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	row.add_child(UIKit.label(text, 26))
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = float(Save.get_setting(key))
	s.custom_minimum_size = Vector2(420, 40)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.value_changed.connect(func(v: float): Save.set_setting(key, v))
	row.add_child(s)
	_list.add_child(row)


func _do_reset() -> void:
	Save.reset_all()
	UIKit.clear_children(_list)
	_build()
