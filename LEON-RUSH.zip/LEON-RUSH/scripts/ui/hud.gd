class_name HUD
extends Control

signal pause_pressed
signal special_pressed

const COL_SLOTS := Color("#e0e7ff")

var world: GameWorld

var _dist: Label
var _meat: Label
var _slots: Label
var _effects: Label
var _combo: Label
var _special: Button


func _ready() -> void:
	UIKit.full_rect(self)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ins := UIKit.safe_insets()

	var box := VBoxContainer.new()
	box.position = Vector2(ins.x + 24.0, ins.y + 16.0)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	_dist = UIKit.label("0 m", 34)
	_meat = UIKit.label("Carne: 0", 28, Color("#ffd166"))
	_slots = UIKit.label("", 22, COL_SLOTS)
	_effects = UIKit.label("", 20, Color("#80ed99"))
	box.add_child(_dist)
	box.add_child(_meat)
	box.add_child(_slots)
	box.add_child(_effects)

	_combo = UIKit.label("", 42, UIKit.COL_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	_combo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_combo.anchor_left = 0.5
	_combo.anchor_right = 0.5
	_combo.offset_left = -200.0
	_combo.offset_right = 200.0
	_combo.offset_top = ins.y + 14.0
	add_child(_combo)

	var pause := UIKit.button("II", func(): pause_pressed.emit(), Vector2(84, 64))
	pause.anchor_left = 1.0
	pause.anchor_right = 1.0
	pause.offset_left = -84.0 - ins.z - 20.0
	pause.offset_right = -ins.z - 20.0
	pause.offset_top = ins.y + 16.0
	pause.offset_bottom = ins.y + 80.0
	add_child(pause)

	_special = UIKit.button("ESPECIAL", func(): special_pressed.emit(), Vector2(230, 96), true)
	_special.anchor_left = 1.0
	_special.anchor_right = 1.0
	_special.anchor_top = 1.0
	_special.anchor_bottom = 1.0
	_special.offset_left = -230.0 - ins.z - 20.0
	_special.offset_right = -ins.z - 20.0
	_special.offset_top = -96.0 - ins.w - 20.0
	_special.offset_bottom = -ins.w - 20.0
	add_child(_special)


func _process(_delta: float) -> void:
	if world == null or not visible:
		return
	_dist.text = "%d m" % int(world.distance_m())
	_meat.text = "Carne: %d" % world.meat_units
	_combo.text = "x%d" % world.combo_mult() if world.streak >= 2 else ""

	var names: Array = []
	for k in world.powers.slots:
		names.append(str(GameCatalog.POWERUPS[k]["name"]))
	_slots.text = "Especial: " + (", ".join(PackedStringArray(names)) if not names.is_empty() else "—")

	var effects: Array = []
	for k in world.powers.active.keys():
		if k == "shield":
			effects.append("Escudo")
		else:
			effects.append("%s %.0fs" % [GameCatalog.POWERUPS[k]["name"], world.powers.time_left(k)])
	_effects.text = " | ".join(PackedStringArray(effects))

	var can_use: bool = world.powers.can_activate()
	_special.disabled = not can_use
	if world.powers.slots.is_empty():
		_special.text = "ESPECIAL"
	elif world.powers.cooldown > 0.0:
		_special.text = "%.1fs" % world.powers.cooldown
	else:
		_special.text = "ESPECIAL"
