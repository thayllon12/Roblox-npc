extends Control
## Missions UI with claim buttons.

@onready var list: VBoxContainer = $Scroll/List
@onready var back_btn: Button = $Bottom/BackBtn
@onready var meat_label: Label = $Top/MeatLabel

var mission_mgr: Node

func _ready() -> void:
	mission_mgr = preload("res://scripts/progression/mission_manager.gd").new()
	mission_mgr.name = "MissionManager"
	add_child(mission_mgr)
	back_btn.pressed.connect(_on_back)
	mission_mgr.missions_updated.connect(_refresh)
	_refresh()

func _refresh() -> void:
	meat_label.text = "Meat: %d" % SaveManager.get_total_meat()
	for child in list.get_children():
		child.queue_free()
	await get_tree().process_frame

	for m in mission_mgr.get_missions():
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 52)

		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var desc := Label.new()
		desc.text = m.desc
		var prog := Label.new()
		prog.text = "%d / %d" % [m.progress, m.target]
		prog.add_theme_font_size_override("font_size", 14)
		info.add_child(desc)
		info.add_child(prog)
		row.add_child(info)

		var btn := Button.new()
		btn.custom_minimum_size = Vector2(110, 40)
		if m.claimed:
			btn.text = "DONE"
			btn.disabled = true
		elif m.completed:
			btn.text = "+%d 🥩" % m.reward
			btn.pressed.connect(_on_claim.bind(m.id))
		else:
			btn.text = "..."
			btn.disabled = true
		row.add_child(btn)
		list.add_child(row)

func _on_claim(id: String) -> void:
	mission_mgr.claim_reward(id)
	_refresh()

func _on_back() -> void:
	get_tree().change_scene_to_file("res://scenes/main/main_menu.tscn")
