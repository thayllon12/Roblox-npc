class_name MissionsScreen
extends Control

signal back

var _list: VBoxContainer
var _balance: Label
var _feedback: Label


func _ready() -> void:
	UIKit.full_rect(self)
	UIKit.dim(self, 0.92)

	var margin := MarginContainer.new()
	UIKit.full_rect(margin)
	UIKit.set_margin(margin, 48)
	add_child(margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 20)
	head.add_child(UIKit.button("VOLTAR", func(): back.emit(), Vector2(160, 60)))
	head.add_child(UIKit.label("MISSÕES", 40, UIKit.COL_ACCENT))
	_balance = UIKit.label("", 26, Color("#ffd166"))
	head.add_child(_balance)
	root.add_child(head)

	_feedback = UIKit.label("", 22, UIKit.COL_MUTED)
	root.add_child(_feedback)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 12)
	scroll.add_child(_list)
	refresh()


func refresh() -> void:
	UIKit.clear_children(_list)
	_balance.text = "Carne: %d" % int(Save.data["meat_balance"])
	for m in GameCatalog.MISSIONS:
		_list.add_child(_row(m))


func _row(m: Dictionary) -> Control:
	var stats: Dictionary = Save.data["stats"]
	var value := float(stats.get(m["stat"], 0.0))
	var goal := float(m["goal"])
	var done := value >= goal
	var claimed := Save.is_claimed(str(m["id"]))

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIKit.panel_style())
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	panel.add_child(row)

	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	col.add_child(UIKit.label(str(m["title"]), 26))

	var bar := ProgressBar.new()
	bar.max_value = goal
	bar.value = minf(value, goal)
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(320, 22)
	col.add_child(bar)

	var shown: String
	if m["stat"] == "best_time":
		shown = "%.0f s" % value
	else:
		shown = "%d / %d" % [int(minf(value, goal)), int(goal)]
	col.add_child(UIKit.label(shown, 20, UIKit.COL_MUTED))

	var text := "RESGATADA"
	if not claimed:
		text = ("RESGATAR +%d" % int(m["reward"])) if done else "EM ANDAMENTO"
	var btn := UIKit.button(text, func(): _claim(m), Vector2(240, 64), done and not claimed)
	btn.disabled = claimed or not done
	row.add_child(btn)
	return panel


func _claim(m: Dictionary) -> void:
	if Save.claim(m):
		_feedback.text = "Recompensa recebida: +%d carne!" % int(m["reward"])
	refresh()
