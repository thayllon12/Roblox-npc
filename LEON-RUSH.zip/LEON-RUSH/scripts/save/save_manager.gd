extends Node
## Local save system using ConfigFile / user:// 

const SAVE_PATH := "user://leon_rush_save.cfg"

var data: Dictionary = {
	"best_distance": 0.0,
	"best_score": 0,
	"best_meat": 0,
	"total_meat": 0,
	"unlocked_skins": ["default"],
	"selected_skin": "default",
	"settings": {
		"music_enabled": true,
		"sfx_enabled": true,
		"music_volume": 0.8,
		"sfx_volume": 1.0,
		"quality": 1, # 0 low, 1 medium, 2 high
		"vibration": true
	},
	"missions": {},
	"version": 1
}

func _ready() -> void:
	load_game()

func load_game() -> void:
	var config := ConfigFile.new()
	var err := config.load(SAVE_PATH)
	if err != OK:
		# First run or corrupted — use defaults
		save_game()
		return

	for key in data.keys():
		if config.has_section_key("save", key):
			data[key] = config.get_value("save", key)

	# Safety: ensure unlocked_skins always contains default
	if not data["unlocked_skins"].has("default"):
		data["unlocked_skins"].append("default")

func save_game() -> void:
	var config := ConfigFile.new()
	for key in data.keys():
		config.set_value("save", key, data[key])
	config.save(SAVE_PATH)

func get_best_distance() -> float:
	return float(data.get("best_distance", 0.0))

func set_best_distance(value: float) -> void:
	data["best_distance"] = value

func get_best_score() -> int:
	return int(data.get("best_score", 0))

func set_best_score(value: int) -> void:
	data["best_score"] = value

func get_best_meat() -> int:
	return int(data.get("best_meat", 0))

func set_best_meat(value: int) -> void:
	data["best_meat"] = value

func get_total_meat() -> int:
	return int(data.get("total_meat", 0))

func add_meat(amount: int) -> void:
	data["total_meat"] = get_total_meat() + amount

func spend_meat(amount: int) -> bool:
	if get_total_meat() >= amount:
		data["total_meat"] = get_total_meat() - amount
		return true
	return false

func is_skin_unlocked(skin_id: String) -> bool:
	return data["unlocked_skins"].has(skin_id)

func unlock_skin(skin_id: String) -> void:
	if not is_skin_unlocked(skin_id):
		data["unlocked_skins"].append(skin_id)

func get_selected_skin() -> String:
	return str(data.get("selected_skin", "default"))

func set_selected_skin(skin_id: String) -> void:
	if is_skin_unlocked(skin_id):
		data["selected_skin"] = skin_id

func get_setting(key: String, default: Variant = null) -> Variant:
	return data["settings"].get(key, default)

func set_setting(key: String, value: Variant) -> void:
	data["settings"][key] = value
	EventBus.settings_changed.emit()

func get_mission_progress(mission_id: String) -> int:
	return int(data["missions"].get(mission_id, 0))

func set_mission_progress(mission_id: String, value: int) -> void:
	data["missions"][mission_id] = value
