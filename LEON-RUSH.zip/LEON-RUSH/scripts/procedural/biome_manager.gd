extends Node
## Manages biome progression during a run.

const BIOMES: Array[String] = ["jungle", "savanna", "cave", "volcanic", "ruins"]

const BIOME_THRESHOLDS := {
	"jungle": 0.0,
	"savanna": 250.0,
	"cave": 550.0,
	"volcanic": 950.0,
	"ruins": 1400.0,
}

const BIOME_COLORS := {
	"jungle": Color(0.15, 0.35, 0.2),
	"savanna": Color(0.45, 0.38, 0.22),
	"cave": Color(0.12, 0.12, 0.18),
	"volcanic": Color(0.25, 0.1, 0.08),
	"ruins": Color(0.28, 0.26, 0.22),
}

var current_biome: String = "jungle"
var world_generator: Node = null
var background: ColorRect = null

func setup(world_gen: Node, bg: ColorRect = null) -> void:
	world_generator = world_gen
	background = bg
	current_biome = "jungle"
	_apply_biome("jungle")

func _process(_delta: float) -> void:
	if not GameManager.is_playing():
		return
	var dist := GameManager.distance
	var target := "jungle"
	for biome in BIOMES:
		if dist >= BIOME_THRESHOLDS[biome]:
			target = biome
	if target != current_biome:
		_transition_to(target)

func _transition_to(biome: String) -> void:
	current_biome = biome
	_apply_biome(biome)
	EventBus.biome_changed.emit(biome)

func _apply_biome(biome: String) -> void:
	if world_generator and world_generator.has_method("change_biome"):
		world_generator.change_biome(biome)
	if background:
		var target_color: Color = BIOME_COLORS.get(biome, Color(0.15, 0.25, 0.2))
		# Smooth color lerp via tween if available
		var tw := background.create_tween()
		tw.tween_property(background, "color", target_color, 1.2)

func get_current() -> String:
	return current_biome

func get_display_name() -> String:
	match current_biome:
		"jungle": return "Jungle"
		"savanna": return "Savanna"
		"cave": return "Cave"
		"volcanic": return "Volcanic"
		"ruins": return "Ancient Ruins"
	return current_biome.capitalize()
