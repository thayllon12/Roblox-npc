class_name SegmentGenerator
extends RefCounted
## Gera segmentos do cenário como dados puros (sem nós), o que permite testar em modo headless.
##
## Regra de segurança principal: obstáculos consecutivos ficam separados por, no mínimo,
## min_gap_for(velocidade) pixels. Isso garante cerca de 0,85 s entre obstáculos, tempo suficiente
## para pousar de um pulo antes do próximo, mesmo com o impulso de velocidade ativo.
## Obstáculos altos ("branch") sempre podem ser passados deslizando por baixo.

const SEGMENT_LEN := 1400.0
const START_PAD := 480.0
const POWERUP_CHANCE := 0.2
const SPEED_BOOST := 1.3
const SAFETY := 0.85

const PATTERNS_EASY := [["rock"], ["log"], ["spike"], ["rock", "spike"], ["branch"]]
const PATTERNS_MID := [["rock", "rock"], ["branch", "rock"], ["log", "branch"], ["spike", "spike", "spike"], ["rock", "branch", "log"]]
const PATTERNS_HARD := [["branch", "rock", "branch"], ["spike", "log", "branch", "rock"], ["rock", "branch", "spike", "rock"]]

var rng := RandomNumberGenerator.new()
var next_free := START_PAD
var _rest_streak := 0


func _init(seed_value: int = -1) -> void:
	if seed_value >= 0:
		rng.seed = seed_value
	else:
		rng.randomize()


## Distância mínima entre obstáculos para uma velocidade base.
static func min_gap_for(base_speed: float) -> float:
	return clampf(base_speed * SPEED_BOOST * SAFETY, 260.0, 900.0)


## Gera um segmento começando na posição "start" da pista.
## difficulty: 0.0 (fácil) até 1.0 (difícil).
func generate(start: float, base_speed: float, difficulty: float) -> Dictionary:
	var end := start + SEGMENT_LEN
	var gap := min_gap_for(base_speed)
	next_free = maxf(next_free, start + rng.randf_range(40.0, 160.0))

	var resting := _rest_streak < 2 and rng.randf() < lerpf(0.3, 0.05, difficulty)
	if resting:
		_rest_streak += 1
	else:
		_rest_streak = 0

	var obstacles: Array = []
	if not resting:
		var pool: Array = PATTERNS_EASY
		if difficulty > 0.35:
			pool = PATTERNS_EASY + PATTERNS_MID
		if difficulty > 0.7:
			pool = PATTERNS_MID + PATTERNS_HARD
		var pattern: Array = pool[rng.randi() % pool.size()]
		for kind in pattern:
			var w: float = Obstacle.SHAPES[kind]["w"]
			var centre := next_free + w * 0.5
			if centre + w * 0.5 > end:
				break
			obstacles.append({"kind": kind, "track": centre})
			next_free = centre + w * 0.5 + gap * rng.randf_range(1.0, 1.25)

	var free_spans := _free_spans(start, end, obstacles)
	var meats: Array = []
	for span in free_spans:
		var a: float = span[0] + 30.0
		var b: float = span[1] - 30.0
		if b - a < 40.0:
			continue
		var count := clampi(int((b - a) / 58.0), 1, 9)
		var style := rng.randi() % 3
		for i in count:
			var t := (float(i) + 0.5) / float(count)
			var h := 44.0
			match style:
				1:
					h = 60.0 + 80.0 * sin(t * PI)
				2:
					h = 40.0 if i % 2 == 0 else 110.0
			meats.append({"track": lerpf(a, b, t), "h": h, "kind": _pick_meat()})

	var orbs: Array = []
	if not free_spans.is_empty() and rng.randf() < POWERUP_CHANCE:
		var chosen: Array = free_spans[rng.randi() % free_spans.size()]
		var keys: Array = GameCatalog.POWERUP_KEYS
		orbs.append({"track": lerpf(chosen[0], chosen[1], 0.5), "h": 96.0, "kind": keys[rng.randi() % keys.size()]})

	return {"start": start, "end": end, "obstacles": obstacles, "meats": meats, "orbs": orbs, "resting": resting}


func _free_spans(start: float, end: float, obstacles: Array) -> Array:
	var spans: Array = []
	var cursor := start
	for o in obstacles:
		var w: float = Obstacle.SHAPES[o["kind"]]["w"]
		var left: float = o["track"] - w * 0.5
		if left - cursor > 80.0:
			spans.append([cursor, left])
		cursor = o["track"] + w * 0.5
	if end - cursor > 80.0:
		spans.append([cursor, end])
	return spans


func _pick_meat() -> String:
	var r := rng.randf()
	if r < 0.6:
		return "common"
	if r < 0.75:
		return "golden"
	if r < 0.85:
		return "energy"
	if r < 0.95:
		return "rare"
	return "special"


## Valida uma lista de segmentos gerados com a mesma velocidade base.
## Retorna mensagens de erro. Lista vazia significa que todas as regras foram respeitadas.
static func validate(segments: Array, base_speed: float) -> PackedStringArray:
	var errors := PackedStringArray()
	var gap := min_gap_for(base_speed)
	var all: Array = []
	for seg in segments:
		all.append_array(seg["obstacles"])
	all.sort_custom(func(a, b): return a["track"] < b["track"])

	for i in range(1, all.size()):
		var prev: Dictionary = all[i - 1]
		var cur: Dictionary = all[i]
		var prev_right: float = prev["track"] + Obstacle.SHAPES[prev["kind"]]["w"] * 0.5
		var cur_left: float = cur["track"] - Obstacle.SHAPES[cur["kind"]]["w"] * 0.5
		if cur_left - prev_right < gap - 0.5:
			errors.append("Gap curto (%.0f < %.0f) entre %s e %s em %.0f" % [cur_left - prev_right, gap, prev["kind"], cur["kind"], cur["track"]])

	for seg in segments:
		for m in seg["meats"]:
			for o in all:
				var hw: float = Obstacle.SHAPES[o["kind"]]["w"] * 0.5
				if absf(float(m["track"]) - float(o["track"])) < hw + 4.0:
					errors.append("Carne sobre obstáculo em %.0f" % float(m["track"]))
					break
	return errors
