# Leon Rush

Endless runner 2D para Android com o leão **Leon**. Corra automaticamente por biomas selvagens, pule e deslize por cima e por baixo dos obstáculos, colete carnes e desbloqueie melhorias.

Todo o conteúdo visual e sonoro é original e gerado por código. Não há assets de terceiros (ver `ASSET_LICENSES.md`).

## Sumário

- [Descrição](#descrição)
- [Tecnologias](#tecnologias)
- [Requisitos](#requisitos)
- [Como abrir no Godot](#como-abrir-no-godot)
- [Como executar no computador](#como-executar-no-computador)
- [Testes automatizados](#testes-automatizados)
- [Como exportar para Android](#como-exportar-para-android)
- [Como compilar no GitHub](#como-compilar-no-github)
- [Como baixar o APK](#como-baixar-o-apk)
- [Como configurar assinatura de produção](#como-configurar-assinatura-de-produção)
- [Como adicionar novos assets](#como-adicionar-novos-assets)
- [Estrutura do projeto](#estrutura-do-projeto)
- [Controles](#controles)
- [Limitações conhecidas](#limitações-conhecidas)

## Descrição

- **Gameplay:** corrida automática, pulo, deslize, coleta de carne, combo e pontuação.
- **Coletáveis:** carne comum, dourada, energética, rara e especial. Cada uma com valor e aparência próprios.
- **Power-ups:** Ímã de Carne, Escudo, Impulso, Carne Dobrada, Invencível e Super Pulo. Os orbes coletados ficam guardados em slots e são ativados pelo botão ESPECIAL.
- **Biomas:** Selva, Savana, Caverna, Vulcão e Ruínas. A troca acontece durante a corrida, com transição de cores.
- **Dificuldade progressiva:** a velocidade cresce de forma suave com a distância, e os padrões de obstáculos ficam mais complexos.
- **Progressão:** loja com skins, acessórios e efeitos; missões com recompensas em carne; recordes pessoais.
- **Salvamento local:** recordes, saldo, itens, missões e configurações são salvos em `user://save.json`. Arquivos corrompidos são isolados e substituídos por valores padrão.
- **Idioma:** interface em português (pt-BR).

## Tecnologias

- Godot Engine 4.3 (renderer `gl_compatibility`, adequado a Android)
- GDScript com tipagem
- Sem plugins e sem dependências externas

## Requisitos

- Godot 4.3 stable, para desenvolvimento local
- Para exportar Android: Android SDK com build-tools 34, Java 17 e export templates do Godot 4.3
- Para compilar pelo GitHub: somente uma conta no GitHub com Actions habilitado

## Como abrir no Godot

1. Baixe o Godot 4.3 em <https://godotengine.org/download>.
2. Abra o Godot e escolha **Importar**.
3. Selecione o arquivo `project.godot` na raiz do repositório.
4. Na primeira abertura, o Godot importa os recursos. Aguarde o fim do processo.
5. Pressione **F5** para executar. A cena principal é `scenes/main/main.tscn`.

## Como executar no computador

Com o Godot instalado, execute pela linha de comando a partir da raiz do projeto:

```bash
godot --path . 
```

Controles no computador: setas ou `W`/`S` para pular e deslizar, `Espaço` ou `E` para o ESPECIAL, `Esc` ou `P` para pausar, e o mouse para swipe e toque.

## Testes automatizados

Os testes verificam as regras de segurança do gerador procedural (distância mínima entre obstáculos, ausência de carne sobre obstáculos), a fórmula de intervalo entre obstáculos, os power-ups e o catálogo.

```bash
godot --headless --path . --import
godot --headless --path . -s res://tests/run_tests.gd
```

O comando termina com código `1` se algum teste falhar.

## Como exportar para Android

### Pelo editor

1. Instale os **export templates** do Godot 4.3: **Editor > Gerenciar modelos de exportação**.
2. Em **Editor > Configurações do Editor > Exportação > Android**, aponte o caminho do **Android SDK**. Instale o build-tools 34.0.0 pelo SDK Manager.
3. Configure um keystore de debug, se o Godot não tiver um automaticamente.
4. Em **Projeto > Exportar**, selecione o preset **Android** e clique em **Exportar projeto**. O APK será gerado em `build/leon-rush.apk`.

### Pela linha de comando

```bash
godot --headless --path . --export-debug "Android" build/leon-rush.apk
```

### Configuração do preset

O arquivo `export_presets.cfg` já define:

| Campo | Valor |
|---|---|
| Nome | Leon Rush |
| Package ID | `com.leonrush.game` |
| Orientação | Paisagem (horizontal) |
| Versão | 1.0.0 (código 1) |
| Arquitetura | arm64-v8a |
| Modo de build | Template pré-compilado (sem Gradle) |
| Ícone | `icon.svg` |

## Como compilar no GitHub

O workflow `.github/workflows/android-build.yml` roda em cada push na branch `main` e também manualmente, pela aba **Actions > Android APK > Run workflow**. Ele executa estas etapas:

1. Instala Java 17 e o Android SDK com build-tools.
2. Baixa o Godot 4.3 e os export templates.
3. Gera um keystore de debug temporário e configura o editor.
4. Importa os recursos do projeto.
5. Executa os testes headless. Se algum falhar, o build para.
6. Exporta o APK.
7. Verifica se o APK existe, não está vazio e contém `AndroidManifest.xml`.
8. Publica o APK como artifact chamado `leon-rush-apk`.

Nenhum caminho local do desenvolvedor é usado. O keystore de debug é gerado a cada execução, e nenhuma senha de produção fica no código.

## Como baixar o APK

1. Abra o repositório no GitHub e vá em **Actions**.
2. Escolha a execução mais recente de **Android APK** com status verde.
3. Na seção **Artifacts**, baixe `leon-rush-apk`. O arquivo ZIP contém `leon-rush.apk`.
4. Copie o APK para o celular e instale. Permita a instalação de fontes desconhecidas quando o Android pedir.

O APK de debug é adequado para testes, mas não para publicação na loja.

## Como configurar assinatura de produção

Para publicar, é preciso um keystore de release. **Nunca** coloque o keystore ou as senhas no repositório.

1. Gere o keystore localmente:

   ```bash
   keytool -genkeypair -v -keystore leon-rush-release.keystore -alias leonrush -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Guarde o arquivo em local seguro, fora do repositório.
3. No GitHub, vá em **Settings > Secrets and variables > Actions** e crie estes secrets:
   - `ANDROID_KEYSTORE_BASE64`: o keystore convertido em base64 (`base64 -w0 leon-rush-release.keystore`)
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`: `leonrush`
   - `ANDROID_KEY_PASSWORD`
4. No workflow, adicione uma etapa que decodifique o secret em `$HOME/keys/release.keystore` e exporte as variáveis `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`, `GODOT_ANDROID_KEYSTORE_RELEASE_USER` e `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD` com os valores dos secrets.
5. Troque o comando de exportação para `--export-release "Android" build/leon-rush-release.apk`.
6. Para a Play Store, use `.aab` no lugar do APK, com a opção `gradle_build/export_format` e o build com Gradle habilitado.

## Como adicionar novos assets

1. Coloque o arquivo na pasta correspondente em `assets/` (personagens, cenários, obstáculos, coletáveis, UI, áudio, partículas ou fontes).
2. Verifique a licença. Use somente CC0 ou licença compatível, confirmada na página original do recurso.
3. Registre autor, fonte, data de acesso e licença em `ASSET_LICENSES.md`, antes de fazer commit.
4. Para trocar um visual gerado por código, substitua o `_draw()` do script correspondente por um `Sprite2D` ou `AnimatedSprite2D` que aponte para o novo arquivo.
5. Para trocar um som gerado, substitua o `AudioStreamWAV` correspondente em `scripts/core/audio_manager.gd` por um `load("res://assets/audio/...")`.

## Estrutura do projeto

```
LEON-RUSH/
├── project.godot              Configuração do projeto e autoloads
├── export_presets.cfg         Preset de exportação Android
├── icon.svg                   Ícone do jogo
├── README.md
├── ASSET_LICENSES.md          Autoria e licença de cada recurso
├── CHANGELOG.md
├── assets/                    Arquivos externos (vazio nesta versão)
├── scenes/main/main.tscn      Cena principal
├── scripts/
│   ├── main.gd                Orquestrador: telas, pausa, navegação, entrada
│   ├── core/                  Salvamento, áudio, catálogo, pool de objetos
│   ├── player/                Leon, entrada, power-ups
│   ├── gameplay/              Mundo da corrida, obstáculos, coletáveis, biomas, fundo
│   ├── procedural/            Gerador de segmentos e validação de rotas
│   ├── effects/               Partículas
│   └── ui/                    HUD, menus, loja, missões, configurações, pausa, game over
├── tests/run_tests.gd         Testes headless
└── .github/workflows/android-build.yml
```

## Controles

| Ação | Toque | Teclado |
|---|---|---|
| Pular | Deslizar para cima | `↑` ou `W` |
| Deslizar | Deslizar para baixo | `↓` ou `S` |
| Ativar power-up | Toque rápido, ou botão ESPECIAL | `Espaço` ou `E` |
| Pausar | Botão II | `Esc` ou `P` |

Swipes curtos e levemente diagonais são aceitos, com tolerância a erros de toque.

## Limitações conhecidas

- **Arte gerada por código:** personagem, cenários e obstáculos são desenhados com formas simples. Um visual de qualidade comercial exige arte feita por um artista ou assets licenciados.
- **Animação:** as animações são procedurais (ciclo de corrida, squash, cauda, juba e piscar). As animações de referência, como "Taking Damage" e "Victory", não existem como clipes próprios.
- **Física:** colisões são feitas por retângulos alinhados, o que é mais previsível e fácil de testar do que o motor de física completo.
- **Idioma:** apenas português (pt-BR).
- **Validação real:** o projeto foi escrito sem execução no Godot. O primeiro build no GitHub Actions é o teste de verdade. Se algo falhar, o log do workflow mostra o erro.
