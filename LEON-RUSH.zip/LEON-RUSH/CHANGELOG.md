# Changelog

## 1.0.0 — Primeira versão jogável

### Adicionado
- Corrida automática com pulo, deslize, queda rápida e física de gravidade.
- Leon com estados (corrida, pulo, queda, deslize, morte), squash, cauda, juba e piscar.
- Obstáculos: rochas, toras, espinhos e galhos (deslize obrigatório).
- Carnes: comum, dourada, energética, rara e especial, com combo e multiplicador.
- Gerador procedural com segmentos, pool de objetos e regras de rota segura.
- Power-ups: Ímã, Escudo, Impulso, Carne Dobrada, Invencível e Super Pulo, com slots e cooldown.
- Cinco biomas com transição de cores durante a corrida.
- Dificuldade progressiva suave com a distância.
- HUD, menu principal, pausa real, tela de Game Over com contagem animada e novo recorde.
- Loja com compra, validação de saldo, skins, acessórios e efeitos.
- Missões com progresso e resgate de recompensas.
- Configurações: música, efeitos, volumes, qualidade gráfica, vibração e apagar progresso.
- Salvamento local com tratamento de arquivo corrompido.
- Áudio sintetizado por código.
- Exportação Android (`com.leonrush.game`, paisagem) e workflow do GitHub Actions com testes e publicação do APK.
- Testes headless das regras de rota do gerador.

### Limitações
- Arte desenhada por código, sem assets externos.
- Build não executado localmente. A validação final acontece no GitHub Actions.
