# Changelog — LEON RUSH

## [1.0.0] — Final Release Candidate (2026-11-15)

### Complete systems
- **Biomes** with distance-based transitions: Jungle → Savanna → Cave → Volcanic → Ancient Ruins
  - Background color transitions
  - Ground/decor palette changes
  - HUD biome name
- **Shop**: 6 unlockable skins (Classic, Golden, Shadow, Crimson, Arctic, Jungle Camo)
  - Buy with meat, equip, persist, applied in-run
- **Missions**: 7 objectives with progress + claimable meat rewards
- **Settings**: Music/SFX toggle + volume sliders (persisted)
- Full navigation from Main Menu to Shop / Missions / Settings / Play
- Power-ups, scoring, records, pause, game over, local save

### Gameplay
- Leon full controller (coyote, buffer, slide, squash/stretch, secondary motion)
- Procedural segments, meat patterns, obstacle variety
- Difficulty ramp + speed scaling
- Screen shake, multiplier HUD, power-up timers

### Build
- GitHub Actions Android workflow skeleton
- Package id: com.leonrush.game
- Documented export path

## Previous
- 0.3.0 Gameplay power-ups
- 0.2.0 Character physics
- 0.1.0 Foundation
