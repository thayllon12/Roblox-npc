package com.devai.assistant.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.devai.assistant.ui.theme.Cyan
import com.devai.assistant.ui.theme.CyanBright
import com.devai.assistant.ui.theme.ElectricBlue
import com.devai.assistant.ui.theme.ElectricBlueDim
import com.devai.assistant.ui.theme.ErrorRed
import com.devai.assistant.ui.theme.Navy
import com.devai.assistant.ui.theme.OrbGlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Estados visuais da Orb do assistente.
 * Cada estado altera cor, intensidade de brilho, velocidade de pulsação e ondas.
 */
enum class OrbState {
    INACTIVE,       // Desligada / dormindo
    WAITING,        // Aguardando "Hey Dev AI"
    LISTENING,      // Microfone ativo, capturando voz
    PROCESSING,     // Reconhecimento / preparação
    THINKING,       // Inferência local ou Gemini processando
    RESPONDING,     // Falando / exibindo resposta
    ERROR,          // Erro de conexão, modelo ou permissão
    OFFLINE         // Sem internet + modo Gemini sem fallback
}

@Composable
fun AssistantOrb(
    state: OrbState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    // Pulsação base (escala)
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    OrbState.INACTIVE -> 3200
                    OrbState.WAITING -> 2200
                    OrbState.LISTENING -> 900
                    OrbState.PROCESSING -> 700
                    OrbState.THINKING -> 1100
                    OrbState.RESPONDING -> 1400
                    OrbState.ERROR -> 600
                    OrbState.OFFLINE -> 2800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Rotação lenta de anéis
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    OrbState.THINKING, OrbState.PROCESSING -> 4000
                    OrbState.LISTENING -> 6000
                    else -> 12000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Intensidade de ondas de áudio (0 = sem ondas)
    val waveIntensity = when (state) {
        OrbState.LISTENING -> 1.0f
        OrbState.RESPONDING -> 0.75f
        OrbState.PROCESSING, OrbState.THINKING -> 0.45f
        OrbState.WAITING -> 0.2f
        else -> 0.0f
    }

    // Cores por estado
    val coreColor = when (state) {
        OrbState.INACTIVE -> ElectricBlueDim.copy(alpha = 0.45f)
        OrbState.WAITING -> ElectricBlue
        OrbState.LISTENING -> CyanBright
        OrbState.PROCESSING -> ElectricBlue
        OrbState.THINKING -> Cyan
        OrbState.RESPONDING -> CyanBright
        OrbState.ERROR -> ErrorRed
        OrbState.OFFLINE -> ElectricBlueDim.copy(alpha = 0.55f)
    }

    val glowColor = when (state) {
        OrbState.ERROR -> ErrorRed.copy(alpha = 0.35f)
        OrbState.OFFLINE -> ElectricBlueDim.copy(alpha = 0.2f)
        else -> OrbGlow
    }

    // Animação de entrada suave
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, animationSpec = tween(800, easing = FastOutSlowInEasing))
    }

    Box(
        modifier = modifier
            .size(size)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onClick() })
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = ((this.size.minDimension / 2f) * 0.38f * pulse * appear.value).coerceAtLeast(1f)

            // Glow externo suave
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.55f * appear.value),
                        glowColor.copy(alpha = 0.15f * appear.value),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 2.8f
                ),
                radius = radius * 2.8f,
                center = center
            )

            // Anéis orbitais (apenas em estados ativos)
            if (state != OrbState.INACTIVE && state != OrbState.OFFLINE) {
                rotate(rotation, center) {
                    for (i in 0 until 3) {
                        val ringRadius = radius * (1.55f + i * 0.35f)
                        val alpha = (0.35f - i * 0.08f) * appear.value
                        drawCircle(
                            color = coreColor.copy(alpha = alpha),
                            radius = ringRadius,
                            center = center,
                            style = Stroke(width = 1.8f - i * 0.3f)
                        )
                    }
                }
            }

            // Ondas de áudio (círculos concêntricos pulsantes)
            if (waveIntensity > 0f) {
                val waveProgress = (System.currentTimeMillis() % 2000) / 2000f
                for (i in 0 until 3) {
                    val waveR = radius * (1.2f + (waveProgress + i * 0.33f) % 1f * 1.6f)
                    val waveAlpha = (1f - ((waveProgress + i * 0.33f) % 1f)) * 0.35f * waveIntensity * appear.value
                    drawCircle(
                        color = coreColor.copy(alpha = waveAlpha),
                        radius = waveR,
                        center = center,
                        style = Stroke(width = 2.5f)
                    )
                }
            }

            // Núcleo com gradiente
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f * appear.value),
                        coreColor.copy(alpha = 0.95f * appear.value),
                        coreColor.copy(alpha = 0.7f * appear.value),
                        Navy.copy(alpha = 0.9f * appear.value)
                    ),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Highlight superior (efeito de vidro / iluminação)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.35f * appear.value),
                        Color.Transparent
                    ),
                    center = Offset(center.x, center.y - radius * 0.35f),
                    radius = radius * 0.7f
                ),
                radius = radius * 0.55f,
                center = Offset(center.x, center.y - radius * 0.25f)
            )

            // Pontos orbitais (detalhe futurista)
            if (state == OrbState.THINKING || state == OrbState.PROCESSING || state == OrbState.LISTENING) {
                rotate(rotation * 1.3f, center) {
                    for (i in 0 until 6) {
                        val angle = (i * 60f) * (PI / 180f).toFloat()
                        val orbitR = radius * 1.75f
                        val px = center.x + cos(angle) * orbitR
                        val py = center.y + sin(angle) * orbitR
                        drawCircle(
                            color = CyanBright.copy(alpha = 0.7f * appear.value),
                            radius = 3.5f,
                            center = Offset(px, py)
                        )
                    }
                }
            }
        }
    }
}
