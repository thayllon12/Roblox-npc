package com.pastinha.joguinho;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;


final class Assets {
    private final HashMap<String, Bitmap> cache = new HashMap<>();
    private final Context ctx;
    final Typeface font;

    
    public Assets(Context c) {
        Typeface f;
        this.ctx = c;
        try {
            f = Typeface.createFromAsset(c.getAssets(), "fonts/future.ttf");
        } catch (Exception e) {
            f = Typeface.DEFAULT_BOLD;
        }
        this.font = f;
    }

    
    public void preload() {
        String[] dirs = {"ships", "damage", "enemies", "lasers", "meteors", "fx", "explosion", "powerups", "ui", "bg"};
        for (String d : dirs) {
            try {
                String[] files = this.ctx.getAssets().list(d);
                if (files != null) {
                    for (String f : files) {
                        if (f.endsWith(".png")) {
                            get(d + "/" + f);
                        }
                    }
                }
            } catch (Exception e) {
            }
        }
    }

    
    public Bitmap get(String path) {
        Bitmap b = this.cache.get(path);
        if (b != null) {
            return b;
        }
        try {
            InputStream in = this.ctx.getAssets().open(path);
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inScaled = false;
                b = BitmapFactory.decodeStream(in, null, o);
                if (in != null) {
                    in.close();
                }
            } finally {
            }
        } catch (Exception e) {
        }
        if (b == null) {
            b = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888);
        }
        this.cache.put(path, b);
        return b;
    }

    
    public Bitmap[] seq(String fmt, int from, int to) {
        Bitmap[] r = new Bitmap[(to - from) + 1];
        for (int i = from; i <= to; i++) {
            r[i - from] = get(String.format(Locale.US, fmt, Integer.valueOf(i)));
        }
        return r;
    }
}
