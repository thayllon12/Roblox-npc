package com.pastinha.joguinho;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.WindowInsets;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

public class GameView extends GfxView implements SurfaceHolder.Callback, Runnable {
    static final int MENU = 0;
    static final int SELECT = 1;
    static final int PLAY = 2;
    static final int PAUSE = 3;
    static final int OVER = 4;
    static final int SHOP = 5;
    static final int ACH = 6;

    static final int B_PLAY = 1;
    static final int B_SHIPS = 2;
    static final int B_SOUND = 3;
    static final int B_BACK = 4;
    static final int B_PAUSE = 5;
    static final int B_BOMB = 6;
    static final int B_RESUME = 7;
    static final int B_RESTART = 8;
    static final int B_MENU = 9;
    static final int B_AGAIN = 10;
    static final int B_SHOP = 11;
    static final int B_ACH = 12;
    static final int B_DIFF = 13;
    static final int B_VIB = 14;
    static final int B_CARD = 100;
    static final int B_UP = 200;

    static final int K_DRONE = 0;
    static final int K_ZIG = 1;
    static final int K_SHOOT = 2;
    static final int K_KAMI = 3;
    static final int K_TANK = 4;
    static final int K_UFO = 5;
    static final int K_BOSS = 6;
    static final int K_BOMBER = 7;
    static final int K_SWARM = 8;

    static final int P_SHIELD = 0;
    static final int P_WEAPON = 1;
    static final int P_HEAL = 2;
    static final int P_BOMB = 3;
    static final int P_COIN = 4;
    static final int P_MISSILE = 5;
    static final int P_DOUBLE = 6;

    static final float PR = 26f;
    static final int NSTARS = 55;
    static final float TWO_PI = 6.2831855f;
    static final float PI = 3.1415927f;

    static class Bullet {
        Bitmap bmp;
        float x;
        float y;
        float vx;
        float vy;
        float r;
        float rot;
        float dmg;
        float trail;
        boolean mine;
        boolean homing;
    }

    static class Enemy {
        Bitmap bmp;
        float baseX;
        float hoverY;
        float hp;
        float maxHp;
        float r;
        float rot;
        float sc;
        float shoot;
        float spin;
        float t;
        float vx;
        float vy;
        float x;
        float y;
        float flash;
        float minionT;
        boolean boss;
        boolean dead;
        int kind;
        int phase;
        int score;
    }

    static class Rock {
        Bitmap bmp;
        boolean dead;
        float flash;
        float hp;
        float r;
        float rot;
        int size;
        float vr;
        float vx;
        float vy;
        float x;
        float y;
    }

    static class Pickup {
        int kind;
        float t;
        float x;
        float y;
    }

    static class Fx {
        float a0;
        boolean add;
        Bitmap bmp;
        Bitmap[] frames;
        float life;
        float rot;
        float s0;
        float s1;
        float t;
        float vr;
        float vx;
        float vy;
        float x;
        float y;
    }

    static class Pop {
        int color;
        String s;
        float t;
        float x;
        float y;
    }

    static class Btn {
        String color;
        String label;
        float h;
        float w;
        float x;
        float y;
        float textSize;
        int id;

        boolean contains(float px, float py) {
            return px >= x && px <= x + w && py >= y && py <= y + h;
        }
    }

    static class Touch {
        int id;
        int type;
        float x;
        float y;

        Touch(int t, int i, float x, float y) {
            this.type = t;
            this.id = i;
            this.x = x;
            this.y = y;
        }
    }

    final Save sv;
    final Sound snd;
    final Vibrator vibrator;
    final Random rnd = new Random();
    final ConcurrentLinkedQueue<Touch> touches = new ConcurrentLinkedQueue<>();
    final ArrayList<Btn> btns = new ArrayList<>();
    final ArrayList<Bullet> bullets = new ArrayList<>();
    final ArrayList<Enemy> enemies = new ArrayList<>();
    final ArrayList<Rock> rocks = new ArrayList<>();
    final ArrayList<Pickup> pickups = new ArrayList<>();
    final ArrayList<Fx> fxs = new ArrayList<>();
    final ArrayList<Pop> pops = new ArrayList<>();
    final Bitmap[] bDmg = new Bitmap[3];
    final Bitmap[] bStars = new Bitmap[3];
    final float[] stX = new float[NSTARS];
    final float[] stY = new float[NSTARS];
    final float[] stV = new float[NSTARS];
    final float[] stS = new float[NSTARS];
    final int[] stI = new int[NSTARS];
    final String[] pickupPath = {"powerups/powerupBlue_shield.png", "powerups/powerupGreen_bolt.png", "powerups/pill_green.png", "powerups/powerupRed_star.png", "powerups/star_gold.png", "powerups/powerupYellow_star.png", "powerups/bolt_gold.png"};
    final float[] pickupScale = {1.5f, 1.5f, 2.0f, 1.5f, 1.4f, 1.5f, 1.5f};
    final String[] ROCK_BIG = {"meteorBrown_big1", "meteorBrown_big2", "meteorBrown_big3", "meteorBrown_big4", "meteorGrey_big1", "meteorGrey_big2", "meteorGrey_big3", "meteorGrey_big4"};
    final String[] ROCK_SMALL = {"meteorBrown_med1", "meteorBrown_med3", "meteorGrey_med1", "meteorGrey_med2", "meteorBrown_small1", "meteorBrown_small2", "meteorGrey_small1", "meteorGrey_small2"};
    final String[] ROCK_TINY = {"meteorBrown_tiny1", "meteorBrown_tiny2", "meteorGrey_tiny1", "meteorGrey_tiny2"};

    Bitmap bBg;
    Bitmap bPanelRect;
    Bitmap bPanelGlass;
    Bitmap bBtnSq;
    Bitmap bMuzzle;
    Bitmap bSpark;
    Bitmap bStar4;
    Bitmap bSmoke;
    Bitmap bEnemyLaser;
    Bitmap bPlayer;
    Bitmap bPlayerLaser;
    Bitmap bMissile;
    Bitmap bLife;
    Bitmap bShield;
    Bitmap bStarOn;
    Bitmap bStarOff;
    Bitmap[] expReg;
    Bitmap[] expSonic;
    int cachedShip = -1;

    volatile float sc = 1f;
    volatile int state = MENU;
    volatile boolean running;
    volatile boolean pauseRequest;
    volatile boolean backRequest;
    volatile boolean layoutDirty;
    int sw = 1;
    int sh = 1;
    float ti = 20f;
    int insetTick;
    Thread thread;
    Btn pressed;
    int pressedId = -1;
    int moveId = -1;
    float offX;
    float offY;

    boolean alive;
    float px;
    float py;
    float tx;
    float ty;
    float roll;
    float hp;
    float maxHp;
    int lives;
    int weapon;
    int bombs;
    int score;
    int combo;
    int runCoins;
    int runKills;
    int achNew;
    float comboT;
    float fireT;
    float bombCD;
    float shieldT;
    float invulT;
    float hitFlash;
    float respT;
    float missileT;
    float missCd;
    float doubleT;
    float resumeT;
    float bgY;
    float shakeT;
    float shakeAmp;
    float flashT;
    float bannerT;
    float bannerMax;
    boolean bannerBoss;
    String bannerText = "";
    float toastT;
    String toastS = "";
    float hintT;
    boolean newRecord;
    String unlockMsg = "";

    int wave;
    boolean waveActive;
    boolean bossPending;
    boolean bossAlive;
    boolean meteorWave;
    Enemy boss;
    int toSpawn;
    int waveTotal;
    float spawnTimer;
    float startDelay;
    float clearT;
    float rockT;

    public GameView(Context ctx) {
        super(ctx);
        sv = new Save(ctx);
        if (sv.ship < 0 || sv.ship >= Defs.NSHIPS || sv.hi < Defs.SHIP_UNLOCK[sv.ship]) {
            sv.ship = 0;
        }
        snd = new Sound(ctx, sv.sound);
        vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        getHolder().addCallback(this);
        setFocusable(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder h) {
        running = true;
        thread = new Thread(this, "game-loop");
        thread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {
        sw = w;
        sh = hh;
        sc = w / W;
        H = hh / sc;
        layoutDirty = true;
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        running = false;
        try {
            if (thread != null) {
                thread.join(1500L);
            }
        } catch (InterruptedException e) {
        }
        thread = null;
    }

    void onHostPause() {
        pauseRequest = true;
        snd.setHostPaused(true);
        sv.flush();
    }

    void onHostResume() {
        snd.setHostPaused(false);
    }

    void onHostDestroy() {
        sv.flush();
        snd.release();
    }

    boolean onBack() {
        if (state == MENU) {
            return false;
        }
        backRequest = true;
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        int idx = e.getActionIndex();
        float s = sc;
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                touches.add(new Touch(0, e.getPointerId(idx), e.getX(idx) / s, e.getY(idx) / s));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    touches.add(new Touch(1, e.getPointerId(i), e.getX(i) / s, e.getY(i) / s));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                touches.add(new Touch(2, e.getPointerId(idx), e.getX(idx) / s, e.getY(idx) / s));
                break;
            case MotionEvent.ACTION_CANCEL:
                touches.add(new Touch(3, -1, 0f, 0f));
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public void run() {
        loadSprites();
        if (state == MENU) {
            snd.music("menu.ogg", true, 0.45f);
        }
        long last = System.nanoTime();
        while (running) {
            long now = System.nanoTime();
            float dt = (now - last) / 1.0E9f;
            last = now;
            if (dt > 0.05f) {
                dt = 0.05f;
            }
            if (layoutDirty) {
                layoutDirty = false;
                for (int i = 0; i < NSTARS; i++) {
                    resetStar(i, true);
                }
                layout();
            }
            readInsets();
            update(dt);
            Canvas c = null;
            try {
                SurfaceHolder h = getHolder();
                c = Build.VERSION.SDK_INT >= 26 ? h.lockHardwareCanvas() : h.lockCanvas();
                if (c != null) {
                    render(c);
                }
            } catch (Exception e) {
            } finally {
                if (c != null) {
                    try {
                        getHolder().unlockCanvasAndPost(c);
                    } catch (Exception e) {
                    }
                }
            }
            long used = (System.nanoTime() - now) / 1000000L;
            if (used < 16) {
                try {
                    Thread.sleep(16 - used);
                } catch (InterruptedException e) {
                }
            }
        }
    }

    void loadSprites() {
        A.preload();
        loadGfx();
        bPanelRect = A.get("ui/panel_rectangle.png");
        bPanelGlass = A.get("ui/panel_glass.png");
        bBtnSq = A.get("ui/button_square.png");
        bMuzzle = A.get("fx/muzzle_01.png");
        bSpark = A.get("fx/spark_03.png");
        bStar4 = A.get("fx/star_04.png");
        bSmoke = A.get("fx/smoke_05.png");
        bEnemyLaser = A.get("lasers/laserRed07.png");
        bMissile = A.get("lasers/laserGreen08.png");
        expReg = A.seq("explosion/regularExplosion%02d.png", 0, 8);
        expSonic = A.seq("explosion/sonicExplosion%02d.png", 0, 8);
        bBg = A.get("bg/darkPurple.png");
        pickShip();
    }

    void readInsets() {
        insetTick++;
        if (insetTick % 30 != 1) {
            return;
        }
        float t = sc * 20f;
        try {
            WindowInsets wi = getRootWindowInsets();
            if (wi != null) {
                t = Math.max(t, wi.getSystemWindowInsetTop());
                if (Build.VERSION.SDK_INT >= 28 && wi.getDisplayCutout() != null) {
                    t = Math.max(t, wi.getDisplayCutout().getSafeInsetTop());
                }
            }
        } catch (Exception e) {
        }
        ti = t / sc;
    }

    String shipFile(int idx) {
        return "ships/playerShip" + Defs.SHIP_MODEL[idx] + "_" + Defs.SHIP_COLOR[idx] + ".png";
    }

    void pickShip() {
        bPlayer = A.get(shipFile(sv.ship));
        bPlayerLaser = A.get("lasers/" + Defs.SHIP_LASER[sv.ship] + ".png");
    }

    void resetStar(int i, boolean anywhere) {
        stX[i] = rnd.nextFloat() * W;
        stY[i] = anywhere ? rnd.nextFloat() * H : -20f;
        float depth = rnd.nextFloat();
        stV[i] = 220f * depth + 40f;
        stS[i] = 0.9f * depth + 0.35f;
        stI[i] = rnd.nextInt(3);
    }

    Btn addBtn(int id, String label, String color, float x, float y, float w, float h, float ts) {
        Btn b = new Btn();
        b.id = id;
        b.label = label;
        b.color = color;
        b.x = x;
        b.y = y;
        b.w = w;
        b.h = h;
        b.textSize = ts;
        btns.add(b);
        return b;
    }

    void layout() {
        btns.clear();
        pressed = null;
        pressedId = -1;
        switch (state) {
            case MENU: {
                float y = H * 0.47f;
                addBtn(B_PLAY, "JOGAR", "Green", 110f, y, 500f, 110f, 52f);
                float y1 = y + 128f;
                addBtn(B_SHIPS, "NAVES", "Blue", 60f, y1, 285f, 84f, 32f);
                addBtn(B_SHOP, "LOJA", "Yellow", 375f, y1, 285f, 84f, 32f);
                float y2 = y1 + 102f;
                addBtn(B_ACH, "CONQUISTAS", "Blue", 60f, y2, 285f, 84f, 26f);
                addBtn(B_DIFF, "NIVEL " + Defs.DIFF_NAME[sv.diff], Defs.DIFF_COLOR[sv.diff], 375f, y2, 285f, 84f, 26f);
                float y3 = y2 + 102f;
                addBtn(B_SOUND, sv.sound ? "SOM LIGADO" : "SOM MUDO", sv.sound ? "Yellow" : "Red", 60f, y3, 285f, 84f, 26f);
                addBtn(B_VIB, sv.vib ? "VIBRA SIM" : "VIBRA NAO", sv.vib ? "Yellow" : "Red", 375f, y3, 285f, 84f, 26f);
                break;
            }
            case SELECT: {
                for (int i = 0; i < Defs.NSHIPS; i++) {
                    addBtn(B_CARD + i, "", "Grey", 60f, 130f + i * 200f, 600f, 188f, 0f);
                }
                addBtn(B_BACK, "VOLTAR", "Red", 160f, Math.max(1140f, H - 128f), 400f, 90f, 40f);
                break;
            }
            case PLAY: {
                addBtn(B_PAUSE, "", "Grey", 320f, ti + 16f, 80f, 80f, 0f);
                addBtn(B_BOMB, "", "Grey", 564f, H - 178f, 132f, 132f, 0f);
                break;
            }
            case PAUSE: {
                float py0 = H / 2f - 360f;
                addBtn(B_RESUME, "CONTINUAR", "Green", 140f, py0 + 150f, 440f, 96f, 38f);
                addBtn(B_RESTART, "REINICIAR", "Blue", 140f, py0 + 270f, 440f, 96f, 38f);
                addBtn(B_SOUND, sv.sound ? "SOM LIGADO" : "SOM MUDO", sv.sound ? "Yellow" : "Red", 140f, py0 + 390f, 440f, 96f, 36f);
                addBtn(B_MENU, "MENU", "Red", 140f, py0 + 510f, 440f, 96f, 38f);
                break;
            }
            case OVER: {
                float py0 = H / 2f - 470f;
                addBtn(B_AGAIN, "JOGAR DE NOVO", "Green", 140f, py0 + 700f, 440f, 96f, 36f);
                addBtn(B_MENU, "MENU", "Blue", 140f, py0 + 812f, 440f, 96f, 38f);
                break;
            }
            case SHOP: {
                for (int i = 0; i < Defs.NUPS; i++) {
                    addBtn(B_UP + i, "", "Grey", 60f, 200f + i * 162f, 600f, 150f, 0f);
                }
                addBtn(B_BACK, "VOLTAR", "Red", 160f, Math.max(1140f, H - 128f), 400f, 90f, 40f);
                break;
            }
            case ACH: {
                addBtn(B_BACK, "VOLTAR", "Red", 160f, Math.max(1136f, H - 124f), 400f, 88f, 40f);
                break;
            }
            default:
                break;
        }
    }

    void setState(int s) {
        state = s;
        moveId = -1;
        layout();
    }

    void buzz(long ms) {
        if (!sv.vib || vibrator == null) {
            return;
        }
        try {
            vibrator.vibrate(ms);
        } catch (Exception e) {
        }
    }

    void buyUpgrade(int i) {
        int lvl = sv.up[i];
        if (lvl >= Defs.UP_MAX[i]) {
            snd.play("back");
            return;
        }
        int cost = Defs.UP_BASE[i] * (lvl + 1);
        if (sv.coins >= cost) {
            sv.coins -= cost;
            sv.up[i]++;
            sv.flush();
            snd.play("powerup", 0.9f, 1.0f);
            buzz(25);
        } else {
            snd.play("back");
        }
    }

    void action(int id) {
        if (id >= B_CARD && id < B_CARD + Defs.NSHIPS) {
            int i = id - B_CARD;
            if (sv.hi >= Defs.SHIP_UNLOCK[i]) {
                sv.ship = i;
                sv.flush();
                pickShip();
                snd.play("start");
            } else {
                snd.play("back");
            }
            return;
        }
        if (id >= B_UP && id < B_UP + Defs.NUPS) {
            buyUpgrade(id - B_UP);
            return;
        }
        switch (id) {
            case B_PLAY:
            case B_RESTART:
            case B_AGAIN:
                snd.play("start");
                startGame();
                break;
            case B_SHIPS:
                snd.play("click");
                setState(SELECT);
                break;
            case B_SHOP:
                snd.play("click");
                setState(SHOP);
                break;
            case B_ACH:
                snd.play("click");
                setState(ACH);
                break;
            case B_DIFF:
                sv.diff = (sv.diff + 1) % 3;
                sv.flush();
                snd.play("click");
                layout();
                break;
            case B_VIB:
                sv.vib = !sv.vib;
                sv.flush();
                snd.play("click");
                buzz(40);
                layout();
                break;
            case B_SOUND:
                sv.sound = !sv.sound;
                sv.flush();
                snd.setEnabled(sv.sound);
                snd.play("click");
                layout();
                break;
            case B_BACK:
                snd.play("back");
                setState(MENU);
                break;
            case B_PAUSE:
                snd.play("click");
                setState(PAUSE);
                break;
            case B_RESUME:
                snd.play("click");
                resumeT = 3f;
                setState(PLAY);
                break;
            case B_MENU:
                snd.play("back");
                toMenu();
                break;
            default:
                break;
        }
    }

    void toMenu() {
        clearWorld();
        sv.flush();
        setState(MENU);
        snd.music("menu.ogg", true, 0.45f);
    }

    void clearWorld() {
        bullets.clear();
        enemies.clear();
        rocks.clear();
        pickups.clear();
        fxs.clear();
        pops.clear();
        boss = null;
        bossAlive = false;
    }

    void startGame() {
        clearWorld();
        pickShip();
        score = 0;
        combo = 0;
        comboT = 0f;
        wave = 0;
        lives = 3;
        weapon = 1;
        bombs = 1 + sv.up[4];
        maxHp = Defs.SHIP_HP[sv.ship] * (1f + 0.12f * sv.up[1]);
        hp = maxHp;
        shieldT = 2.5f;
        invulT = 2.5f;
        fireT = 0.3f;
        bombCD = 0f;
        hitFlash = 0f;
        missileT = 0f;
        missCd = 0f;
        doubleT = 0f;
        resumeT = 0f;
        runCoins = 0;
        runKills = 0;
        achNew = 0;
        toastT = 0f;
        px = 360f;
        py = H - 220f;
        tx = px;
        ty = py;
        roll = 0f;
        alive = true;
        newRecord = false;
        unlockMsg = "";
        startDelay = 1.2f;
        waveActive = false;
        toSpawn = 0;
        waveTotal = 1;
        bossPending = false;
        meteorWave = false;
        rockT = 4f;
        clearT = 0f;
        shakeT = 0f;
        flashT = 0f;
        bannerT = 0f;
        hintT = 5f;
        sv.games++;
        checkAch();
        sv.flush();
        bgBitmapForWave();
        setState(PLAY);
        snd.music("game.ogg", true, 0.4f);
    }

    void bgBitmapForWave() {
        String[] bg = {"darkPurple", "blue", "purple", "black"};
        bBg = A.get("bg/" + bg[Math.max(0, (wave - 1) / 3) % 4] + ".png");
    }

    void gameOver() {
        int oldHi = sv.hi;
        newRecord = score > sv.hi;
        if (newRecord) {
            sv.hi = score;
        }
        if (wave > sv.bestWave) {
            sv.bestWave = wave;
        }
        unlockMsg = "";
        for (int i = 1; i < Defs.NSHIPS; i++) {
            if (oldHi < Defs.SHIP_UNLOCK[i] && sv.hi >= Defs.SHIP_UNLOCK[i]) {
                unlockMsg = "NAVE LIBERADA: " + Defs.SHIP_NAME[i];
            }
        }
        checkAch();
        sv.flush();
        buzz(200);
        setState(OVER);
        snd.music("gameover.ogg", false, 0.5f);
    }

    void processTouch(Touch t) {
        switch (t.type) {
            case 0: {
                Btn b = null;
                for (int i = btns.size() - 1; i >= 0; i--) {
                    if (btns.get(i).contains(t.x, t.y)) {
                        b = btns.get(i);
                        break;
                    }
                }
                if (b != null) {
                    if (b.id == B_BOMB) {
                        useBomb();
                    } else if (pressed == null) {
                        pressed = b;
                        pressedId = t.id;
                    }
                    return;
                }
                if (state == PLAY && moveId < 0 && resumeT <= 0f) {
                    moveId = t.id;
                    offX = px - t.x;
                    offY = Math.max(-300f, Math.min(-120f, py - t.y));
                    tx = t.x + offX;
                    ty = t.y + offY;
                }
                return;
            }
            case 1:
                if (t.id == moveId && state == PLAY) {
                    tx = t.x + offX;
                    ty = t.y + offY;
                }
                return;
            case 2:
                if (t.id == moveId) {
                    moveId = -1;
                }
                if (pressed != null && t.id == pressedId) {
                    Btn b3 = pressed;
                    pressed = null;
                    pressedId = -1;
                    if (b3.contains(t.x, t.y)) {
                        action(b3.id);
                    }
                }
                return;
            default:
                moveId = -1;
                pressed = null;
                pressedId = -1;
                return;
        }
    }

    float aimAngle(float x, float y) {
        if (alive) {
            return (float) Math.atan2(py - y, px - x);
        }
        return 1.5707964f;
    }

    Bitmap enemyBmp(String color, int n) {
        return A.get("enemies/enemy" + color + n + ".png");
    }

    void update(float dt) {
        tick += dt;
        Touch t;
        while ((t = touches.poll()) != null) {
            processTouch(t);
        }
        if (pauseRequest) {
            pauseRequest = false;
            if (state == PLAY) {
                setState(PAUSE);
            }
        }
        if (backRequest) {
            backRequest = false;
            switch (state) {
                case SELECT:
                case SHOP:
                case ACH:
                    snd.play("back");
                    setState(MENU);
                    break;
                case PLAY:
                    setState(PAUSE);
                    break;
                case PAUSE:
                    resumeT = 3f;
                    setState(PLAY);
                    break;
                case OVER:
                    toMenu();
                    break;
                default:
                    break;
            }
        }
        if (state != PAUSE) {
            bgY = (bgY + 60f * dt) % 256f;
            for (int i = 0; i < NSTARS; i++) {
                stY[i] += stV[i] * dt;
                if (stY[i] > H + 20f) {
                    resetStar(i, false);
                }
            }
        }
        if (state == PLAY) {
            updatePlay(dt);
        } else if (state == OVER) {
            updateFx(dt);
        }
    }

    void updateFx(float dt) {
        if (shakeT > 0f) {
            shakeT -= dt;
        }
        if (flashT > 0f) {
            flashT -= dt;
        }
        for (int i = fxs.size() - 1; i >= 0; i--) {
            Fx f = fxs.get(i);
            f.t += dt;
            f.x += f.vx * dt;
            f.y += f.vy * dt;
            f.rot += f.vr * dt;
            if (f.t >= f.life) {
                fxs.remove(i);
            }
        }
        for (int i = pops.size() - 1; i >= 0; i--) {
            Pop p = pops.get(i);
            p.t += dt;
            p.y -= 55f * dt;
            if (p.t > 1f) {
                pops.remove(i);
            }
        }
    }

    float playerDmg() {
        return Defs.SHIP_DMG[sv.ship] * (1f + 0.1f * sv.up[0]);
    }

    Enemy nearestEnemy(float x, float y) {
        Enemy best = null;
        float bd = 1.0E12f;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead || e.y < -30f) {
                continue;
            }
            float dx = e.x - x;
            float dy = e.y - y;
            float d = dx * dx + dy * dy;
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    void steer(Bullet b, float dt) {
        Enemy t = nearestEnemy(b.x, b.y);
        float cur = (float) Math.atan2(b.vy, b.vx);
        if (t != null) {
            float want = (float) Math.atan2(t.y - b.y, t.x - b.x);
            float d = want - cur;
            while (d > PI) {
                d -= TWO_PI;
            }
            while (d < -PI) {
                d += TWO_PI;
            }
            cur += clamp(d, -7f * dt, 7f * dt);
        }
        b.vx = cos(cur) * 560f;
        b.vy = sin(cur) * 560f;
        b.rot = (float) Math.toDegrees(cur) + 90f;
        b.trail -= dt;
        if (b.trail <= 0f) {
            b.trail = 0.04f;
            Fx f = fx(bSmoke, null, b.x, b.y, 0.5f, 0.05f, 0.14f, 0.5f, false);
            f.vy = 20f;
        }
    }

    void updatePlay(float dt) {
        if (resumeT > 0f) {
            resumeT -= dt;
            return;
        }
        updateFx(dt);
        if (bannerT > 0f) {
            bannerT -= dt;
        }
        if (hintT > 0f) {
            hintT -= dt;
        }
        if (toastT > 0f) {
            toastT -= dt;
        }
        if (bombCD > 0f) {
            bombCD -= dt;
        }
        if (doubleT > 0f) {
            doubleT -= dt;
        }
        if (comboT > 0f) {
            comboT -= dt;
            if (comboT <= 0f) {
                combo = 0;
            }
        }
        if (alive) {
            float k = Math.min(1f, 16f * dt * Defs.SHIP_SPD[sv.ship]);
            px += (tx - px) * k;
            py += (ty - py) * k;
            px = clamp(px, 45f, 675f);
            py = clamp(py, ti + 200f, H - 70f);
            tx = clamp(tx, 45f, 675f);
            ty = clamp(ty, ti + 200f, H - 70f);
            roll += (clamp((tx - px) * 0.06f, -14f, 14f) - roll) * Math.min(1f, 10f * dt);
            fireT -= dt;
            if (fireT <= 0f) {
                shootPlayer();
                fireT = Defs.SHIP_FIRE[sv.ship] * (1f - 0.06f * sv.up[2]);
            }
            if (missileT > 0f) {
                missileT -= dt;
                missCd -= dt;
                if (missCd <= 0f) {
                    fireMissiles();
                    missCd = 0.65f;
                }
            }
            if (shieldT > 0f) {
                shieldT -= dt;
            }
            if (invulT > 0f) {
                invulT -= dt;
            }
            if (hitFlash > 0f) {
                hitFlash -= dt;
            }
        } else {
            respT -= dt;
            if (respT <= 0f) {
                if (lives > 0) {
                    respawn();
                } else {
                    gameOver();
                    return;
                }
            }
        }
        for (int i = bullets.size() - 1; i >= 0; i--) {
            Bullet b = bullets.get(i);
            if (b.homing) {
                steer(b, dt);
            }
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            if (b.y < -90f || b.y > H + 90f || b.x < -90f || b.x > 810f) {
                bullets.remove(i);
            } else if (b.mine) {
                boolean used = false;
                for (int j = 0; j < enemies.size() && !used; j++) {
                    Enemy e = enemies.get(j);
                    if (!e.dead && hit(b.x, b.y, b.r, e.x, e.y, e.r)) {
                        damageEnemy(e, b.dmg, b.x, b.y);
                        used = true;
                    }
                }
                for (int j = 0; j < rocks.size() && !used; j++) {
                    Rock r = rocks.get(j);
                    if (!r.dead && hit(b.x, b.y, b.r, r.x, r.y, r.r)) {
                        damageRock(r, b.dmg, b.x, b.y);
                        used = true;
                    }
                }
                if (used) {
                    bullets.remove(i);
                }
            } else if (alive && hit(b.x, b.y, b.r, px, py, 20f)) {
                hurtPlayer(b.dmg);
                bullets.remove(i);
            }
        }
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            if (e.dead) {
                enemies.remove(i);
                continue;
            }
            updateEnemy(e, dt);
            if (e.dead) {
                enemies.remove(i);
            } else if (e.y > H + 140f || e.x < -200f || e.x > 920f) {
                enemies.remove(i);
            } else if (alive && hit(e.x, e.y, 0.85f * e.r, px, py, PR)) {
                hurtPlayer(e.boss ? 35f : (e.kind == K_SWARM ? 12f : 25f));
                if (!e.boss) {
                    killEnemy(e);
                }
            }
        }
        for (int i = rocks.size() - 1; i >= 0; i--) {
            Rock r = rocks.get(i);
            if (r.dead) {
                rocks.remove(i);
                continue;
            }
            r.x += r.vx * dt;
            r.y += r.vy * dt;
            r.rot += r.vr * dt;
            if (r.flash > 0f) {
                r.flash -= dt;
            }
            if (r.y > H + 120f || r.x < -150f || r.x > 870f) {
                rocks.remove(i);
            } else if (alive && hit(r.x, r.y, 0.9f * r.r, px, py, PR)) {
                hurtPlayer(r.size == 2 ? 24f : (r.size == 1 ? 12f : 6f));
                breakRock(r, false);
            }
        }
        float magR = 190f + 45f * sv.up[3];
        float magV = 430f + 90f * sv.up[3];
        for (int i = pickups.size() - 1; i >= 0; i--) {
            Pickup p = pickups.get(i);
            p.t += dt;
            p.y += 110f * dt;
            p.x += sin(p.t * 3f) * 30f * dt;
            if (alive) {
                float dx = px - p.x;
                float dy = py - p.y;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < magR && d > 1f) {
                    p.x += dx / d * magV * dt;
                    p.y += dy / d * magV * dt;
                }
                if (hit(p.x, p.y, PR, px, py, 32f)) {
                    collect(p);
                    pickups.remove(i);
                    continue;
                }
            }
            if (p.y > H + 60f) {
                pickups.remove(i);
            }
        }
        if (startDelay > 0f) {
            startDelay -= dt;
            if (startDelay <= 0f) {
                startWave();
            }
            return;
        }
        rockT -= dt;
        if (rockT <= 0f) {
            if (meteorWave) {
                spawnRock(rnd.nextInt(3) == 0 ? 2 : 1, -1f, -1f);
                rockT = 0.3f + rnd.nextFloat() * 0.35f;
            } else {
                spawnRock(rnd.nextInt(2) == 0 ? 1 : 2, -1f, -1f);
                rockT = Math.max(1.3f, 3.6f - wave * 0.1f) + rnd.nextFloat() * 1.6f;
            }
            if (bossAlive) {
                rockT += 3f;
            }
        }
        if (waveActive) {
            spawnTimer -= dt;
            if (spawnTimer <= 0f && (toSpawn > 0 || bossPending)) {
                if (bossPending) {
                    spawnBoss();
                    bossPending = false;
                    spawnTimer = 3f;
                } else {
                    spawnUnit();
                    toSpawn--;
                    spawnTimer = Math.max(0.35f, 1.15f - wave * 0.04f) + rnd.nextFloat() * 0.35f;
                }
            }
            if (toSpawn <= 0 && !bossPending && enemies.isEmpty()) {
                waveActive = false;
                clearT = 2.4f;
                snd.play("levelup", 0.7f, 1.1f);
                int bonus = (int) (wave * 100 * Defs.DIFF_SCORE[sv.diff]);
                score += bonus;
                hp = Math.min(maxHp, hp + 12f);
                addCoins(wave * 3);
                popText("BONUS +" + bonus, 360f, H * 0.42f, C_GRN);
                if (bossAlive) {
                    bossAlive = false;
                    boss = null;
                }
                checkAch();
            }
            return;
        }
        clearT -= dt;
        if (clearT <= 0f) {
            startWave();
        }
    }

    void respawn() {
        alive = true;
        hp = maxHp;
        px = 360f;
        py = H - 200f;
        tx = px;
        ty = py;
        invulT = 3f;
        shieldT = 3f;
        snd.play("shield", 0.8f, 0.8f);
    }

    void startWave() {
        wave++;
        if (wave > sv.bestWave) {
            sv.bestWave = wave;
        }
        bgBitmapForWave();
        waveActive = true;
        boolean bw = wave % 5 == 0;
        meteorWave = !bw && wave % 4 == 0;
        bossPending = bw;
        float cnt = Defs.DIFF_CNT[sv.diff];
        int n = bw ? (wave / 5) * 2 + 3 : Math.min(40, wave * 2 + 5);
        n = Math.max(2, Math.round(n * cnt));
        if (meteorWave) {
            n = n / 2 + 2;
        }
        toSpawn = n;
        waveTotal = n + (bw ? 1 : 0);
        spawnTimer = 1.2f;
        bannerBoss = bw || meteorWave;
        bannerText = bw ? "ALERTA CHEFE" : (meteorWave ? "CHUVA DE METEOROS" : "ONDA " + wave);
        bannerMax = 2.4f;
        bannerT = 2.4f;
        if (bw || meteorWave) {
            snd.play("warning", 1f, 1f);
        } else {
            snd.play("levelup", 0.6f, 1f);
        }
        if (bw) {
            snd.music("boss.ogg", true, 0.45f);
        } else {
            snd.music("game.ogg", true, 0.4f);
        }
        checkAch();
    }

    void shootPlayer() {
        float d = playerDmg();
        float y = py - 30f;
        switch (weapon) {
            case 1:
                pb(px, y, 0f, d);
                break;
            case 2:
                pb(px - 14f, y, 0f, d * 0.8f);
                pb(px + 14f, y, 0f, d * 0.8f);
                break;
            case 3:
                pb(px, y - 8f, 0f, d * 0.8f);
                pb(px - 20f, y, -9f, d * 0.7f);
                pb(px + 20f, y, 9f, d * 0.7f);
                break;
            case 4:
                pb(px - 12f, y - 6f, 0f, d * 0.75f);
                pb(px + 12f, y - 6f, 0f, d * 0.75f);
                pb(px - 28f, y, -12f, d * 0.65f);
                pb(px + 28f, y, 12f, d * 0.65f);
                break;
            default:
                pb(px, y - 10f, 0f, d * 0.8f);
                pb(px - 18f, y - 4f, -7f, d * 0.7f);
                pb(px + 18f, y - 4f, 7f, d * 0.7f);
                pb(px - 34f, y + 2f, -16f, d * 0.6f);
                pb(px + 34f, y + 2f, 16f, d * 0.6f);
                break;
        }
        snd.play("shoot" + (Defs.SHIP_MODEL[sv.ship]), 0.3f, 1f);
        Fx f = fx(bMuzzle, null, px, y - 6f, 0.09f, 0.1f, 0.16f, 0.9f, true);
        f.vy = -40f;
    }

    void pb(float x, float y, float angDeg, float dmg) {
        Bullet b = new Bullet();
        float a = (float) Math.toRadians(angDeg);
        b.x = x;
        b.y = y;
        b.vx = sin(a) * 950f;
        b.vy = -cos(a) * 950f;
        b.mine = true;
        b.dmg = dmg;
        b.r = 12f;
        b.rot = angDeg;
        b.bmp = bPlayerLaser;
        bullets.add(b);
    }

    void fireMissiles() {
        float d = playerDmg();
        for (int k = -1; k <= 1; k += 2) {
            Bullet b = new Bullet();
            b.x = px + k * 26f;
            b.y = py - 10f;
            b.vx = k * 180f;
            b.vy = -420f;
            b.mine = true;
            b.homing = true;
            b.dmg = 3f * d;
            b.r = 14f;
            b.bmp = bMissile;
            bullets.add(b);
        }
        snd.play("shoot3", 0.25f, 1.4f);
    }

    void eb(float x, float y, float ang, float spd) {
        Bullet b = new Bullet();
        b.x = x;
        b.y = y;
        b.vx = cos(ang) * spd;
        b.vy = sin(ang) * spd;
        b.mine = false;
        b.dmg = Math.min(10f, wave / 2f) + 10f;
        b.r = 11f;
        b.rot = (float) Math.toDegrees(ang) - 90f;
        b.bmp = bEnemyLaser;
        bullets.add(b);
    }

    void hurtPlayer(float d) {
        if (!alive || invulT > 0f) {
            return;
        }
        if (shieldT > 0f) {
            snd.play("shield", 0.7f, 1.2f);
            fx(bLight, null, px, py, 0.25f, 0.5f, 0.9f, 0.9f, true);
            invulT = 0.15f;
            return;
        }
        hp -= d * Defs.DIFF_DMG[sv.diff];
        hitFlash = 0.3f;
        invulT = 0.5f;
        shakeT = 0.3f;
        shakeAmp = 10f;
        combo = 0;
        snd.play("hit", 0.9f, 1f);
        buzz(35);
        sparks(px, py - 10f, 6);
        if (hp <= 0f) {
            killPlayer();
        }
    }

    void killPlayer() {
        alive = false;
        lives--;
        weapon = Math.max(1, weapon - 1);
        combo = 0;
        respT = 1.7f;
        explode(px, py, 1.9f);
        fx(null, expSonic, px, py, 0.6f, 1.6f, 3.4f, 1f, false);
        snd.play("explode_big", 1f, 0.9f);
        buzz(120);
        shakeT = 0.6f;
        shakeAmp = 16f;
    }

    void useBomb() {
        if (state != PLAY || !alive || bombs <= 0 || bombCD > 0f || resumeT > 0f) {
            return;
        }
        bombs--;
        bombCD = 1f;
        snd.play("bomb", 1f, 1f);
        buzz(90);
        fx(null, expSonic, px, py, 0.75f, 3.5f, 9f, 1f, false);
        flashT = 0.5f;
        shakeT = 0.6f;
        shakeAmp = 14f;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (!e.dead) {
                damageEnemy(e, e.boss ? 20f : 14f, e.x, e.y);
            }
        }
        for (int i = rocks.size() - 1; i >= 0; i--) {
            Rock r = rocks.get(i);
            if (!r.dead && r.y > -40f) {
                breakRock(r, true);
            }
        }
        for (int i = bullets.size() - 1; i >= 0; i--) {
            Bullet b = bullets.get(i);
            if (!b.mine) {
                if (rnd.nextInt(3) == 0) {
                    fx(bSpark, null, b.x, b.y, 0.3f, 0.12f, 0.25f, 1f, true);
                }
                bullets.remove(i);
            }
        }
    }

    void collect(Pickup p) {
        fx(bStar4, null, p.x, p.y, 0.4f, 0.1f, 0.4f, 1f, true);
        switch (p.kind) {
            case P_SHIELD:
                shieldT = 8f;
                snd.play("shield", 0.9f, 1f);
                popText("ESCUDO", p.x, p.y, C_BLU);
                break;
            case P_WEAPON:
                if (weapon < 5) {
                    weapon++;
                    popText("ARMA NIVEL " + weapon, p.x, p.y, C_LIME);
                } else {
                    score += 500;
                    popText("+500", p.x, p.y, C_YEL);
                }
                snd.play("powerup", 0.9f, 1f);
                break;
            case P_HEAL:
                hp = Math.min(maxHp, hp + 40f);
                snd.play("heal", 0.9f, 1f);
                popText("REPARO", p.x, p.y, C_GRN);
                break;
            case P_BOMB:
                bombs = Math.min(5, bombs + 1);
                snd.play("powerup", 0.9f, 1.3f);
                popText("BOMBA", p.x, p.y, C_PINK);
                break;
            case P_MISSILE:
                missileT = 12f;
                missCd = 0f;
                snd.play("powerup", 0.9f, 0.8f);
                popText("MISSEIS", p.x, p.y, C_LIME);
                break;
            case P_DOUBLE:
                doubleT = 12f;
                snd.play("powerup", 0.9f, 1.6f);
                popText("PONTOS X2", p.x, p.y, C_YEL);
                break;
            default: {
                int pts = (Math.min(4, combo / 5) + 1) * 100;
                if (doubleT > 0f) {
                    pts *= 2;
                }
                score += pts;
                addCoins(Math.round(3f * Defs.DIFF_COIN[sv.diff]));
                snd.play("coin", 0.7f, 1f);
                popText("+" + pts, p.x, p.y, C_YEL);
                break;
            }
        }
    }

    void dropPickup(float x, float y, int kind) {
        Pickup p = new Pickup();
        p.kind = kind;
        p.x = x;
        p.y = y;
        pickups.add(p);
    }

    int randPower() {
        int[] pool = {P_SHIELD, P_SHIELD, P_WEAPON, P_WEAPON, P_HEAL, P_BOMB, P_MISSILE, P_MISSILE, P_DOUBLE};
        return pool[rnd.nextInt(pool.length)];
    }

    int pickKind() {
        float[] w = {4f, wave >= 2 ? 3f : 0f, wave >= 3 ? 3f : 0f, wave >= 4 ? 2f : 0f, wave >= 6 ? 1.5f : 0f, wave >= 3 ? 1f : 0f, 0f, wave >= 5 ? 1.5f : 0f};
        float sum = 0f;
        for (float v : w) {
            sum += v;
        }
        float r = rnd.nextFloat() * sum;
        for (int i = 0; i < w.length; i++) {
            r -= w[i];
            if (r <= 0f && w[i] > 0f) {
                return i;
            }
        }
        return 0;
    }

    void spawnUnit() {
        if (wave >= 3 && rnd.nextFloat() < 0.16f) {
            spawnFormation();
        } else {
            enemies.add(makeEnemy(pickKind()));
        }
    }

    void spawnFormation() {
        float cx = 200f + rnd.nextFloat() * 320f;
        for (int i = -2; i <= 2; i++) {
            Enemy e = makeEnemy(K_SWARM);
            e.baseX = cx + i * 70f;
            e.x = e.baseX;
            e.y = -60f - Math.abs(i) * 55f;
            enemies.add(e);
        }
    }

    Enemy makeEnemy(int kind) {
        Enemy e = new Enemy();
        e.kind = kind;
        e.sc = 0.95f;
        e.y = -60f;
        e.x = rnd.nextFloat() * 600f + 60f;
        e.baseX = clamp(e.x, 180f, 540f);
        e.shoot = rnd.nextFloat() + 0.8f;
        int n = rnd.nextInt(3) + 1;
        String[] cols = {"Black", "Blue", "Green", "Red"};
        switch (kind) {
            case K_DRONE:
                e.bmp = enemyBmp("Black", n);
                e.hp = (wave / 5) + 1f;
                e.vy = Math.min(320f, wave * 5f + 150f);
                e.score = 50;
                break;
            case K_ZIG:
                e.bmp = enemyBmp("Blue", n);
                e.hp = (wave / 6) + 2f;
                e.vy = Math.min(240f, wave * 3f + 120f);
                e.score = 90;
                break;
            case K_SHOOT:
                e.bmp = enemyBmp("Green", n);
                e.hp = (wave / 4) + 3f;
                e.hoverY = rnd.nextFloat() * 170f + 140f;
                e.score = 140;
                break;
            case K_KAMI:
                e.bmp = enemyBmp("Red", n);
                e.hp = (wave / 8) + 2f;
                e.score = 110;
                break;
            case K_TANK:
                e.bmp = enemyBmp(cols[rnd.nextInt(4)], 4);
                e.hp = (wave / 2) + 9f;
                e.vy = 70f;
                e.sc = 1.2f;
                e.hoverY = rnd.nextFloat() * 100f + 130f;
                e.score = 300;
                e.shoot = 1.5f;
                break;
            case K_BOMBER:
                e.bmp = enemyBmp(cols[rnd.nextInt(4)], 3);
                e.hp = (wave / 3) + 6f;
                e.vy = 85f;
                e.sc = 1.35f;
                e.hoverY = rnd.nextFloat() * 90f + 120f;
                e.score = 260;
                e.shoot = 1.8f;
                break;
            case K_SWARM:
                e.bmp = enemyBmp(cols[rnd.nextInt(4)], 1);
                e.hp = 1f;
                e.vy = 260f;
                e.sc = 0.7f;
                e.score = 30;
                break;
            default: {
                String[] u = {"Blue", "Green", "Red", "Yellow"};
                e.kind = K_UFO;
                e.bmp = A.get("enemies/ufo" + u[rnd.nextInt(4)] + ".png");
                e.hp = (wave / 5) + 4f;
                e.vy = 110f;
                e.score = 200;
                e.sc = 0.95f;
                break;
            }
        }
        e.hp *= Defs.DIFF_HP[sv.diff];
        e.maxHp = e.hp;
        e.r = e.bmp.getWidth() * 0.4f * e.sc;
        return e;
    }

    void spawnBoss() {
        Enemy e = new Enemy();
        int lvl = Math.max(1, wave / 5);
        String[] n = {"Red", "Black", "Blue", "Green"};
        e.kind = K_BOSS;
        e.boss = true;
        e.bmp = enemyBmp(n[(lvl - 1) % 4], 5);
        e.sc = 2.6f;
        e.hp = (lvl * 35f + 60f) * Defs.DIFF_HP[sv.diff];
        e.maxHp = e.hp;
        e.x = 360f;
        e.y = -220f;
        e.r = e.bmp.getWidth() * 0.38f * e.sc;
        e.score = lvl * 2500;
        e.shoot = 2f;
        e.hoverY = 2f;
        e.minionT = 5f;
        enemies.add(e);
        boss = e;
        bossAlive = true;
    }

    void updateEnemy(Enemy e, float dt) {
        e.t += dt;
        if (e.flash > 0f) {
            e.flash -= dt;
        }
        float spd = Math.min(0.8f, wave * 0.03f) + 1f;
        switch (e.kind) {
            case K_DRONE:
                e.y += e.vy * dt;
                break;
            case K_ZIG:
                e.y += e.vy * dt;
                e.x = e.baseX + sin(e.t * 2.4f) * 130f;
                break;
            case K_SHOOT:
                if (e.y < e.hoverY) {
                    e.y += 150f * dt;
                } else {
                    e.x = e.baseX + sin(e.t * 1.1f) * 201.6f;
                    if (e.t > 12f) {
                        e.y += 220f * dt;
                    }
                }
                e.shoot -= dt;
                if (e.shoot <= 0f && e.y > 40f) {
                    eb(e.x, e.y + e.r * 0.7f, aimAngle(e.x, e.y), 330f * spd);
                    e.shoot = 2f / spd + rnd.nextFloat() * 0.6f;
                }
                break;
            case K_KAMI:
                if (e.t < 0.8f || !alive) {
                    e.y += (alive ? 120f : 320f) * dt;
                } else {
                    float dx = px - e.x;
                    float dy = py - e.y;
                    float d = Math.max(1f, (float) Math.sqrt(dx * dx + dy * dy));
                    e.vx += (dx / d * 420f - e.vx) * dt * 2.2f;
                    e.vy += (dy / d * 420f - e.vy) * dt * 2.2f;
                    e.x += e.vx * dt;
                    e.y += e.vy * dt;
                }
                e.rot = clamp(-e.vx * 0.08f, -35f, 35f);
                break;
            case K_TANK:
                if (e.y < e.hoverY) {
                    e.y += e.vy * dt;
                } else {
                    e.x += sin(e.t * 0.7f) * 70f * dt;
                    if (e.t > 14f) {
                        e.y += 120f * dt;
                    }
                }
                e.shoot -= dt;
                if (e.shoot <= 0f && e.y > 40f) {
                    float a = aimAngle(e.x, e.y);
                    for (int k = -1; k <= 1; k++) {
                        eb(e.x, e.y + e.r * 0.6f, k * 0.3f + a, 300f * spd);
                    }
                    e.shoot = 2.3f / spd;
                }
                break;
            case K_UFO:
                e.y += e.vy * dt;
                e.x = e.baseX + sin(e.t * 3.2f) * 180f;
                e.rot = sin(e.t * 3.2f) * 12f;
                e.shoot -= dt;
                if (e.shoot <= 0f && e.y > 30f) {
                    eb(e.x, e.y + e.r * 0.5f, aimAngle(e.x, e.y), 360f * spd);
                    e.shoot = 1.8f / spd;
                }
                break;
            case K_BOMBER:
                if (e.y < e.hoverY) {
                    e.y += e.vy * dt;
                } else {
                    e.x = e.baseX + sin(e.t * 0.9f) * 150f;
                    if (e.t > 13f) {
                        e.y += 140f * dt;
                    }
                }
                e.shoot -= dt;
                if (e.shoot <= 0f && e.y > 40f) {
                    for (int k = -2; k <= 2; k++) {
                        eb(e.x, e.y + e.r * 0.6f, 1.5707964f + k * 0.28f, 280f * spd);
                    }
                    e.shoot = 2.2f / spd;
                }
                break;
            case K_SWARM:
                e.y += e.vy * dt;
                e.x = e.baseX + sin(e.t * 5f) * 30f;
                break;
            default:
                updateBoss(e, dt);
                break;
        }
    }

    void updateBoss(Enemy e, float dt) {
        if (e.y < 190f) {
            e.y += 100f * dt;
            return;
        }
        e.x = sin(e.t * 0.8f) * 170f + 360f;
        e.y = sin(e.t * 1.3f) * 30f + 190f;
        float ratio = e.hp / e.maxHp;
        int ph = ratio > 0.66f ? 0 : (ratio > 0.33f ? 1 : 2);
        if (ph != e.phase) {
            e.phase = ph;
            shakeT = 0.5f;
            shakeAmp = 12f;
            snd.play("explode_big", 1f, 0.8f);
            explode(e.x, e.y, 1.6f);
        }
        int bv = (Math.max(1, wave / 5) - 1) % 3;
        e.shoot -= dt;
        if (e.shoot <= 0f) {
            float a = aimAngle(e.x, e.y);
            if (bv == 0) {
                if (ph == 0) {
                    for (int k = -1; k <= 1; k++) {
                        eb(e.x, e.y + 60f, k * 0.28f + a, 300f);
                    }
                    e.shoot = 1f;
                } else if (ph == 2) {
                    e.spin += 0.55f;
                    eb(e.x, e.y + 40f, e.spin, 260f);
                    eb(e.x, e.y + 40f, e.spin + PI, 260f);
                    e.shoot = 0.16f;
                } else {
                    for (int i = 0; i < 14; i++) {
                        eb(e.x, e.y + 40f, e.spin + i * TWO_PI / 14f, 230f);
                    }
                    e.spin += 0.2f;
                    eb(e.x, e.y + 60f, a, 340f);
                    e.shoot = 1.4f;
                }
            } else if (bv == 1) {
                if (ph == 0) {
                    for (int k = -2; k <= 2; k++) {
                        eb(e.x, e.y + 60f, a + k * 0.22f, 290f);
                    }
                    e.shoot = 1.1f;
                } else if (ph == 1) {
                    e.spin += 0.45f;
                    for (int k = 0; k < 3; k++) {
                        eb(e.x, e.y + 40f, e.spin + k * 2.0943951f, 250f);
                    }
                    e.shoot = 0.2f;
                } else {
                    for (int i = 0; i < 18; i++) {
                        eb(e.x, e.y + 40f, e.spin + i * TWO_PI / 18f, 220f);
                    }
                    e.spin += 0.17f;
                    for (int k = -1; k <= 1; k++) {
                        eb(e.x, e.y + 60f, a + k * 0.18f, 340f);
                    }
                    e.shoot = 1.25f;
                }
            } else {
                if (ph == 0) {
                    eb(e.x - 70f, e.y + 50f, 1.5707964f, 340f);
                    eb(e.x + 70f, e.y + 50f, 1.5707964f, 340f);
                    e.shoot = 0.4f;
                } else if (ph == 1) {
                    for (int k = -1; k <= 1; k++) {
                        eb(e.x, e.y + 60f, a + k * 0.25f, 320f);
                    }
                    e.shoot = 0.9f;
                } else {
                    for (int i = 0; i < 20; i++) {
                        eb(e.x, e.y + 40f, e.spin + i * TWO_PI / 20f, 230f);
                    }
                    e.spin += 0.15f;
                    eb(e.x - 40f, e.y + 60f, a, 360f);
                    eb(e.x + 40f, e.y + 60f, a, 360f);
                    e.shoot = 1.1f;
                }
            }
            snd.play("shoot3", 0.25f, 0.8f);
        }
        if (ph == 2) {
            e.hoverY -= dt;
            if (e.hoverY <= 0f) {
                float a2 = aimAngle(e.x, e.y);
                for (int k = -2; k <= 2; k++) {
                    eb(e.x, e.y + 60f, k * 0.2f + a2, 330f);
                }
                e.hoverY = 1.8f;
            }
        }
        if (ph >= 1) {
            e.minionT -= dt;
            if (e.minionT <= 0f && enemies.size() < 10) {
                for (int i = 0; i < 2; i++) {
                    Enemy m = makeEnemy(K_SWARM);
                    m.baseX = e.x + (i == 0 ? -90f : 90f);
                    m.x = m.baseX;
                    m.y = e.y + 40f;
                    enemies.add(m);
                }
                e.minionT = 6f;
            }
        }
    }

    void damageEnemy(Enemy e, float dmg, float x, float y) {
        if (e.dead) {
            return;
        }
        e.hp -= dmg;
        e.flash = 0.07f;
        fx(bSpark, null, x, y, 0.2f, 0.07f, 0.16f, 1f, true).rot = rnd.nextFloat() * 360f;
        if (e.hp > 0f) {
            snd.play("enemy_hit", 0.35f, rnd.nextFloat() * 0.3f + 0.9f);
        } else {
            killEnemy(e);
        }
    }

    void killEnemy(Enemy e) {
        if (e.dead) {
            return;
        }
        e.dead = true;
        sv.kills++;
        runKills++;
        addScore(e.score, e.x, e.y);
        if (!e.boss) {
            float s = e.kind == K_TANK ? 1.5f : (e.kind == K_SWARM ? 0.6f : 1f);
            explode(e.x, e.y, s);
            snd.play(e.kind == K_TANK ? "explode_big" : "explode_small", 0.8f, rnd.nextFloat() * 0.2f + 0.95f);
            if (e.kind == K_UFO) {
                dropPickup(e.x, e.y, randPower());
                return;
            }
            float r = rnd.nextFloat();
            if (e.kind == K_SWARM) {
                if (r < 0.06f) {
                    dropPickup(e.x, e.y, P_COIN);
                }
                return;
            }
            if (r < 0.08f) {
                dropPickup(e.x, e.y, randPower());
            } else if (r < 0.28f) {
                dropPickup(e.x, e.y, P_COIN);
            }
            return;
        }
        for (int i = 0; i < 9; i++) {
            float ox = (rnd.nextFloat() - 0.5f) * e.r * 1.6f;
            float oy = (rnd.nextFloat() - 0.5f) * e.r * 1.2f;
            Fx f = explode(e.x + ox, e.y + oy, rnd.nextFloat() * 0.8f + 1.2f);
            f.t = -i * 0.12f;
        }
        fx(null, expSonic, e.x, e.y, 0.8f, 2f, 6f, 1f, false).t = -0.5f;
        snd.play("explode_big", 1f, 0.7f);
        buzz(250);
        flashT = 0.6f;
        shakeT = 0.9f;
        shakeAmp = 16f;
        int lvl = Math.max(1, wave / 5);
        sv.bosses++;
        addCoins(Math.round(25f * lvl * Defs.DIFF_COIN[sv.diff]));
        popText("CHEFE DERROTADO", 360f, H * 0.34f, C_YEL);
        dropPickup(e.x - 50f, e.y, P_WEAPON);
        dropPickup(e.x, e.y, P_SHIELD);
        dropPickup(e.x + 50f, e.y, P_BOMB);
        dropPickup(e.x - 100f, e.y, P_MISSILE);
        dropPickup(e.x + 100f, e.y, P_DOUBLE);
        for (int i = bullets.size() - 1; i >= 0; i--) {
            if (!bullets.get(i).mine) {
                bullets.remove(i);
            }
        }
        bossAlive = false;
        boss = null;
        checkAch();
        sv.flush();
        snd.music("game.ogg", true, 0.4f);
    }

    void addScore(int base, float x, float y) {
        int mult = Math.min(4, combo / 5) + 1;
        int p = (int) (base * mult * Defs.DIFF_SCORE[sv.diff]);
        if (doubleT > 0f) {
            p *= 2;
        }
        score += p;
        combo++;
        if (combo > sv.bestCombo) {
            sv.bestCombo = combo;
        }
        comboT = 2.5f;
        popText("+" + p, x, y, (mult > 1 || doubleT > 0f) ? C_YEL : C_WHITE);
    }

    void addCoins(int n) {
        if (n <= 0) {
            return;
        }
        runCoins += n;
        sv.coins += n;
        sv.totalCoins += n;
    }

    void toast(String s) {
        toastS = s;
        toastT = 3f;
    }

    void checkAch() {
        for (int i = 0; i < Defs.ACH_NAME.length; i++) {
            if ((sv.ach & (1 << i)) != 0) {
                continue;
            }
            if (sv.stat(Defs.ACH_STAT[i]) >= Defs.ACH_GOAL[i]) {
                sv.ach |= 1 << i;
                sv.coins += Defs.ACH_REWARD[i];
                achNew++;
                toast("CONQUISTA: " + Defs.ACH_NAME[i]);
                snd.play("levelup", 0.8f, 1.2f);
            }
        }
    }

    void popText(String s, float x, float y, int color) {
        if (pops.size() > 14) {
            pops.remove(0);
        }
        Pop p = new Pop();
        p.s = s;
        p.x = x;
        p.y = y;
        p.color = color;
        pops.add(p);
    }

    void spawnRock(int size, float x, float y) {
        String[] src = size == 2 ? ROCK_BIG : (size == 1 ? ROCK_SMALL : ROCK_TINY);
        Rock r = new Rock();
        r.size = size;
        r.bmp = A.get("meteors/" + src[rnd.nextInt(src.length)] + ".png");
        r.hp = size == 2 ? (wave / 10) + 5f : (size == 1 ? 2f : 1f);
        r.r = r.bmp.getWidth() * 0.42f;
        r.x = x < 0f ? rnd.nextFloat() * 620f + 50f : x;
        r.y = y < 0f ? -80f : y;
        r.vx = (rnd.nextFloat() - 0.5f) * 140f;
        r.vy = rnd.nextFloat() * 100f + 120f + wave * 4f;
        r.vr = (rnd.nextFloat() - 0.5f) * 220f;
        rocks.add(r);
    }

    void damageRock(Rock r, float dmg, float x, float y) {
        r.hp -= dmg;
        r.flash = 0.06f;
        fx(bSpark, null, x, y, 0.2f, 0.06f, 0.13f, 1f, true);
        if (r.hp > 0f) {
            snd.play("enemy_hit", 0.25f, 0.7f);
        } else {
            breakRock(r, true);
        }
    }

    void breakRock(Rock r, boolean byPlayer) {
        if (r.dead) {
            return;
        }
        r.dead = true;
        explode(r.x, r.y, r.size == 2 ? 0.8f : (r.size == 1 ? 0.5f : 0.3f));
        snd.play("explode_small", r.size == 2 ? 0.6f : 0.35f, r.size == 2 ? 0.8f : 1.1f);
        if (byPlayer) {
            int pts = r.size == 2 ? 20 : (r.size == 1 ? 10 : 5);
            score += doubleT > 0f ? pts * 2 : pts;
            if (meteorWave) {
                if (rnd.nextFloat() < 0.18f) {
                    dropPickup(r.x, r.y, P_COIN);
                }
            } else if (r.size == 2 && rnd.nextFloat() < 0.12f) {
                dropPickup(r.x, r.y, P_COIN);
            }
        }
        if (r.size > 0) {
            for (int i = 0; i < 2; i++) {
                spawnRock(r.size - 1, r.x + (i == 0 ? -14f : 14f), r.y);
                Rock c = rocks.get(rocks.size() - 1);
                c.vx = (i == 0 ? -1 : 1) * (rnd.nextFloat() * 80f + 60f);
            }
        }
    }

    Fx fx(Bitmap bmp, Bitmap[] frames, float x, float y, float life, float s0, float s1, float a0, boolean add) {
        Fx f = new Fx();
        f.bmp = bmp;
        f.frames = frames;
        f.x = x;
        f.y = y;
        f.life = life;
        f.s0 = s0;
        f.s1 = s1;
        f.a0 = a0;
        f.add = add;
        if (fxs.size() > 160) {
            fxs.remove(0);
        }
        fxs.add(f);
        return f;
    }

    Fx explode(float x, float y, float scale) {
        Fx f = fx(null, expReg, x, y, 0.6f, scale, scale * 1.15f, 1f, false);
        f.rot = rnd.nextFloat() * 360f;
        sparks(x, y, (int) (3f * scale) + 4);
        Fx s = fx(bSmoke, null, x, y, 0.9f, scale * 0.08f, scale * 0.28f, 0.5f, false);
        s.vy = 30f;
        s.vr = 40f;
        if (scale > 1.2f) {
            fx(bLight, null, x, y, 0.3f, scale * 0.35f, scale * 0.7f, 0.9f, true);
            if (shakeT < 0.25f) {
                shakeT = 0.25f;
                shakeAmp = 6f;
            }
        }
        return f;
    }

    void sparks(float x, float y, int n) {
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * TWO_PI;
            float v = rnd.nextFloat() * 260f + 90f;
            Fx f = fx(bSpark, null, x, y, rnd.nextFloat() * 0.3f + 0.35f, rnd.nextFloat() * 0.06f + 0.06f, 0.02f, 1f, true);
            f.vx = cos(a) * v;
            f.vy = sin(a) * v;
            f.rot = rnd.nextFloat() * 360f;
        }
    }

    void ensureShip() {
        if (cachedShip != sv.ship || bStarOn == null) {
            cachedShip = sv.ship;
            bLife = A.get("ui/playerLife" + Defs.SHIP_MODEL[sv.ship] + "_" + Defs.SHIP_COLOR[sv.ship] + ".png");
            for (int d = 0; d < 3; d++) {
                bDmg[d] = A.get("damage/playerShip" + Defs.SHIP_MODEL[sv.ship] + "_damage" + (d + 1) + ".png");
            }
            bShield = A.get("fx/shield3.png");
            bStarOn = A.get("powerups/star_gold.png");
            bStarOff = A.get("powerups/star_silver.png");
            for (int i = 0; i < 3; i++) {
                bStars[i] = A.get("fx/star" + (i + 1) + ".png");
            }
        }
    }

    void render(Canvas c) {
        ensureShip();
        c.save();
        c.scale(sc, sc);
        drawBackground(c);
        switch (state) {
            case MENU:
                drawMenu(c);
                break;
            case SELECT:
                drawSelect(c);
                break;
            case SHOP:
                drawShop(c);
                break;
            case ACH:
                drawAch(c);
                break;
            default:
                drawWorld(c);
                drawHud(c);
                if (state == PAUSE) {
                    drawPause(c);
                } else if (state == OVER) {
                    drawOver(c);
                }
                break;
        }
        c.restore();
    }

    void drawBackground(Canvas c) {
        for (float y = bgY - 256f; y < H; y += 256f) {
            for (float x = 0f; x < W; x += 256f) {
                d9.set(x, y, x + 257f, y + 257f);
                c.drawBitmap(bBg, null, d9, pSpr);
            }
        }
        for (int i = 0; i < NSTARS; i++) {
            sprA(c, bStars[stI[i]], stX[i], stY[i], stS[i], 0f, stS[i] * 0.45f + 0.35f, false);
        }
    }

    void drawShipIdx(Canvas c, int idx, float x, float y, float s, float alpha) {
        Bitmap b = A.get(shipFile(idx));
        thruster(c, b, x, y, s, alpha);
        sprA(c, b, x, y, s, 0f, alpha, false);
    }

    void drawBtnPill(Canvas c, Btn b) {
        boolean pr = b == pressed;
        float k = pr ? 0.95f : 1f;
        float w = b.w * k;
        float h = b.h * k;
        float x = b.x + (b.w - w) / 2f;
        float y = b.y + (b.h - h) / 2f + (pr ? 3f : 0f);
        pill(c, "Grey", x, y + 8f, w, h, 120);
        pill(c, b.color, x, y, w, h, 255);
        text(c, b.label, x + w / 2f, y + h / 2f + b.textSize * 0.36f, b.textSize, C_WHITE, 1, true);
    }

    void drawButtons(Canvas c) {
        for (int i = 0; i < btns.size(); i++) {
            Btn b = btns.get(i);
            if (b.textSize > 0f) {
                drawBtnPill(c, b);
            }
        }
    }

    void drawBtnSquare(Canvas c, Btn b, float alpha) {
        boolean pr = b == pressed;
        float k = pr ? 0.94f : 1f;
        float w = b.w * k;
        float h = b.h * k;
        pSpr.setAlpha((int) (255f * alpha));
        drawBox(c, bBtnSq, b.x + (b.w - w) / 2f, b.y + (b.h - h) / 2f, w, h);
        pSpr.setAlpha(255);
    }

    void panelRecord(Canvas c, float x, float y) {
        nine(c, bPanelRect, x, y, 400f, 120f, 24, 18f, 215);
        text(c, "RECORDE", x + 200f, y + 38f, 24f, C_YEL, 1, true);
        drawNum(c, sv.hi, x + 200f, y + 80f, 2.4f, 1);
    }

    void drawMenu(Canvas c) {
        float bob = sin(tick * 2f) * 6f;
        text(c, "JOGUINHO", 360f, H * 0.14f + bob, 104f, C_WHITE, 1, true);
        text(c, "DEFESA ESPACIAL", 360f, H * 0.14f + 62f + bob, 36f, C_YEL, 1, true);
        float sy = H * 0.32f + sin(tick * 1.6f) * 10f;
        sprA(c, bLight, 360f, sy, 1.2f, 0f, 0.35f, true);
        drawShipIdx(c, sv.ship, 360f, sy, 2.1f, 1f);
        text(c, Defs.SHIP_NAME[sv.ship], 360f, sy + 110f, 30f, C_WHITE, 1, true);
        spr(c, bStarOn, 44f, ti + 36f, 1f, 0f, pSpr);
        drawNum(c, sv.coins, 70f, ti + 36f, 1.5f, 0);
        drawButtons(c);
        panelRecord(c, 160f, H - 190f);
        text(c, "ARTE E AUDIO CC0 - KENNEY.NL", 360f, H - 22f, 17f, C_FADE, 1, true);
    }

    void drawSelect(Canvas c) {
        text(c, "ESCOLHA A NAVE", 360f, 78f, 46f, C_WHITE, 1, true);
        text(c, "RECORDE " + sv.hi, 360f, 112f, 22f, C_YEL, 1, true);
        String[] statName = {"VIDA", "DANO", "TIRO"};
        String[] statCol = {"Green", "Red", "Yellow"};
        for (int i = 0; i < Defs.NSHIPS; i++) {
            Btn b = btns.get(i);
            boolean open = sv.hi >= Defs.SHIP_UNLOCK[i];
            float x = b.x;
            float y = b.y + (b == pressed ? 3f : 0f);
            nine(c, bPanelGlass, x, y, b.w, b.h, 36, 28f, 255);
            drawShipIdx(c, i, x + 100f, y + 94f, 1.2f, open ? 1f : 0.35f);
            text(c, Defs.SHIP_NAME[i], x + 195f, y + 50f, 34f, DARK, 0, false);
            if (open) {
                float[] v = {Defs.SHIP_HP[i] / 150f, Defs.SHIP_DMG[i] / 1.6f, 0.11f / Defs.SHIP_FIRE[i]};
                for (int r = 0; r < 3; r++) {
                    float by = y + 72f + r * 36f;
                    text(c, statName[r], x + 195f, by + 16f, 17f, DARK, 0, false);
                    bar(c, statCol[r], x + 285f, by, 275f, 20f, v[r]);
                }
            } else {
                text(c, "BLOQUEADA", x + 195f, y + 112f, 30f, C_DKRED, 0, false);
                text(c, "ALCANCE " + Defs.SHIP_UNLOCK[i] + " PONTOS", x + 195f, y + 152f, 20f, DARK, 0, false);
            }
            if (open && i == sv.ship) {
                pill(c, "Yellow", x + b.w - 165f, y + 14f, 140f, 36f, 255);
                text(c, "EM USO", x + b.w - 95f, y + 40f, 19f, DARK, 1, false);
            }
        }
        drawButtons(c);
    }

    void drawShop(Canvas c) {
        text(c, "LOJA", 360f, 96f, 56f, C_WHITE, 1, true);
        text(c, "MOEDAS", 190f, 164f, 26f, C_YEL, 0, true);
        spr(c, bStarOn, 400f, 152f, 1.1f, 0f, pSpr);
        drawNum(c, sv.coins, 430f, 152f, 2f, 0);
        for (int i = 0; i < Defs.NUPS; i++) {
            Btn b = btns.get(i);
            float x = b.x;
            float y = b.y + (b == pressed ? 3f : 0f);
            int lvl = sv.up[i];
            boolean max = lvl >= Defs.UP_MAX[i];
            nine(c, bPanelGlass, x, y, b.w, b.h, 36, 28f, 255);
            text(c, Defs.UP_NAME[i], x + 28f, y + 48f, 32f, DARK, 0, false);
            text(c, Defs.UP_DESC[i], x + 28f, y + 82f, 17f, DARK, 0, false);
            for (int j = 0; j < Defs.UP_MAX[i]; j++) {
                spr(c, j < lvl ? bStarOn : bStarOff, x + 44f + j * 36f, y + 114f, 0.8f, 0f, pSpr);
            }
            int cost = Defs.UP_BASE[i] * (lvl + 1);
            boolean can = !max && sv.coins >= cost;
            pill(c, max ? "Grey" : (can ? "Green" : "Red"), x + b.w - 190f, y + 40f, 165f, 70f, 255);
            text(c, max ? "MAX" : String.valueOf(cost), x + b.w - 107f, y + 87f, 30f, C_WHITE, 1, true);
        }
        drawButtons(c);
    }

    void drawAch(Canvas c) {
        text(c, "CONQUISTAS", 360f, 84f, 50f, C_WHITE, 1, true);
        text(c, Integer.bitCount(sv.ach) + " DE " + Defs.ACH_NAME.length, 360f, 124f, 24f, C_YEL, 1, true);
        for (int i = 0; i < Defs.ACH_NAME.length; i++) {
            float x = 40f;
            float y = 150f + i * 96f;
            boolean ok = (sv.ach & (1 << i)) != 0;
            nine(c, bPanelGlass, x, y, 640f, 90f, 36, 24f, 255);
            spr(c, ok ? bStarOn : bStarOff, x + 48f, y + 45f, 1.5f, 0f, pSpr);
            text(c, Defs.ACH_NAME[i], x + 98f, y + 34f, 26f, DARK, 0, false);
            text(c, Defs.ACH_DESC[i], x + 98f, y + 58f, 17f, DARK, 0, false);
            int cur = Math.min(Defs.ACH_GOAL[i], sv.stat(Defs.ACH_STAT[i]));
            bar(c, ok ? "Green" : "Blue", x + 98f, y + 66f, 300f, 14f, cur / (float) Defs.ACH_GOAL[i]);
            if (ok) {
                text(c, "COMPLETA", x + 620f, y + 38f, 22f, C_DKGRN, 2, false);
            } else {
                text(c, "+" + Defs.ACH_REWARD[i], x + 620f, y + 38f, 24f, C_GOLD, 2, false);
                text(c, cur + "/" + Defs.ACH_GOAL[i], x + 620f, y + 74f, 18f, DARK, 2, false);
            }
        }
        drawButtons(c);
    }

    void drawPlayer(Canvas c) {
        float alpha = (invulT <= 0f || ((int) (tick * 14f)) % 2 != 0) ? 1f : 0.4f;
        thruster(c, bPlayer, px, py, 1.15f, alpha);
        sprA(c, bPlayer, px, py, 1.15f, roll, alpha, false);
        float fr = hp / maxHp;
        int d = fr < 0.2f ? 2 : (fr < 0.4f ? 1 : (fr < 0.66f ? 0 : -1));
        if (d >= 0) {
            sprA(c, bDmg[d], px, py, 1.15f, roll, alpha, false);
        }
        if (d >= 1 && ((int) (tick * 10f)) % 3 == 0) {
            fx(bSmoke, null, px + (rnd.nextFloat() - 0.5f) * 30f, py + 10f, 0.7f, 0.05f, 0.16f, 0.45f, false).vy = 90f;
        }
        if (shieldT > 0f) {
            boolean blink = shieldT < 2f && ((int) (tick * 12f)) % 2 == 0;
            if (!blink) {
                sprA(c, bShield, px, py, sin(tick * 8f) * 0.05f + 1.05f, tick * 40f, 0.9f, true);
            }
        }
        if (hitFlash > 0f) {
            sprA(c, bPlayer, px, py, 1.15f, roll, hitFlash * 2f, true);
        }
    }

    void drawFx(Canvas c, Fx f) {
        if (f.t < 0f) {
            return;
        }
        float p = Math.min(1f, f.t / f.life);
        float s = f.s0 + (f.s1 - f.s0) * p;
        Bitmap b;
        float a;
        if (f.frames != null) {
            b = f.frames[Math.min(f.frames.length - 1, (int) (f.frames.length * p))];
            a = f.a0 * (p > 0.8f ? (1f - p) / 0.2f : 1f);
        } else {
            b = f.bmp;
            a = f.a0 * (1f - p);
        }
        sprA(c, b, f.x, f.y, s, f.rot, a, f.add);
    }

    void drawWorld(Canvas c) {
        c.save();
        if (shakeT > 0f) {
            float a = shakeAmp * Math.min(1f, shakeT / 0.4f);
            c.translate((rnd.nextFloat() - 0.5f) * a * 2f, (rnd.nextFloat() - 0.5f) * a * 2f);
        }
        for (int i = 0; i < rocks.size(); i++) {
            Rock r = rocks.get(i);
            spr(c, r.bmp, r.x, r.y, 1f, r.rot, pSpr);
            if (r.flash > 0f) {
                sprA(c, r.bmp, r.x, r.y, 1f, r.rot, 0.7f, true);
            }
        }
        for (int i = 0; i < pickups.size(); i++) {
            Pickup p = pickups.get(i);
            sprA(c, bLight, p.x, p.y, 0.22f, 0f, 0.55f, true);
            spr(c, A.get(pickupPath[p.kind]), p.x, p.y, pickupScale[p.kind] * (sin(p.t * 6f) * 0.08f + 1f), 0f, pSpr);
        }
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            spr(c, e.bmp, e.x, e.y, e.sc, e.rot, pSpr);
            if (e.flash > 0f) {
                sprA(c, e.bmp, e.x, e.y, e.sc, e.rot, 0.7f, true);
            }
        }
        for (int i = 0; i < bullets.size(); i++) {
            Bullet b = bullets.get(i);
            if (b.homing) {
                sprA(c, bLight, b.x, b.y, 0.18f, 0f, 0.7f, true);
                spr(c, b.bmp, b.x, b.y, 1.4f, b.rot, pSpr);
            } else if (b.mine) {
                sprA(c, bLight, b.x, b.y, 0.11f, 0f, 0.45f, true);
                spr(c, b.bmp, b.x, b.y, 1.15f, b.rot, pSpr);
            } else {
                sprA(c, bLight, b.x, b.y, 0.14f, 0f, 0.6f, true);
                spr(c, b.bmp, b.x, b.y, 1.4f, b.rot, pSpr);
            }
        }
        if (alive) {
            drawPlayer(c);
        }
        for (int i = 0; i < fxs.size(); i++) {
            drawFx(c, fxs.get(i));
        }
        for (int i = 0; i < pops.size(); i++) {
            Pop p = pops.get(i);
            int a = (int) (clamp(1.2f - p.t, 0f, 1f) * 255f);
            text(c, p.s, p.x, p.y, PR, (a << 24) | (p.color & 0xFFFFFF), 1, true);
        }
        c.restore();
        if (flashT > 0f) {
            sprA(c, bLight, 360f, H / 2f, 6f, 0f, flashT * 2f, true);
        }
    }

    void drawHud(Canvas c) {
        float t = ti;
        nine(c, bPanelRect, 14f, t + 12f, 304f, 140f, 24, 18f, 215);
        spr(c, bLife, 50f, t + 44f, 1.4f, 0f, pSpr);
        spr(c, bNumX, 90f, t + 46f, 1.3f, 0f, pSpr);
        drawNum(c, Math.max(0, lives), 104f, t + 45f, 1.7f, 0);
        for (int i = 0; i < 5; i++) {
            spr(c, i < weapon ? bStarOn : bStarOff, 178f + i * 28f, t + 45f, 0.95f, 0f, pSpr);
        }
        float fr = hp / maxHp;
        bar(c, fr > 0.6f ? "Green" : (fr > 0.3f ? "Yellow" : "Red"), 28f, t + 68f, 276f, 28f, fr);
        text(c, "VIDA", 42f, t + 89f, 18f, C_WHITE, 0, true);
        bar(c, "Blue", 28f, t + 106f, 276f, 24f, shieldT / 8f);
        text(c, "ESCUDO", 42f, t + 125f, 16f, C_WHITE, 0, true);
        nine(c, bPanelRect, 406f, t + 12f, 300f, 140f, 24, 18f, 215);
        text(c, "PONTOS", 424f, t + 40f, 19f, C_YEL, 0, true);
        drawNum(c, score, 688f, t + 76f, 2f, 2);
        text(c, "ONDA " + Math.max(1, wave), 424f, t + 130f, 24f, C_WHITE, 0, true);
        if (combo >= 2) {
            pill(c, "Yellow", 556f, t + 104f, 134f, 34f, 255);
            text(c, "COMBO " + combo, 623f, t + 128f, 17f, DARK, 1, false);
        }
        for (int i = 0; i < btns.size(); i++) {
            Btn b = btns.get(i);
            if (b.id == B_PAUSE) {
                drawBtnSquare(c, b, 1f);
                text(c, "II", b.x + b.w / 2f, b.y + b.h / 2f + 13f, 34f, DARK, 1, false);
            } else if (b.id == B_BOMB) {
                float al = bombs > 0 ? 1f : 0.5f;
                drawBtnSquare(c, b, al);
                sprA(c, A.get("powerups/powerupRed_star.png"), b.x + b.w / 2f, b.y + 50f, 1.9f, 0f, al, false);
                spr(c, bNumX, b.x + b.w / 2f - 20f, b.y + 100f, 1.2f, 0f, pSpr);
                drawNum(c, bombs, b.x + b.w / 2f - 6f, b.y + 100f, 1.5f, 0);
            }
        }
        float sx = 18f;
        float sy = t + 160f;
        if (missileT > 0f) {
            pill(c, "Green", sx, sy, 150f, 30f, 255);
            text(c, "MISSEIS " + (int) Math.ceil(missileT), sx + 75f, sy + 22f, 16f, DARK, 1, false);
            sx += 160f;
        }
        if (doubleT > 0f) {
            pill(c, "Yellow", sx, sy, 160f, 30f, 255);
            text(c, "PONTOS X2 " + (int) Math.ceil(doubleT), sx + 80f, sy + 22f, 16f, DARK, 1, false);
        }
        spr(c, bStarOn, 676f, sy + 15f, 0.7f, 0f, pSpr);
        text(c, "+" + runCoins, 654f, sy + 22f, 20f, C_YEL, 2, true);
        if (bossAlive && boss != null) {
            text(c, "CHEFE", 360f, t + 212f, 22f, C_ORG, 1, true);
            bar(c, "Red", 100f, t + 222f, 520f, 28f, boss.hp / boss.maxHp);
        }
        if (toastT > 0f && state == PLAY) {
            int a = (int) (clamp(toastT, 0f, 1f) * 255f);
            pill(c, "Yellow", 90f, t + 268f, 540f, 56f, a);
            text(c, toastS, 360f, t + 304f, 24f, (a << 24) | (DARK & 0xFFFFFF), 1, false);
        }
        if (bannerT > 0f && state == PLAY) {
            float el = bannerMax - bannerT;
            float pop = Math.max(0f, 1f - el / 0.3f) * 0.3f + 1f;
            int col = (((int) (clamp(Math.min(bannerT / 0.5f, el / 0.15f), 0f, 1f) * 255f)) << 24) | (bannerBoss ? 0xFF5252 : 0xFFFFFF);
            text(c, bannerText, 360f, H * 0.36f, pop * (bannerText.length() > 12 ? 52f : 74f), col, 1, true);
        }
        if (hintT > 0f && state == PLAY) {
            int a = (int) (clamp(hintT, 0f, 1f) * 255f);
            text(c, "ARRASTE PARA MOVER", 360f, H * 0.62f, 36f, (a << 24) | 0xFFFFFF, 1, true);
            text(c, "O TIRO E AUTOMATICO", 360f, H * 0.62f + 46f, PR, (a << 24) | 0xFFE14F, 1, true);
        }
        if (resumeT > 0f && state == PLAY) {
            text(c, "PREPARE-SE", 360f, H * 0.36f, 52f, C_WHITE, 1, true);
            text(c, String.valueOf((int) Math.ceil(resumeT)), 360f, H * 0.5f, 150f, C_YEL, 1, true);
        }
    }

    void drawPause(Canvas c) {
        dim(c, 175);
        float py0 = H / 2f - 360f;
        nine(c, bPanelGlass, 90f, py0, 540f, 720f, 36, 28f, 255);
        pill(c, "Yellow", 170f, py0 + 34f, 380f, 90f, 255);
        text(c, "PAUSA", 360f, py0 + 96f, 46f, C_WHITE, 1, true);
        drawButtons(c);
    }

    void drawOver(Canvas c) {
        dim(c, 190);
        float py0 = H / 2f - 470f;
        nine(c, bPanelGlass, 70f, py0, 580f, 920f, 36, 28f, 255);
        pill(c, "Red", 130f, py0 + 34f, 460f, 94f, 255);
        text(c, "FIM DE JOGO", 360f, py0 + 98f, 44f, C_WHITE, 1, true);
        text(c, "PONTOS", 360f, py0 + 190f, 28f, DARK, 1, false);
        drawNum(c, score, 360f, py0 + 250f, 3.4f, 1);
        text(c, "RECORDE", 360f, py0 + 336f, 24f, DARK, 1, false);
        drawNum(c, sv.hi, 360f, py0 + 388f, 2.2f, 1);
        if (newRecord) {
            float k = sin(tick * 8f) * 0.06f + 1f;
            text(c, "NOVO RECORDE!", 360f, py0 + 456f, k * 38f, C_GOLD, 1, false);
        }
        text(c, "ONDA ALCANCADA: " + Math.max(1, wave), 360f, py0 + 510f, 26f, DARK, 1, false);
        text(c, "INIMIGOS: " + runKills + "   MOEDAS: +" + runCoins, 360f, py0 + 552f, 24f, DARK, 1, false);
        if (!unlockMsg.isEmpty()) {
            text(c, unlockMsg, 360f, py0 + 598f, 24f, C_DKGRN, 1, false);
        }
        if (achNew > 0) {
            text(c, "CONQUISTAS NOVAS: " + achNew, 360f, py0 + 640f, 24f, C_GOLD, 1, false);
        }
        drawButtons(c);
    }
}
