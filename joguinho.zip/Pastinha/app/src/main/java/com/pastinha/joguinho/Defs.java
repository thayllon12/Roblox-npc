package com.pastinha.joguinho;

final class Defs {
    static final int NSHIPS = 5;
    static final String[] SHIP_NAME = {"FALCAO", "TITA", "RAIO", "FENIX", "OMEGA"};
    static final int[] SHIP_MODEL = {1, 2, 3, 1, 2};
    static final String[] SHIP_COLOR = {"blue", "green", "orange", "red", "red"};
    static final String[] SHIP_LASER = {"laserBlue01", "laserGreen01", "laserBlue02", "laserRed01", "laserRed02"};
    static final float[] SHIP_HP = {100f, 150f, 70f, 90f, 130f};
    static final float[] SHIP_FIRE = {0.17f, 0.25f, 0.11f, 0.14f, 0.15f};
    static final float[] SHIP_DMG = {1.0f, 1.6f, 0.75f, 1.2f, 1.4f};
    static final float[] SHIP_SPD = {1.0f, 0.8f, 1.25f, 1.15f, 1.0f};
    static final int[] SHIP_UNLOCK = {0, 3000, 8000, 15000, 30000};

    static final int NUPS = 5;
    static final String[] UP_NAME = {"DANO", "BLINDAGEM", "CADENCIA", "IMA", "BOMBAS"};
    static final String[] UP_DESC = {"+10% DE DANO POR NIVEL", "+12% DE VIDA POR NIVEL", "TIRO 6% MAIS RAPIDO POR NIVEL", "ATRAI ITENS DE MAIS LONGE", "+1 BOMBA NO INICIO DA PARTIDA"};
    static final int[] UP_MAX = {5, 5, 5, 3, 3};
    static final int[] UP_BASE = {200, 200, 250, 150, 400};

    static final String[] DIFF_NAME = {"FACIL", "NORMAL", "DIFICIL"};
    static final String[] DIFF_COLOR = {"Green", "Blue", "Red"};
    static final float[] DIFF_HP = {0.75f, 1f, 1.4f};
    static final float[] DIFF_DMG = {0.7f, 1f, 1.4f};
    static final float[] DIFF_CNT = {0.85f, 1f, 1.2f};
    static final float[] DIFF_SCORE = {0.7f, 1f, 1.5f};
    static final float[] DIFF_COIN = {1f, 1f, 1.5f};

    static final String[] ACH_NAME = {"PRIMEIRO VOO", "CACADOR", "EXTERMINADOR", "SOBREVIVENTE", "VETERANO", "DERRUBA CHEFE", "CACA CHEFES", "MESTRE DO COMBO", "COLECIONADOR", "LENDA"};
    static final String[] ACH_DESC = {"JOGUE UMA PARTIDA", "DESTRUA 100 INIMIGOS", "DESTRUA 1000 INIMIGOS", "CHEGUE A ONDA 10", "CHEGUE A ONDA 20", "DERROTE 1 CHEFE", "DERROTE 10 CHEFES", "FACA UM COMBO DE 25", "JUNTE 2000 MOEDAS", "FACA 50000 PONTOS"};
    static final int[] ACH_STAT = {0, 1, 1, 2, 2, 3, 3, 4, 5, 6};
    static final int[] ACH_GOAL = {1, 100, 1000, 10, 20, 1, 10, 25, 2000, 50000};
    static final int[] ACH_REWARD = {50, 100, 400, 200, 500, 150, 600, 250, 300, 500};
}
