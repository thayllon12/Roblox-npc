package com.pastinha.joguinho;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.SurfaceView;
import java.util.HashMap;

abstract class GfxView extends SurfaceView {
    static final float W = 720f;
    static final int DARK = 0xFF22304A;
    static final int C_WHITE = 0xFFFFFFFF;
    static final int C_YEL = 0xFFFFD84F;
    static final int C_GRN = 0xFF8CFF9E;
    static final int C_BLU = 0xFF6FDFFF;
    static final int C_LIME = 0xFF9CFF6B;
    static final int C_PINK = 0xFFFF7A7A;
    static final int C_ORG = 0xFFFF8A80;
    static final int C_GOLD = 0xFFE67E00;
    static final int C_DKGRN = 0xFF2E9E4F;
    static final int C_DKRED = 0xFFD32F2F;
    static final int C_FADE = 0xB0FFFFFF;

    final Assets A;
    final Paint pSpr = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    final Paint pAdd = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Rect s9 = new Rect();
    final RectF d9 = new RectF();
    final Bitmap[] numerals = new Bitmap[10];
    final HashMap<String, Bitmap[]> pills = new HashMap<>();
    Bitmap bNumX;
    Bitmap bBlack;
    Bitmap bLight;
    Bitmap[] fireFrames;
    float H = 1280f;
    float tick;

    GfxView(Context ctx) {
        super(ctx);
        A = new Assets(ctx);
        pAdd.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        pText.setTypeface(A.font);
        pText.setStrokeJoin(Paint.Join.ROUND);
    }

    void loadGfx() {
        bNumX = A.get("ui/numeralX.png");
        bBlack = A.get("bg/black.png");
        bLight = A.get("fx/light_01.png");
        for (int i = 0; i < 10; i++) {
            numerals[i] = A.get("ui/numeral" + i + ".png");
        }
        fireFrames = A.seq("fx/fire%02d.png", 2, 4);
    }

    static float sin(float a) {
        return (float) Math.sin(a);
    }

    static float cos(float a) {
        return (float) Math.cos(a);
    }

    static float clamp(float v, float a, float b) {
        return v < a ? a : (v > b ? b : v);
    }

    static boolean hit(float ax, float ay, float ar, float bx, float by, float br) {
        float dx = ax - bx;
        float dy = ay - by;
        float r = ar + br;
        return dx * dx + dy * dy < r * r;
    }

    void spr(Canvas c, Bitmap b, float x, float y, float s, float rot, Paint p) {
        c.save();
        c.translate(x, y);
        if (rot != 0f) {
            c.rotate(rot);
        }
        c.scale(s, s);
        c.drawBitmap(b, -b.getWidth() / 2f, -b.getHeight() / 2f, p);
        c.restore();
    }

    void sprA(Canvas c, Bitmap b, float x, float y, float s, float rot, float alpha, boolean add) {
        Paint p = add ? pAdd : pSpr;
        p.setAlpha((int) (clamp(alpha, 0f, 1f) * 255f));
        spr(c, b, x, y, s, rot, p);
        p.setAlpha(255);
    }

    void nine(Canvas c, Bitmap b, float x, float y, float w, float h, int cs, float cd, int alpha) {
        int bw = b.getWidth();
        int bh = b.getHeight();
        int[] sx = {0, cs, bw - cs, bw};
        int[] sy = {0, cs, bh - cs, bh};
        float[] dx = {x, x + cd, x + w - cd, x + w};
        float[] dy = {y, y + cd, y + h - cd, y + h};
        pSpr.setAlpha(alpha);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                s9.set(sx[i], sy[j], sx[i + 1], sy[j + 1]);
                d9.set(dx[i], dy[j], dx[i + 1], dy[j + 1]);
                c.drawBitmap(b, s9, d9, pSpr);
            }
        }
        pSpr.setAlpha(255);
    }

    void pill(Canvas c, String col, float x, float y, float w, float h, int alpha) {
        Bitmap[] pl = pills.get(col);
        if (pl == null) {
            pl = new Bitmap[]{A.get("ui/" + col + "_bar_round_large_l.png"), A.get("ui/" + col + "_bar_round_large_m.png"), A.get("ui/" + col + "_bar_round_large_r.png")};
            pills.put(col, pl);
        }
        float cap = 0.5f * h;
        pSpr.setAlpha(alpha);
        d9.set(x, y, x + cap, y + h);
        c.drawBitmap(pl[0], null, d9, pSpr);
        d9.set(x + cap - 0.6f, y, x + w - cap + 0.6f, y + h);
        c.drawBitmap(pl[1], null, d9, pSpr);
        d9.set(x + w - cap, y, x + w, y + h);
        c.drawBitmap(pl[2], null, d9, pSpr);
        pSpr.setAlpha(255);
    }

    void bar(Canvas c, String col, float x, float y, float w, float h, float frac) {
        pill(c, "Grey", x, y, w, h, 255);
        float f = clamp(frac, 0f, 1f);
        if (f <= 0.01f) {
            return;
        }
        pill(c, col, x, y, Math.max(h, w * f), h, 255);
    }

    void text(Canvas c, String s, float x, float y, float size, int fill, int align, boolean outline) {
        pText.setTextSize(size);
        pText.setTextAlign(align == 0 ? Paint.Align.LEFT : (align == 1 ? Paint.Align.CENTER : Paint.Align.RIGHT));
        if (outline) {
            pText.setStyle(Paint.Style.STROKE);
            pText.setStrokeWidth(Math.max(2f, 0.16f * size));
            pText.setColor(((fill >>> 24) << 24) | 0x0A0A1E);
            c.drawText(s, x, y, pText);
        }
        pText.setStyle(Paint.Style.FILL);
        pText.setColor(fill);
        c.drawText(s, x, y, pText);
    }

    void drawNum(Canvas c, long n, float x, float y, float s, int align) {
        String str = Long.toString(n);
        float gw = 20.5f * s;
        float total = str.length() * gw;
        float sx = align == 0 ? x : (align == 1 ? x - total / 2f : x - total);
        for (int i = 0; i < str.length(); i++) {
            Bitmap b = numerals[str.charAt(i) - '0'];
            float bw = b.getWidth() * s;
            float bh = b.getHeight() * s;
            d9.set(i * gw + sx, y - bh / 2f, i * gw + sx + bw, y + bh / 2f);
            c.drawBitmap(b, null, d9, pSpr);
        }
    }

    void drawBox(Canvas c, Bitmap b, float x, float y, float w, float h) {
        d9.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, d9, pSpr);
    }

    void dim(Canvas c, int alpha) {
        pSpr.setAlpha(alpha);
        d9.set(0f, 0f, W, H);
        c.drawBitmap(bBlack, null, d9, pSpr);
        pSpr.setAlpha(255);
    }

    void thruster(Canvas c, Bitmap ship, float x, float y, float s, float alpha) {
        Bitmap f = fireFrames[((int) (tick * 16f)) % fireFrames.length];
        float sy = (sin(tick * 45f) * 0.3f + 1.1f) * s;
        float off = ship.getWidth() * 0.2f * s;
        float ey = ship.getHeight() * 0.5f * s + y - 10f * s;
        pAdd.setAlpha((int) (clamp(alpha, 0f, 1f) * 255f));
        for (int k = -1; k <= 1; k += 2) {
            c.save();
            c.translate(k * off + x, ey);
            c.scale(s * 1.1f, -sy);
            c.drawBitmap(f, -f.getWidth() / 2f, -f.getHeight(), pAdd);
            c.restore();
        }
        pAdd.setAlpha(255);
    }
}
