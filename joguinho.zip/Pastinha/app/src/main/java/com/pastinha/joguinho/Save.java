package com.pastinha.joguinho;

import android.content.Context;
import android.content.SharedPreferences;

final class Save {
    private final SharedPreferences p;
    int hi;
    int coins;
    int ship;
    int diff;
    int kills;
    int bosses;
    int games;
    int bestWave;
    int bestCombo;
    int totalCoins;
    int ach;
    boolean sound;
    boolean vib;
    final int[] up = new int[Defs.NUPS];

    Save(Context c) {
        p = c.getSharedPreferences("joguinho", 0);
        hi = p.getInt("hi", 0);
        coins = p.getInt("coins", 0);
        ship = p.getInt("ship", 0);
        diff = p.getInt("diff", 1);
        kills = p.getInt("kills", 0);
        bosses = p.getInt("bosses", 0);
        games = p.getInt("games", 0);
        bestWave = p.getInt("bestWave", 0);
        bestCombo = p.getInt("bestCombo", 0);
        totalCoins = p.getInt("totalCoins", 0);
        ach = p.getInt("ach", 0);
        sound = p.getBoolean("sound", true);
        vib = p.getBoolean("vib", true);
        for (int i = 0; i < up.length; i++) {
            up[i] = p.getInt("up" + i, 0);
        }
        if (diff < 0 || diff > 2) {
            diff = 1;
        }
    }

    void flush() {
        SharedPreferences.Editor e = p.edit();
        e.putInt("hi", hi);
        e.putInt("coins", coins);
        e.putInt("ship", ship);
        e.putInt("diff", diff);
        e.putInt("kills", kills);
        e.putInt("bosses", bosses);
        e.putInt("games", games);
        e.putInt("bestWave", bestWave);
        e.putInt("bestCombo", bestCombo);
        e.putInt("totalCoins", totalCoins);
        e.putInt("ach", ach);
        e.putBoolean("sound", sound);
        e.putBoolean("vib", vib);
        for (int i = 0; i < up.length; i++) {
            e.putInt("up" + i, up[i]);
        }
        e.apply();
    }

    int stat(int s) {
        switch (s) {
            case 0:
                return games;
            case 1:
                return kills;
            case 2:
                return bestWave;
            case 3:
                return bosses;
            case 4:
                return bestCombo;
            case 5:
                return totalCoins;
            default:
                return hi;
        }
    }
}
