# DEV AI ASSISTANT

Assistente Android de voz com inferência local Qwen/llama.cpp, reconhecimento offline Vosk PT-BR, síntese de voz Android, ativação por frase e integração opcional com Gemini Live.

**Versão do aplicativo:** 1.2.0  
**Android:** API 26+  
**ABI nativa configurada:** `arm64-v8a`  
**Java/Kotlin:** JDK 17 / Kotlin 2.0.21

## O que o projeto prepara automaticamente

### Durante a compilação

O workflow `.github/workflows/android-build.yml` instala as ferramentas e baixa as dependências necessárias para compilar:

- JDK 17;
- Android SDK Platform 35 e Build Tools 35.0.0;
- Android NDK 26.1.10909125;
- CMake 3.22.1;
- Gradle 8.9;
- código `llama.cpp` na revisão `b4510`, incluindo submódulos Git;
- dependências Android/Maven definidas no Gradle: AndroidX, Jetpack Compose, Navigation, DataStore, Security Crypto, OkHttp, Coroutines, Vosk, JNA e ONNX Runtime.

O Gradle baixa os artefatos Maven durante a etapa de resolução de dependências e a compilação. O APK Debug é publicado como Artifact.

### Na primeira execução do aplicativo

- **Qwen3 0.6B Q8_0:** baixa automaticamente do repositório Hugging Face para o armazenamento privado do aplicativo, verifica o cabeçalho GGUF e instala o arquivo sem usar a pasta pública Downloads.
- **Vosk PT-BR small 0.3:** baixa o ZIP oficial, extrai em diretório privado temporário, valida os arquivos essenciais e instala o modelo.
- Modelos válidos já presentes não são baixados novamente.

O Qwen Q8_0 tem aproximadamente 805 MB. O tamanho real é lido do servidor; é necessária conexão com a internet e espaço livre suficiente. Os modelos não são embutidos no APK para evitar um pacote de instalação de centenas de megabytes.

## Como compilar

### GitHub Actions (recomendado)

1. Extraia o conteúdo deste ZIP na raiz de um repositório GitHub (a pasta `.github/workflows` precisa ficar na raiz do repositório).
2. Faça push para `main`/`master`, ou abra **Actions → DEV AI ASSISTANT - Android APK → Run workflow**.
3. Aguarde as etapas de instalação do SDK/NDK/CMake, download do llama.cpp, resolução Maven e compilação.
4. Baixe o Artifact `DEV-AI-ASSISTANT-debug-*` quando o workflow terminar com sucesso.

O workflow também aceita um arquivo `Dev.zip` na raiz e procura nele o `settings.gradle.kts`.

### Linux/macOS local

Pré-requisitos: JDK 17 e Android SDK Command-line Tools instalados. Configure `ANDROID_HOME` (ou `ANDROID_SDK_ROOT`) e aceite as licenças. Depois execute:

```bash
./scripts/build-android.sh
```

O script instala os pacotes Android requeridos com `sdkmanager`, baixa Gradle 8.9 se não estiver no PATH, baixa llama.cpp com os submódulos e compila `assembleDebug`.

## Funcionalidades do aplicativo

- Interface Compose escura e orb animada com a identidade DEVEx.
- Importação de arquivos GGUF pelo seletor Android.
- Instalação inicial do Qwen e carregamento via JNI/llama.cpp (quando o build nativo foi concluído).
- Geração local, controle de contexto, cancelamento e liberação do modelo.
- Reconhecimento Vosk PT-BR e transcrição.
- Ativação por voz através de frases reconhecidas pelo Vosk: “Hey Dev”, “Ei Dev”, “Ok Dev” e “Okay Dev”.
- TTS nativo Android.
- Serviço de primeiro plano com notificação persistente para escuta em segundo plano, sujeito às permissões e restrições do Android.
- Cliente Gemini Live por WebSocket, com chave guardada via Android Keystore e teste de handshake na tela de configurações.
- Configurações persistentes com DataStore.

## Limitações que devem permanecer explícitas

- O build depende de acesso à internet para baixar Gradle, dependências Maven e o código-fonte llama.cpp. Não há como embutir o SDK/NDK Android inteiro neste ZIP.
- O modelo Qwen e o Vosk são baixados pelo aplicativo no primeiro uso. A instalação do Qwen só é iniciada se o backend nativo tiver sido carregado com sucesso.
- A ativação “Hey Dev/Ok Dev” usa reconhecimento contínuo/rearmado do Vosk e depende da qualidade da transcrição; não é um classificador acústico dedicado treinado especificamente para “Hey Dev”.
- O classificador ONNX de wake word personalizado não é fornecido nem treinado neste projeto. ONNX Runtime permanece disponível para importação opcional.
- Gemini Live exige uma API key válida e um ID de modelo Live atualmente habilitado para essa chave/conta. O teste verifica o handshake da sessão; não comprova a qualidade de uma conversa de áudio completa.
- O serviço de microfone em segundo plano depende de permissão explícita, notificação e das regras de execução em segundo plano da versão Android/fabricante.
- A configuração nativa está limitada a `arm64-v8a`; outros ABIs não são gerados nesta versão.
- Não há APK Debug incluído nesta entrega porque o ambiente de edição não tem Android SDK/NDK, Gradle ou acesso de rede para baixar as dependências e compilar o código nativo.

## Arquivos importantes

- `.github/workflows/android-build.yml` — pipeline de instalação e build no GitHub Actions.
- `scripts/prepare-llama.sh` — baixa llama.cpp e submódulos.
- `scripts/build-android.sh` — preparação e build local Linux/macOS.
- `docs/DEPENDENCY_SETUP.md` — detalhes dos downloads e dependências.
- `app/src/main/cpp/CMakeLists.txt` — build nativo; falha explicitamente se llama.cpp estiver ausente (sem STUB).

## Segurança e privacidade

A chave Gemini não deve ser gravada no código-fonte; o app a armazena com `EncryptedSharedPreferences` apoiado pelo Android Keystore. Modelos e arquivos temporários são mantidos no espaço privado do app. O microfone só deve ser usado após a permissão Android e, em segundo plano, com o serviço de primeiro plano visível.

## Gemini (chat e respostas por voz)

A seleção Gemini usa o endpoint `generateContent` para mensagens de texto, separado do WebSocket da Gemini Live API. O padrão é `gemini-2.5-flash`. Configure a API Key em **Configurações → Gemini online**, salve e use **Testar**. A chave fica armazenada nas preferências criptografadas do Android; não a coloque no código nem no repositório.

Se a API Gemini falhar, o fallback para Qwen pode ser ligado/desligado em Configurações. Para respostas faladas, mantenha **Resposta falada (TTS)** ativada.

## Palavra de ativação e segundo plano

A palavra de ativação vem desativada por padrão. Ative **Hey Dev / Ok Dev** explicitamente e, para continuar ouvindo fora da tela principal, ative também **Serviço em segundo plano**. O Android mantém uma notificação enquanto o serviço de microfone está ativo. O sistema pode limitar/restringir serviços de microfone em alguns estados do dispositivo; o app não promete escuta permanente após encerramento forçado, reinicialização ou restrições de bateria.

Quando a palavra de ativação for reconhecida no serviço em segundo plano, o cartão flutuante do DEV pode ser expandido automaticamente se **Orb flutuante** estiver ativado e a permissão de sobreposição tiver sido concedida. A abertura automática de uma Activity por cima de outros apps não é forçada; o cartão oferece a ação **Abrir conversa**.
