# Fases E–G — Resumo do que foi adicionado

## E — Gemini Live
- `gemini/GeminiLiveClient.kt`: cliente WebSocket completo (setup, texto, PCM 16 kHz in / 24 kHz out, reconexão, erros).
- Modelo padrão: `gemini-3.8-live`.
- API Key fornecida pelo usuário e armazenada de forma criptografada.

## F — Overlay + Foreground Service
- `service/AssistantForegroundService.kt`: serviço com tipo `microphone`, notificação persistente, start/stop.
- `overlay/OverlayService.kt` + `OverlayLifecycleOwner.kt`: orb flutuante arrastável (Compose em Service).

## G — Settings + Segurança
- `storage/SettingsRepository.kt`: DataStore (preferências) + EncryptedSharedPreferences (API Key via Android Keystore).
- `ui/screens/SettingsScreen.kt`: tela completa de configurações (provedor, fallback, TTS, wake, Gemini, overlay, serviço).
- MainActivity atualizado com navegação e solicitação de permissões em tempo de execução.

## Build
- `.github/workflows/build.yml` para gerar APK debug no GitHub Actions.

## Próximos passos recomendados pelo usuário
1. Adicionar submodule llama.cpp e validar inferência real no dispositivo.
2. Baixar/importar modelo Vosk PT-BR.
3. Treinar classificador openWakeWord para “Hey Dev AI”.
4. Testar sessão Gemini Live com chave real (áudio bidirecional).
5. Calibrar threshold do wake word no POCO X7 Pro.
6. (Opcional) Assinar APK release com keystore local (nunca no repositório).
