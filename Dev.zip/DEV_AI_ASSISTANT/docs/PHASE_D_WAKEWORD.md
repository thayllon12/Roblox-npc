# Fase D — Wake word “Hey Dev AI”

## Status honesto

**Não existe neste pacote um modelo ONNX treinado e validado para a frase “Hey Dev AI”.**

O openWakeWord e os ports Android fornecem a infraestrutura. A frase personalizada exige:

1. Coleta ou síntese de exemplos positivos (“Hey Dev AI” falado de várias formas)
2. Exemplos negativos (outras falas, ruído, frases parecidas)
3. Treinamento do classificador
4. Exportação para ONNX
5. Importação no app

Até o modelo personalizado ser treinado e importado:

- O detector permanece em estado `DISABLED`
- O app continua 100% utilizável pelo botão **Escutar** (Fase C)
- Não há simulação de detecção de outra palavra como se fosse “Hey Dev AI”

## O que foi implementado

| Item | Status |
|------|--------|
| Dependência ONNX Runtime Android | ✅ |
| `WakeWordDetector` (carga ONNX, captura PCM, score, threshold, cooldown) | ✅ |
| Importação de classificador `.onnx` via SAF | ✅ |
| Integração com fluxo de voz (ao detectar → inicia Vosk) | ✅ (hooks) |
| Documentação de treinamento | ✅ |
| Modelo treinado “Hey Dev AI” | ❌ (deve ser treinado pelo desenvolvedor) |

## Como treinar o modelo “Hey Dev AI”

### Opção A — openWakeWord oficial + notebook/scripts

Repositório: https://github.com/dscripka/openWakeWord

1. Clone e configure o ambiente (Python 3.10+, preferencialmente com GPU)
2. Use o exemplo de config:

```yaml
model_name: "hey_dev_ai"
target_phrase:
  - "hey dev ai"
  - "hey dev a i"
custom_negative_phrases:
  - "hey david"
  - "hey there"
  - "dev ai"
  - "hey"
```

3. Gere amostras positivas (TTS Piper / gravações reais) e negativas
4. Treine e exporte `hey_dev_ai.onnx` (+ `.onnx.data` se aplicável)

### Opção B — Pipelines prontos da comunidade

- https://github.com/lgpearson1771/openwakeword-trainer  
- https://github.com/TaterTotterson/openWakeWord-Trainer  
- https://github.com/Dethon/openwakeword-training  

Esses repositórios automatizam geração de clips, augmentação e export ONNX.

### Exemplos positivos recomendados

- 500–2000+ clips de “Hey Dev AI” (várias vozes, sotaques, velocidades, ruído de fundo)
- Incluir variações: “Hey Dev AI”, “Ei Dev AI”, “Hey Dev A.I.”

### Exemplos negativos

- Conversas normais em português
- Frases parecidas (“Hey David”, “Dev AI”, “Hey Google”)
- Música, TV, ruído ambiente

## Como instalar o modelo no app

1. Treine e obtenha `hey_dev_ai.onnx` (e `hey_dev_ai.onnx.data` se existir)
2. No app (ou via código), copie para:

```
/data/data/com.devai.assistant/files/wakeword/hey_dev_ai.onnx
```

3. Ou use o seletor de arquivos da UI (botão de importação de wake word)
4. Ajuste o `threshold` (comece em 0.5 e calibre com testes reais)

## Pipeline completo (melspectrogram + embedding)

O openWakeWord original usa 3 estágios:

1. `melspectrogram.onnx`
2. `embedding_model.onnx` (Google speech embedding)
3. Classificador da frase

A implementação atual carrega o **classificador** e faz um fallback simplificado de features para desenvolvimento. Para produção com baixa taxa de falso positivo:

- Inclua os dois modelos de pré-processamento em `assets/` ou `filesDir/wakeword/`
- Substitua `runInferenceSimplified` pela cadeia completa (mel → embedding → classifier)

Os ports Android de referência (msnilsen/openwakeword-android, Re-MENTIA) já fazem isso e podem ser usados como base.

## Sensibilidade

```kotlin
wakeWordDetector.threshold = 0.45f  // mais sensível
wakeWordDetector.threshold = 0.65f  // menos falsos positivos
wakeWordDetector.cooldownMs = 2500L
```

## Integração no fluxo do assistente

Quando o score ultrapassa o limiar:

1. `WakeWordDetector` chama o callback `onWake`
2. O controller para a escuta do wake word temporariamente
3. Inicia `VoskSpeechRecognizer.startListening`
4. Após a resposta (TTS), volta a escutar o wake word

## Checklist de validação (após treinar o modelo)

- [ ] Frase “Hey Dev AI” dispara de forma consistente
- [ ] Frases semelhantes NÃO disparam (teste “Hey David”, “Dev AI”)
- [ ] Ruído de TV/música não dispara
- [ ] Consumo de CPU/bateria aceitável em 16 kHz contínuo
- [ ] Threshold calibrado no dispositivo alvo (POCO X7 Pro)

## Resumo

A Fase D entrega a **infraestrutura real** de wake word em Android (ONNX, captura, estados, importação, threshold).  
O modelo específico “Hey Dev AI” **precisa ser treinado** — isso não pode ser inventado nem substituído por outro modelo sem violar o requisito do projeto.
