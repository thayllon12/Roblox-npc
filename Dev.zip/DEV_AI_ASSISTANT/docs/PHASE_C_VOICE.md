# Fase C — Voz (Vosk PT-BR + TTS + captura)

## Componentes

| Classe | Função |
|--------|--------|
| `VoskSpeechRecognizer` | Modelo Vosk, escuta, resultados parciais/finais |
| `TtsEngine` | Text-to-Speech nativo (pt-BR prioritário) |
| `VoiceAssistantController` | Orquestra: escuta → LLM → fala |

## Dependências Gradle

```kotlin
implementation("com.alphacephei:vosk-android:0.3.75@aar")
implementation("net.java.dev.jna:jna:5.18.1@aar")
```

Use a notação `@aar` para garantir que as bibliotecas nativas sejam incluídas.

## Modelo Vosk PT-BR

- Nome: `vosk-model-small-pt-0.3`
- Tamanho: ~31 MB
- URL oficial: https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip
- Licença: Apache 2.0

### Como instalar no app

1. Baixe o ZIP no celular ou PC
2. No app, toque em **Vosk ZIP**
3. Selecione o arquivo baixado
4. O app descompacta em `filesDir/vosk-models/vosk-model-small-pt-0.3/`

## Fluxo de uso

1. Importe e carregue um GGUF (Fase B)
2. Importe o modelo Vosk (ZIP)
3. Conceda permissão de microfone
4. Toque em **Escutar** (ou na orb)
5. Fale em português
6. Quando a frase for reconhecida como final:
   - texto → prompt → LLM local
   - resposta → TTS (voz nativa)

## Permissões

`RECORD_AUDIO` é solicitada em tempo de execução na primeira vez que o usuário tenta escutar.

## Observações

- Vosk e openWakeWord são camadas separadas. Esta fase não implementa wake word.
- Resultados parciais aparecem enquanto o usuário fala.
- TTS usa o motor do sistema; a qualidade depende das vozes instaladas no aparelho (preferência pt-BR).
- Em aparelhos sem voz pt-BR instalada, o Android pode cair para outra língua ou exigir download de dados de idioma.

## Limitações conhecidas

1. Não há VAD (voice activity detection) avançado além do que o Vosk fornece — silêncio longo pode gerar timeout.
2. O prompt enviado ao LLM ainda é simples (sem histórico de conversa completo).
3. Streaming de tokens do LLM para a UI/TTS ainda não está implementado.
4. O modelo small de português tem WER mais alto que modelos grandes; para melhor precisão use o modelo full (~1.6 GB) no futuro.

## Próxima fase

**Fase D** — Wake word personalizado “Hey Dev AI” (openWakeWord / ONNX).
