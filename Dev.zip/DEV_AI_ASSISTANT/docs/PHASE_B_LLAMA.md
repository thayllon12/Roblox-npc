# Fase B — Integração llama.cpp + GGUF

## O que foi implementado

| Componente | Arquivo | Status |
|------------|---------|--------|
| CMake + flags Android | `app/src/main/cpp/CMakeLists.txt` | ✅ |
| JNI bridge (C++) | `app/src/main/cpp/llama_jni.cpp` | ✅ |
| Kotlin native interface | `localmodel/LlamaNative.kt` | ✅ |
| Motor de IA local | `localmodel/LocalLlmEngine.kt` | ✅ |
| ModelInfo + validação GGUF | `localmodel/ModelInfo.kt` | ✅ |
| ViewModel | `ui/screens/MainViewModel.kt` | ✅ |
| UI de importação / teste | `ui/screens/MainScreen.kt` | ✅ |
| Gradle NDK/CMake | `app/build.gradle.kts` | ✅ |

### Funcionalidades

- Importação de arquivos `.gguf` via Storage Access Framework
- Validação do magic number `GGUF`
- Cópia para armazenamento interno do app
- Carregamento / descarregamento do modelo
- Inferência em background (Dispatchers.Default)
- Interrupção de geração (`requestStop`)
- Controle de temperatura, top-p e max tokens
- Estados da orb sincronizados com o motor
- Liberação de recursos nativos

## Como adicionar o llama.cpp (obrigatório para inferência real)

O ZIP **não inclui** o código-fonte do llama.cpp (centenas de MB).  
O CMake detecta a ausência e compila em **modo STUB** (a UI funciona e mostra texto de demonstração).

### Opção 1 — Git submodule (recomendado)

Na raiz do projeto:

```bash
git init   # se ainda não for um repositório
git submodule add https://github.com/ggml-org/llama.cpp.git app/src/main/cpp/llama.cpp
git submodule update --init --recursive
```

### Opção 2 — Clone manual

```bash
cd app/src/main/cpp
git clone --depth 1 --recurse-submodules https://github.com/ggml-org/llama.cpp.git
```

Depois:

1. Abra o projeto no Android Studio
2. Faça **Sync Project with Gradle Files**
3. O CMake vai compilar o llama.cpp + a biblioteca `libdevai-llama.so`
4. A primeira compilação pode demorar vários minutos

### Modelo recomendado

- **Qwen3-0.6B-Q8_0.gguf** (~639 MB)  
  Link oficial: https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/blob/main/Qwen3-0.6B-Q8_0.gguf  
  Licença: Apache-2.0

Baixe o arquivo no celular ou no PC e use o botão **Importar GGUF** na tela principal.

## API do motor (resumo)

```kotlin
val engine = LocalLlmEngine(context)

// Inicialização
engine.initialize()

// Importar
val info = engine.importGguf(file, displayName = "Qwen 0.6B")

// Carregar
engine.load(info, contextSize = 2048)

// Gerar (background)
val text = engine.generate("Olá!", temperature = 0.7f, maxTokens = 256)

// Interromper
engine.stopGeneration()

// Descarregar
engine.unload()

// Liberar tudo
engine.release()
```

## Observações de desempenho (POCO X7 Pro / Dimensity 8400-Ultra)

- Use `n_gpu_layers = 0` (CPU) para máxima estabilidade
- Contexto 2048 é um bom equilíbrio
- Q8_0 do 0.6B cabe confortavelmente em 12 GB de RAM
- Em aparelhos com menos memória, prefira quantizações Q4_K_M / Q5_K_M

## Limitações conhecidas desta fase

1. O código JNI usa a API pública do llama.cpp v1.0.x (nov/2026).  
   Se a API mudar em versões futuras, será necessário ajustar `llama_jni.cpp`.
2. Chat template (system/user/assistant) ainda não é aplicado automaticamente.  
   O prompt é enviado “cru”. Melhorias de prompt engineering virão nas fases de voz/Gemini.
3. Não há streaming de tokens para a UI ainda (a resposta completa é retornada de uma vez).
4. Apenas ABI `arm64-v8a` está habilitada no Gradle (adequado para o dispositivo alvo).

## Próxima fase

**Fase C** — Vosk (reconhecimento de voz PT-BR) + TTS nativo + captura de áudio.
