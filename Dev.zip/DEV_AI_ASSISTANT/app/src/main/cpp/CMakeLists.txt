cmake_minimum_required(VERSION 3.22.1)

project("devai-llama" VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# ---------------------------------------------------------------------------
# llama.cpp deve ser adicionado como submodule em:
#   app/src/main/cpp/llama.cpp
#
# Comando (na raiz do projeto):
#   git submodule add https://github.com/ggml-org/llama.cpp.git app/src/main/cpp/llama.cpp
#   git submodule update --init --recursive
#
# Ou clone manualmente:
#   git clone --depth 1 --recurse-submodules https://github.com/ggml-org/llama.cpp.git app/src/main/cpp/llama.cpp
# ---------------------------------------------------------------------------

set(LLAMA_DIR ${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp)

if(NOT EXISTS "${LLAMA_DIR}/CMakeLists.txt")
    message(WARNING "============================================================")
    message(WARNING " llama.cpp NÃO encontrado em app/src/main/cpp/llama.cpp")
    message(WARNING " A biblioteca nativa será compilada em modo STUB.")
    message(WARNING " Siga as instruções no README da Fase B para adicionar o submodule.")
    message(WARNING "============================================================")
    set(USE_LLAMA_STUB ON)
else()
    set(USE_LLAMA_STUB OFF)
endif()

# Flags recomendadas para Android (baseadas na documentação oficial 2026)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)

if(ANDROID_ABI STREQUAL "arm64-v8a")
    # KleidiAI melhora performance em ARM modernos (Dimensity, Snapdragon)
    set(GGML_CPU_KLEIDIAI ON CACHE BOOL "" FORCE)
endif()

if(NOT USE_LLAMA_STUB)
    add_subdirectory(${LLAMA_DIR} build-llama EXCLUDE_FROM_ALL)
endif()

# Nossa biblioteca JNI
add_library(devai-llama SHARED
    llama_jni.cpp
)

target_include_directories(devai-llama PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
)

if(NOT USE_LLAMA_STUB)
    target_include_directories(devai-llama PRIVATE
        ${LLAMA_DIR}
        ${LLAMA_DIR}/include
        ${LLAMA_DIR}/common
        ${LLAMA_DIR}/ggml/include
        ${LLAMA_DIR}/ggml/src
    )
    target_link_libraries(devai-llama
        llama
        android
        log
    )
    target_compile_definitions(devai-llama PRIVATE USE_REAL_LLAMA=1)
else()
    # Stub: permite que o projeto sincronize e compile sem o submodule
    target_link_libraries(devai-llama android log)
    target_compile_definitions(devai-llama PRIVATE USE_REAL_LLAMA=0)
endif()

# Otimizações
target_compile_options(devai-llama PRIVATE
    -O3
    -fvisibility=hidden
    -ffunction-sections
    -fdata-sections
)
