package com.devai.assistant.localmodel

/**
 * Bridge JNI para llama.cpp.
 *
 * A biblioteca nativa `libdevai-llama.so` é carregada sob demanda.
 * Se o submodule llama.cpp não estiver presente, o código C++
 * é compilado em modo STUB (retorna textos de demonstração).
 */
object LlamaNative {

    private var libraryLoaded = false

    @Synchronized
    fun ensureLoaded() {
        if (!libraryLoaded) {
            try {
                System.loadLibrary("devai-llama")
                libraryLoaded = true
            } catch (e: UnsatisfiedLinkError) {
                throw RuntimeException(
                    "Falha ao carregar libdevai-llama.so. " +
                    "Verifique se o NDK está instalado e se o CMake compilou a biblioteca.",
                    e
                )
            }
        }
    }

    /**
     * Inicializa o backend do llama.cpp.
     * @param nativeLibDir caminho para o diretório de .so nativos do app
     *        (context.applicationInfo.nativeLibraryDir)
     */
    external fun initBackend(nativeLibDir: String): Boolean

    /**
     * Carrega um arquivo GGUF.
     * @param modelPath caminho absoluto do arquivo .gguf
     * @param nCtx tamanho do contexto (recomendado 2048–4096 em mobile)
     * @param nGpuLayers camadas na GPU (0 = apenas CPU, mais estável)
     */
    external fun loadModel(modelPath: String, nCtx: Int, nGpuLayers: Int): Boolean

    external fun isModelLoaded(): Boolean

    external fun unloadModel()

    /** Solicita interrupção da geração em andamento. */
    external fun requestStop()

    /**
     * Gera texto a partir do prompt.
     * DEVE ser chamado de uma thread de background.
     * @return texto gerado ou null em caso de erro
     */
    external fun generate(
        prompt: String,
        temperature: Float,
        maxTokens: Int,
        topP: Float
    ): String?

    external fun getModelInfo(): String?

    external fun freeBackend()
}
