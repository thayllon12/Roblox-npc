package com.devai.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.devai.assistant.MainActivity
import com.devai.assistant.R
import com.devai.assistant.localmodel.LocalLlmEngine
import com.devai.assistant.voice.VoiceAssistantController

/**
 * Foreground Service para manter o assistente de voz ativo em segundo plano.
 * Tipo: microphone (Android 14+ exige foregroundServiceType).
 */
class AssistantForegroundService : Service() {

    private var voiceController: VoiceAssistantController? = null
    private var llmEngine: LocalLlmEngine? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        Log.i(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val notification = buildNotification("Aguardando \"Hey Dev AI\"")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                startVoiceLoop()
            }
        }
        return START_STICKY
    }

    private fun startVoiceLoop() {
        if (voiceController != null) return
        llmEngine = LocalLlmEngine(applicationContext)
        voiceController = VoiceAssistantController(applicationContext, llmEngine!!)
        voiceController?.startWakeWordListening()
        Log.i(TAG, "Voice loop started")
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "DEV AI Assistente",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Serviço de escuta contínua do assistente"
            setShowBadge(false)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(status: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DEV AI ASSISTANT")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .addAction(0, "Parar", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    fun updateStatus(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        voiceController?.release()
        voiceController = null
        llmEngine?.release()
        llmEngine = null
        Log.i(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "AssistantFgService"
        private const val CHANNEL_ID = "dev_ai_assistant_channel"
        private const val NOTIFICATION_ID = 4201
        const val ACTION_STOP = "com.devai.assistant.STOP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, AssistantForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, AssistantForegroundService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
