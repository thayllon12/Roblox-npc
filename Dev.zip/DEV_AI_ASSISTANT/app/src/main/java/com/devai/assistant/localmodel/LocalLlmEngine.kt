package com.devai.assistant.localmodel

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Motor de IA local baseado em llama.cpp.
 *
 * Responsabilidades:
 * - Importar arquivos GGUF (via URI ou path)
 * - Carregar / descarregar modelo
 * - Executar inferência em background
 * - Expor estado para a UI
 * - Gerenciar memória e interrupção
 *
 * NÃO mistura UI, rede ou áudio nesta classe.
 */
class LocalLlmEngine(private val context: Context) {

    enum class State {
        UNINITIALIZED,
        READY,          // backend ok, nenhum modelo carregado
        LOADING_MODEL,
        MODEL_LOADED,
        GENERATING,
        ERROR
    }

    data class GenerationParams(
        val temperature: Float = 0.7f,
        val maxTokens: Int = 512,
        val topP: Float = 0.9f,
        val contextSize: Int = 2048
    )

    private val _state = MutableStateFlow(State.UNINITIALIZED)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _currentModel = MutableStateFlow<ModelInfo?>(null)
    val currentModel: StateFlow<ModelInfo?> = _currentModel.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val modelsDir: File by lazy {
        File(context.filesDir, "models").also { it.mkdirs() }
    }

    private var params = GenerationParams()

    // ------------------------------------------------------------------
    // Inicialização
    // ------------------------------------------------------------------

    suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        try {
            LlamaNative.ensureLoaded()
            val libDir = context.applicationInfo.nativeLibraryDir
            val ok = LlamaNative.initBackend(libDir)
            if (ok) {
                _state.value = State.READY
                _lastError.value = null
                Log.i(TAG, "Backend initialized")
            } else {
                _state.value = State.ERROR
                _lastError.value = "Falha ao inicializar backend llama.cpp"
            }
            ok
        } catch (e: Exception) {
            Log.e(TAG, "initialize failed", e)
            _state.value = State.ERROR
            _lastError.value = e.message ?: "Erro desconhecido"
            false
        }
    }

    // ------------------------------------------------------------------
    // Importação de GGUF
    // ------------------------------------------------------------------

    /**
     * Copia um arquivo GGUF para o diretório interno do app.
     * @param sourceFile arquivo já acessível (ex.: obtido via SAF)
     * @param displayName nome amigável (opcional)
     */
    suspend fun importGguf(sourceFile: File, displayName: String? = null): ModelInfo? =
        withContext(Dispatchers.IO) {
            if (!sourceFile.exists() || !sourceFile.canRead()) {
                _lastError.value = "Arquivo inacessível"
                return@withContext null
            }
            if (!sourceFile.name.lowercase().endsWith(".gguf")) {
                _lastError.value = "O arquivo precisa ter extensão .gguf"
                return@withContext null
            }

            // Validação mínima de cabeçalho GGUF (magic "GGUF")
            sourceFile.inputStream().use { input ->
                val magic = ByteArray(4)
                if (input.read(magic) != 4 || String(magic) != "GGUF") {
                    _lastError.value = "Arquivo não é um GGUF válido (magic incorreto)"
                    return@withContext null
                }
            }

            val id = UUID.randomUUID().toString().take(8)
            val safeName = (displayName ?: sourceFile.nameWithoutExtension)
                .replace(Regex("[^a-zA-Z0-9._-]"), "_")
                .take(64)
            val dest = File(modelsDir, "${safeName}_$id.gguf")

            try {
                sourceFile.copyTo(dest, overwrite = true)
            } catch (e: Exception) {
                _lastError.value = "Falha ao copiar modelo: ${e.message}"
                return@withContext null
            }

            val info = ModelInfo(
                id = id,
                displayName = displayName ?: sourceFile.name,
                filePath = dest.absolutePath,
                sizeBytes = dest.length()
            )
            Log.i(TAG, "Imported model: ${info.displayName} (${info.formattedSize()})")
            info
        }

    /**
     * Lista modelos já importados no diretório interno.
     */
    fun listImportedModels(): List<ModelInfo> {
        return modelsDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".gguf", ignoreCase = true) }
            ?.map { file ->
                ModelInfo(
                    id = file.nameWithoutExtension.takeLast(8),
                    displayName = file.nameWithoutExtension.dropLast(9).ifEmpty { file.name },
                    filePath = file.absolutePath,
                    sizeBytes = file.length()
                )
            }
            ?.sortedByDescending { it.importedAt }
            ?: emptyList()
    }

    /**
     * Remove um modelo do armazenamento interno.
     * Se for o modelo carregado, descarrega primeiro.
     */
    suspend fun removeModel(info: ModelInfo): Boolean = withContext(Dispatchers.IO) {
        if (_currentModel.value?.filePath == info.filePath) {
            unload()
        }
        val file = File(info.filePath)
        val deleted = file.exists() && file.delete()
        if (!deleted) {
            _lastError.value = "Não foi possível remover o arquivo"
        }
        deleted
    }

    // ------------------------------------------------------------------
    // Carregamento / descarregamento
    // ------------------------------------------------------------------

    suspend fun load(info: ModelInfo, contextSize: Int = params.contextSize): Boolean =
        withContext(Dispatchers.IO) {
            if (!info.exists) {
                _lastError.value = "Arquivo do modelo não encontrado"
                _state.value = State.ERROR
                return@withContext false
            }

            _state.value = State.LOADING_MODEL
            _lastError.value = null

            // Descarrega modelo anterior se houver
            if (LlamaNative.isModelLoaded()) {
                LlamaNative.unloadModel()
            }

            val ok = LlamaNative.loadModel(
                modelPath = info.filePath,
                nCtx = contextSize.coerceIn(512, 8192),
                nGpuLayers = 0 // CPU only por estabilidade em mobile
            )

            if (ok) {
                _currentModel.value = info
                _state.value = State.MODEL_LOADED
                params = params.copy(contextSize = contextSize)
                Log.i(TAG, "Model loaded: ${info.displayName}")
            } else {
                _currentModel.value = null
                _state.value = State.ERROR
                _lastError.value = "Falha ao carregar o modelo (verifique RAM e formato GGUF)"
            }
            ok
        }

    suspend fun unload() = withContext(Dispatchers.IO) {
        LlamaNative.unloadModel()
        _currentModel.value = null
        if (_state.value != State.UNINITIALIZED && _state.value != State.ERROR) {
            _state.value = State.READY
        }
    }

    // ------------------------------------------------------------------
    // Inferência
    // ------------------------------------------------------------------

    /**
     * Gera resposta. Executa em Dispatchers.Default.
     * Pode ser interrompida com [stopGeneration].
     */
    suspend fun generate(
        prompt: String,
        temperature: Float = params.temperature,
        maxTokens: Int = params.maxTokens,
        topP: Float = params.topP
    ): String? = withContext(Dispatchers.Default) {
        if (!LlamaNative.isModelLoaded()) {
            _lastError.value = "Nenhum modelo carregado"
            return@withContext null
        }

        _state.value = State.GENERATING
        _lastError.value = null

        try {
            val result = LlamaNative.generate(
                prompt = prompt,
                temperature = temperature.coerceIn(0.0f, 2.0f),
                maxTokens = maxTokens.coerceIn(16, 2048),
                topP = topP.coerceIn(0.0f, 1.0f)
            )
            if (result == null) {
                _lastError.value = "Geração falhou"
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "generate error", e)
            _lastError.value = e.message
            null
        } finally {
            _state.value = if (LlamaNative.isModelLoaded()) State.MODEL_LOADED else State.READY
        }
    }

    fun stopGeneration() {
        LlamaNative.requestStop()
    }

    fun updateParams(newParams: GenerationParams) {
        params = newParams
    }

    fun getParams(): GenerationParams = params

    // ------------------------------------------------------------------
    // Liberação final
    // ------------------------------------------------------------------

    suspend fun release() = withContext(Dispatchers.IO) {
        LlamaNative.unloadModel()
        LlamaNative.freeBackend()
        _currentModel.value = null
        _state.value = State.UNINITIALIZED
    }

    companion object {
        private const val TAG = "LocalLlmEngine"
    }
}
