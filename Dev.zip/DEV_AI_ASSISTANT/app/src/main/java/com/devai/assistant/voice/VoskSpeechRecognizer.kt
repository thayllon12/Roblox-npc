package com.devai.assistant.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Reconhecimento de fala offline com Vosk (português brasileiro).
 *
 * Responsabilidades:
 * - Gerenciar modelo Vosk (download/importação/descompactação)
 * - Capturar áudio e converter em texto
 * - Emitir resultados parciais e finais
 * - Não misturar com wake word (isso é outra camada)
 */
class VoskSpeechRecognizer(private val context: Context) {

    enum class State {
        UNINITIALIZED,
        MODEL_MISSING,
        LOADING_MODEL,
        READY,
        LISTENING,
        ERROR
    }

    data class Result(
        val text: String,
        val isFinal: Boolean
    )

    private val _state = MutableStateFlow(State.UNINITIALIZED)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _lastFinalText = MutableStateFlow<String?>(null)
    val lastFinalText: StateFlow<String?> = _lastFinalText.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private var model: Model? = null
    private var speechService: SpeechService? = null
    private var onFinalResult: ((String) -> Unit)? = null

    private val modelsDir: File by lazy {
        File(context.filesDir, "vosk-models").also { it.mkdirs() }
    }

    // ------------------------------------------------------------------
    // Modelo
    // ------------------------------------------------------------------

    /**
     * Verifica se o modelo PT-BR padrão já está instalado.
     */
    fun isModelInstalled(): Boolean {
        val dir = File(modelsDir, MODEL_NAME)
        return dir.exists() && dir.isDirectory && dir.list()?.isNotEmpty() == true
    }

    fun getModelPath(): File = File(modelsDir, MODEL_NAME)

    /**
     * Descompacta um ZIP do modelo Vosk já baixado (ex.: obtido via download externo).
     * O ZIP oficial tem a pasta do modelo na raiz ou um nível abaixo.
     */
    suspend fun installModelFromZip(zipFile: File): Boolean = withContext(Dispatchers.IO) {
        if (!zipFile.exists()) {
            _lastError.value = "Arquivo ZIP não encontrado"
            return@withContext false
        }
        _state.value = State.LOADING_MODEL
        try {
            val target = File(modelsDir, MODEL_NAME)
            if (target.exists()) target.deleteRecursively()
            target.mkdirs()

            ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    // Remove o primeiro nível de pasta se existir (vosk-model-small-pt-0.3/...)
                    val relative = name.substringAfter("$MODEL_NAME/", name)
                        .substringAfter("vosk-model-small-pt-0.3/", name)
                        .let {
                            if (it.startsWith("vosk-model")) it.substringAfter("/") else it
                        }
                    if (relative.isNotBlank() && !entry.isDirectory) {
                        val outFile = File(target, relative)
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (target.list()?.isEmpty() != false) {
                _lastError.value = "ZIP não continha arquivos de modelo válidos"
                _state.value = State.MODEL_MISSING
                return@withContext false
            }

            Log.i(TAG, "Model installed at ${target.absolutePath}")
            loadModel()
            true
        } catch (e: Exception) {
            Log.e(TAG, "installModelFromZip failed", e)
            _lastError.value = e.message
            _state.value = State.ERROR
            false
        }
    }

    /**
     * Carrega o modelo já instalado em memória.
     */
    suspend fun loadModel(): Boolean = withContext(Dispatchers.IO) {
        if (!isModelInstalled()) {
            _state.value = State.MODEL_MISSING
            _lastError.value = "Modelo Vosk PT-BR não instalado"
            return@withContext false
        }
        _state.value = State.LOADING_MODEL
        try {
            model?.close()
            model = Model(getModelPath().absolutePath)
            _state.value = State.READY
            _lastError.value = null
            Log.i(TAG, "Vosk model loaded")
            true
        } catch (e: Exception) {
            Log.e(TAG, "loadModel failed", e)
            _lastError.value = "Falha ao carregar modelo: ${e.message}"
            _state.value = State.ERROR
            false
        }
    }

    // ------------------------------------------------------------------
    // Reconhecimento
    // ------------------------------------------------------------------

    /**
     * Inicia escuta contínua. Resultados finais são entregues em [onFinal].
     * Resultados parciais ficam em [partialText].
     */
    fun startListening(onFinal: (String) -> Unit) {
        if (_state.value != State.READY && _state.value != State.LISTENING) {
            Log.w(TAG, "Cannot start: state=${_state.value}")
            return
        }
        val m = model
        if (m == null) {
            _lastError.value = "Modelo não carregado"
            return
        }

        stopListening()
        onFinalResult = onFinal
        _partialText.value = ""
        _lastFinalText.value = null

        try {
            val recognizer = Recognizer(m, SAMPLE_RATE.toFloat())
            speechService = SpeechService(recognizer, SAMPLE_RATE.toFloat()).also { service ->
                service.startListening(object : RecognitionListener {
                    override fun onPartialResult(hypothesis: String?) {
                        hypothesis ?: return
                        try {
                            val text = JSONObject(hypothesis).optString("partial", "")
                            if (text.isNotBlank()) {
                                _partialText.value = text
                            }
                        } catch (_: Exception) { }
                    }

                    override fun onResult(hypothesis: String?) {
                        hypothesis ?: return
                        try {
                            val text = JSONObject(hypothesis).optString("text", "").trim()
                            if (text.isNotBlank()) {
                                _lastFinalText.value = text
                                _partialText.value = ""
                                onFinalResult?.invoke(text)
                            }
                        } catch (_: Exception) { }
                    }

                    override fun onFinalResult(hypothesis: String?) {
                        // Já tratado em onResult para a maioria dos casos
                    }

                    override fun onError(e: Exception?) {
                        Log.e(TAG, "Recognition error", e)
                        _lastError.value = e?.message
                        _state.value = State.ERROR
                    }

                    override fun onTimeout() {
                        Log.i(TAG, "Recognition timeout")
                    }
                })
            }
            _state.value = State.LISTENING
            Log.i(TAG, "Listening started")
        } catch (e: Exception) {
            Log.e(TAG, "startListening failed", e)
            _lastError.value = e.message
            _state.value = State.ERROR
        }
    }

    fun stopListening() {
        try {
            speechService?.stop()
            speechService?.shutdown()
        } catch (_: Exception) { }
        speechService = null
        if (_state.value == State.LISTENING) {
            _state.value = State.READY
        }
        onFinalResult = null
    }

    fun release() {
        stopListening()
        try {
            model?.close()
        } catch (_: Exception) { }
        model = null
        _state.value = State.UNINITIALIZED
    }

    companion object {
        private const val TAG = "VoskSpeechRecognizer"
        const val MODEL_NAME = "vosk-model-small-pt-0.3"
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip"
        const val MODEL_SIZE_MB = 31
        private const val SAMPLE_RATE = 16000
    }
}
