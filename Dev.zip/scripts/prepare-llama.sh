#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLAMA_DIR="$ROOT_DIR/app/src/main/cpp/llama.cpp"
LLAMA_TAG="${LLAMA_CPP_TAG:-b4510}"

if [[ -f "$LLAMA_DIR/CMakeLists.txt" && -f "$LLAMA_DIR/ggml/CMakeLists.txt" ]]; then
  echo "llama.cpp e ggml já estão disponíveis em $LLAMA_DIR"
  exit 0
fi

rm -rf "$LLAMA_DIR"
mkdir -p "$(dirname "$LLAMA_DIR")"
echo "Baixando llama.cpp $LLAMA_TAG e todos os submódulos necessários..."
git clone --depth 1 --recurse-submodules --shallow-submodules \
  --branch "$LLAMA_TAG" https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"

git -C "$LLAMA_DIR" submodule update --init --recursive --depth 1
[[ -f "$LLAMA_DIR/CMakeLists.txt" ]] || { echo "llama.cpp incompleto" >&2; exit 1; }
[[ -f "$LLAMA_DIR/ggml/CMakeLists.txt" ]] || { echo "Submódulo ggml ausente" >&2; exit 1; }
echo "llama.cpp pronto. Commit: $(git -C "$LLAMA_DIR" rev-parse --short HEAD)"
