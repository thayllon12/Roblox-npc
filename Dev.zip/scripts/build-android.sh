#!/usr/bin/env bash
# Build local Linux/macOS. Android SDK + JDK 17 must be installed and licensed.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GRADLE_VERSION="8.9"
GRADLE_HOME_DIR="${GRADLE_USER_HOME:-$HOME/.gradle}/bootstrap/gradle-$GRADLE_VERSION"

if ! command -v java >/dev/null 2>&1; then
  echo "JDK 17 não encontrado. Instale o JDK 17 e configure JAVA_HOME." >&2
  exit 1
fi
JAVA_MAJOR="$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | awk -F. '{if ($1==1) print $2; else print $1}')"
if [[ "$JAVA_MAJOR" != "17" ]]; then
  echo "Este projeto requer JDK 17; encontrado: ${JAVA_MAJOR:-desconhecido}." >&2
  exit 1
fi

if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "Defina ANDROID_HOME ou ANDROID_SDK_ROOT para o Android SDK." >&2
  exit 1
fi
export ANDROID_HOME="${ANDROID_HOME:-$ANDROID_SDK_ROOT}"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/26.1.10909125"
export ANDROID_NDK_ROOT="$ANDROID_NDK_HOME"

if [[ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]]; then
  echo "Android SDK Command-line Tools não encontrados em $ANDROID_HOME." >&2
  exit 1
fi
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --licenses >/dev/null
"$SDKMANAGER" 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0' 'ndk;26.1.10909125' 'cmake;3.22.1'

if command -v gradle >/dev/null 2>&1 && gradle --version 2>/dev/null | grep -q "Gradle $GRADLE_VERSION"; then
  GRADLE_BIN="$(command -v gradle)"
else
  if [[ ! -x "$GRADLE_HOME_DIR/bin/gradle" ]]; then
    mkdir -p "$(dirname "$GRADLE_HOME_DIR")"
    ARCHIVE="$(dirname "$GRADLE_HOME_DIR")/gradle-$GRADLE_VERSION-bin.zip"
    curl --fail --location --retry 3 "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ARCHIVE"
    unzip -q "$ARCHIVE" -d "$(dirname "$GRADLE_HOME_DIR")"
    rm -f "$ARCHIVE"
  fi
  GRADLE_BIN="$GRADLE_HOME_DIR/bin/gradle"
fi

"$ROOT_DIR/scripts/prepare-llama.sh"
cd "$ROOT_DIR"
"$GRADLE_BIN" --no-daemon --stacktrace --refresh-dependencies :app:dependencies
"$GRADLE_BIN" --no-daemon --stacktrace assembleDebug
printf '\nAPK gerado em: %s\n' "$ROOT_DIR/app/build/outputs/apk/debug/app-debug.apk"
