cmake_minimum_required(VERSION 3.22.1)
project("devai-llama" VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Inferência local verdadeira é requisito: não gerar APK silenciosamente em STUB.
set(LLAMA_DIR "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp")
if(NOT EXISTS "${LLAMA_DIR}/CMakeLists.txt")
    message(FATAL_ERROR
        "llama.cpp ausente em app/src/main/cpp/llama.cpp. "
        "Execute scripts/prepare-llama.sh antes de compilar. "
        "O build STUB foi desativado para impedir respostas falsas.")
endif()

set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)
set(GGML_BACKEND_DL OFF CACHE BOOL "" FORCE)

add_subdirectory("${LLAMA_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/llama" EXCLUDE_FROM_ALL)

add_library(devai-llama SHARED llama_jni.cpp)
target_include_directories(devai-llama PRIVATE
    "${LLAMA_DIR}/include"
    "${LLAMA_DIR}/ggml/include"
)
target_link_libraries(devai-llama PRIVATE llama android log)
target_compile_definitions(devai-llama PRIVATE USE_REAL_LLAMA=1)
target_compile_options(devai-llama PRIVATE
    -O3 -fvisibility=hidden -ffunction-sections -fdata-sections
)
