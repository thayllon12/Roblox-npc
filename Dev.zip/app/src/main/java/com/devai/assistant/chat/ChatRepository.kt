package com.devai.assistant.chat

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await

data class Conversation(val id: String, val title: String, val updatedAt: Long)

data class StoredMessage(val id: String, val role: String, val text: String, val createdAt: Long)

/** Conversas e mensagens em users/{uid}/conversations/{id}/messages. */
class ChatRepository(uid: String) {

    private val db = FirebaseFirestore.getInstance()
    private val conversations = db.collection("users").document(uid).collection("conversations")

    fun observeConversations(onChange: (List<Conversation>) -> Unit): ListenerRegistration =
        conversations.orderBy("updatedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    Log.w(TAG, "Falha ao ler conversas", error)
                    return@addSnapshotListener
                }
                onChange(
                    snap?.documents?.map { doc ->
                        Conversation(
                            id = doc.id,
                            title = doc.getString("title") ?: "Nova conversa",
                            updatedAt = doc.getLong("updatedAt") ?: 0L
                        )
                    }.orEmpty()
                )
            }

    fun observeMessages(conversationId: String, onChange: (List<StoredMessage>) -> Unit): ListenerRegistration =
        conversations.document(conversationId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    Log.w(TAG, "Falha ao ler mensagens", error)
                    return@addSnapshotListener
                }
                onChange(
                    snap?.documents?.map { doc ->
                        StoredMessage(
                            id = doc.id,
                            role = doc.getString("role") ?: "user",
                            text = doc.getString("text").orEmpty(),
                            createdAt = doc.getLong("createdAt") ?: 0L
                        )
                    }.orEmpty()
                )
            }

    suspend fun createConversation(title: String): String {
        val now = System.currentTimeMillis()
        return conversations.add(
            mapOf("title" to title, "createdAt" to now, "updatedAt" to now)
        ).await().id
    }

    suspend fun addMessage(conversationId: String, role: String, text: String) {
        val now = System.currentTimeMillis()
        val convRef = conversations.document(conversationId)
        convRef.collection("messages")
            .add(mapOf("role" to role, "text" to text, "createdAt" to now))
            .await()
        convRef.update("updatedAt", now).await()
    }

    suspend fun rename(conversationId: String, title: String) {
        conversations.document(conversationId).update("title", title).await()
    }

    suspend fun delete(conversationId: String) {
        val convRef = conversations.document(conversationId)
        val messages = convRef.collection("messages").get().await()
        // Firestore aceita até 500 operações por lote; trabalha em blocos menores.
        messages.documents.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { batch.delete(it.reference) }
            batch.commit().await()
        }
        convRef.delete().await()
    }

    companion object {
        private const val TAG = "ChatRepository"
    }
}
