package com.devai.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.devai.assistant.localmodel.LocalLlmEngine

class DevAiApplication : Application() {

    /** Uma única instância nativa evita inicializar/liberar llama.cpp em duplicidade. */
    val llmEngine: LocalLlmEngine by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        LocalLlmEngine(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ASSISTANT,
                "Assistente DEV AI",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificação do serviço de voz em segundo plano"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ASSISTANT = "dev_ai_assistant_channel"
    }
}
