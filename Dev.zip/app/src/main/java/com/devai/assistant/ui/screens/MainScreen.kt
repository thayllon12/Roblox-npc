package com.devai.assistant.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.devai.assistant.localmodel.LocalLlmEngine
import com.devai.assistant.R
import com.devai.assistant.ui.components.AssistantOrb
import com.devai.assistant.ui.components.GlassCard
import com.devai.assistant.ui.components.OrbState
import com.devai.assistant.ui.theme.Cyan
import com.devai.assistant.ui.theme.CyanBright
import com.devai.assistant.ui.theme.DeepBlack
import com.devai.assistant.ui.theme.ElectricBlue
import com.devai.assistant.ui.theme.Navy
import com.devai.assistant.ui.theme.NavyDark
import com.devai.assistant.ui.theme.NavyMid
import com.devai.assistant.ui.theme.TextMuted
import com.devai.assistant.ui.theme.TextPrimary
import com.devai.assistant.ui.theme.TextSecondary
import com.devai.assistant.voice.VoiceAssistantController
import com.devai.assistant.voice.VoskSpeechRecognizer

@Composable
fun MainScreen(
    onOpenSettings: () -> Unit = {},
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current
    val orbState by viewModel.orbState.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val currentModel by viewModel.currentModel.collectAsState()
    val engineState by viewModel.engineState.collectAsState()
    val importedModels by viewModel.importedModels.collectAsState()
    val generationResult by viewModel.generationResult.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val lastError by viewModel.lastError.collectAsState()
    val voskModelReady by viewModel.voskModelReady.collectAsState()
    val voicePhase by viewModel.voicePhase.collectAsState()
    val transcript by viewModel.transcript.collectAsState()
    val reply by viewModel.reply.collectAsState()
    val partialText by viewModel.partialText.collectAsState()
    val voskState by viewModel.voskState.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasMicPermission = granted }

    val ggufPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { viewModel.importFromUri(it) } }

    val voskPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { viewModel.importVoskZip(it) } }

    val isListening = voicePhase == VoiceAssistantController.Phase.LISTENING

    LaunchedEffect(hasMicPermission, voskState) {
        if (hasMicPermission && voskState == VoskSpeechRecognizer.State.READY) {
            viewModel.startWakeWord()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(DeepBlack, NavyDark, Navy, DeepBlack)
                )
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(ElectricBlue.copy(alpha = 0.12f), Color.Transparent),
                        radius = 600f
                    )
                )
                .align(Alignment.TopCenter)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.devex_logo),
                        contentDescription = "Logo oficial DEVEx",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("DEV AI", style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp
                        ), color = TextPrimary)
                        Text("ASSISTANT", style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp),
                            color = TextSecondary)
                    }
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(NavyMid.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Default.Settings, "Configurações", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status cards
            GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 16.dp, contentPadding = 12.dp) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Modelo LLM", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text(
                            currentModel?.displayName ?: "Nenhum",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (currentModel != null) CyanBright else TextMuted,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Vosk PT-BR", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text(
                            when {
                                voskModelReady && voskState == VoskSpeechRecognizer.State.READY -> "Pronto"
                                voskModelReady -> "Carregando…"
                                else -> "Não instalado"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = if (voskModelReady) CyanBright else TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Orb
            Box(contentAlignment = Alignment.Center) {
                AssistantOrb(
                    state = orbState,
                    size = 200.dp,
                    onClick = {
                        if (!hasMicPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            return@AssistantOrb
                        }
                        if (isListening) viewModel.stopListening()
                        else if (engineState == LocalLlmEngine.State.MODEL_LOADED &&
                            voskState == VoskSpeechRecognizer.State.READY
                        ) {
                            viewModel.startListening()
                        }
                    }
                )
                if (isBusy || engineState == LocalLlmEngine.State.LOADING_MODEL) {
                    CircularProgressIndicator(Modifier.size(32.dp), color = CyanBright, strokeWidth = 2.dp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            AnimatedContent(targetState = statusMessage, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "status") { text ->
                Text(
                    text,
                    style = MaterialTheme.typography.titleMedium,
                    color = when (orbState) {
                        OrbState.ERROR -> MaterialTheme.colorScheme.error
                        OrbState.LISTENING, OrbState.THINKING, OrbState.RESPONDING -> CyanBright
                        else -> TextPrimary
                    },
                    textAlign = TextAlign.Center
                )
            }

            // Transcrição parcial / final
            if (partialText.isNotBlank() || transcript.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (partialText.isNotBlank()) "… $partialText" else "Você: $transcript",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
            if (reply.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "IA: $reply",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyanBright,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Botões de ação
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Escutar
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 14.dp, contentPadding = 10.dp) {
                    TextButton(
                        onClick = {
                            if (!hasMicPermission) {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                return@TextButton
                            }
                            if (isListening) viewModel.stopListening()
                            else viewModel.startListening()
                        },
                        enabled = voskState == VoskSpeechRecognizer.State.READY &&
                                engineState == LocalLlmEngine.State.MODEL_LOADED,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            null, tint = CyanBright
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(if (isListening) "Parar" else "Falar agora", color = TextPrimary)
                    }
                }
                // Import GGUF
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 14.dp, contentPadding = 10.dp) {
                    TextButton(
                        onClick = { ggufPicker.launch(arrayOf("*/*")) },
                        enabled = !isBusy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, null, tint = CyanBright)
                        Spacer(Modifier.width(4.dp))
                        Text("GGUF", color = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Import Vosk
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 14.dp, contentPadding = 10.dp) {
                    TextButton(
                        onClick = { voskPicker.launch(arrayOf("application/zip", "*/*")) },
                        enabled = !isBusy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, null, tint = CyanBright)
                        Spacer(Modifier.width(4.dp))
                        Text("Vosk ZIP", color = TextPrimary)
                    }
                }
                // Test LLM
                GlassCard(modifier = Modifier.weight(1f), cornerRadius = 14.dp, contentPadding = 10.dp) {
                    TextButton(
                        onClick = {
                            if (engineState == LocalLlmEngine.State.GENERATING) viewModel.stopGeneration()
                            else viewModel.testGenerate()
                        },
                        enabled = engineState == LocalLlmEngine.State.MODEL_LOADED ||
                                engineState == LocalLlmEngine.State.GENERATING,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            if (engineState == LocalLlmEngine.State.GENERATING) Icons.Default.Stop
                            else Icons.Default.PlayArrow,
                            null, tint = CyanBright
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            if (engineState == LocalLlmEngine.State.GENERATING) "Parar" else "Testar LLM",
                            color = TextPrimary
                        )
                    }
                }
            }

            if (!hasMicPermission) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Permissão de microfone necessária para escutar",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            if (generationResult != null) {
                Spacer(modifier = Modifier.height(12.dp))
                GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 16.dp) {
                    Column {
                        Text("Resposta (teste LLM)", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Spacer(Modifier.height(6.dp))
                        Text(generationResult ?: "", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Lista GGUF
            GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 18.dp) {
                Column {
                    Text("Modelos GGUF", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    if (importedModels.isEmpty()) {
                        Text(
                            "Importe Qwen3-0.6B-Q8_0.gguf do Hugging Face.",
                            style = MaterialTheme.typography.bodyMedium, color = TextMuted
                        )
                    } else {
                        importedModels.forEach { model ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(model.displayName, style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(model.formattedSize(), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                                TextButton(onClick = { viewModel.loadModel(model) }, enabled = !isBusy) {
                                    Text("Carregar", color = CyanBright)
                                }
                                TextButton(onClick = { viewModel.removeModel(model) }, enabled = !isBusy) {
                                    Text("X", color = TextMuted)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                "Fase C — Voz (Vosk PT-BR + TTS)\nBaixe: alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted.copy(alpha = 0.75f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
    }
}
