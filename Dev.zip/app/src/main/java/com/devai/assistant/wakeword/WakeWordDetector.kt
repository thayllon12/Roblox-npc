package com.devai.assistant.wakeword

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.FloatBuffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detector de wake word baseado em ONNX Runtime.
 *
 * Arquitetura (alinhada ao openWakeWord):
 * 1. Captura PCM 16 kHz mono
 * 2. (Opcional) melspectrogram + embedding ONNX se presentes
 * 3. Classificador ONNX da frase-alvo → score 0..1
 *
 * IMPORTANTE:
 * Não existe modelo pré-treinado e validado para "Hey Dev AI" neste pacote.
 * O usuário deve treinar um classificador ONNX (ver docs/PHASE_D_WAKEWORD.md)
 * e importá-lo. Sem o modelo personalizado, o detector permanece inativo
 * e o app continua funcional via botão "Escutar" (Fase C).
 *
 * Arquivos esperados em filesDir/wakeword/ :
 *   - hey_dev_ai.onnx          (classificador obrigatório)
 *   - melspectrogram.onnx      (opcional, pipeline completo)
 *   - embedding_model.onnx     (opcional)
 */
class WakeWordDetector(private val context: Context) {

    enum class State {
        DISABLED,       // Sem modelo ou desligado pelo usuário
        READY,          // Modelo carregado, não escutando
        LISTENING,      // Escutando continuamente a frase
        DETECTED,       // Frase detectada (estado transitório)
        ERROR
    }

    private val _state = MutableStateFlow(State.DISABLED)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _lastScore = MutableStateFlow(0f)
    val lastScore: StateFlow<Float> = _lastScore.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _modelName = MutableStateFlow<String?>(null)
    val modelName: StateFlow<String?> = _modelName.asStateFlow()

    private var ortEnv: OrtEnvironment? = null
    private var classifierSession: OrtSession? = null
    private var audioRecord: AudioRecord? = null
    private var listenJob: Job? = null
    private var onDetected: (() -> Unit)? = null

    /** Limiar de detecção (0.0–1.0). Ajuste conforme o modelo treinado. */
    var threshold: Float = 0.5f

    /** Cooldown em ms para evitar múltiplos disparos seguidos. */
    var cooldownMs: Long = 2000L
    private var lastDetectionTime = 0L

    private val wakewordDir: File by lazy {
        File(context.filesDir, "wakeword").also { it.mkdirs() }
    }

    // ------------------------------------------------------------------
    // Modelo
    // ------------------------------------------------------------------

    fun hasClassifierModel(): Boolean {
        return File(wakewordDir, CLASSIFIER_NAME).exists()
    }

    /**
     * Importa um arquivo .onnx de classificador (ex.: hey_dev_ai.onnx).
     */
    suspend fun importClassifier(source: File, displayName: String = CLASSIFIER_NAME): Boolean =
        withContext(Dispatchers.IO) {
            if (!source.exists() || !source.name.lowercase().endsWith(".onnx")) {
                _lastError.value = "Arquivo deve ser .onnx"
                return@withContext false
            }
            try {
                val dest = File(wakewordDir, CLASSIFIER_NAME)
                source.copyTo(dest, overwrite = true)
                // Também copia .onnx.data se existir (pesos externos do openWakeWord)
                val dataSrc = File(source.parentFile, source.name + ".data")
                if (dataSrc.exists()) {
                    dataSrc.copyTo(File(wakewordDir, CLASSIFIER_NAME + ".data"), overwrite = true)
                }
                _modelName.value = displayName
                loadModel()
            } catch (e: Exception) {
                _lastError.value = e.message
                false
            }
        }

    /**
     * Importa via stream (SAF).
     */
    suspend fun importClassifierFromStream(
        input: java.io.InputStream,
        sizeHint: Long = -1
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val dest = File(wakewordDir, CLASSIFIER_NAME)
            FileOutputStream(dest).use { out -> input.copyTo(out) }
            if (dest.length() < 1000) {
                dest.delete()
                _lastError.value = "Arquivo ONNX inválido ou muito pequeno"
                return@withContext false
            }
            _modelName.value = CLASSIFIER_NAME
            loadModel()
        } catch (e: Exception) {
            _lastError.value = e.message
            false
        }
    }

    suspend fun loadModel(): Boolean = withContext(Dispatchers.IO) {
        val modelFile = File(wakewordDir, CLASSIFIER_NAME)
        if (!modelFile.exists()) {
            _state.value = State.DISABLED
            _lastError.value = "Modelo hey_dev_ai.onnx não encontrado. Treine e importe (ver docs)."
            return@withContext false
        }
        try {
            releaseSessions()
            ortEnv = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }
            classifierSession = ortEnv!!.createSession(modelFile.absolutePath, opts)
            _state.value = State.READY
            _lastError.value = null
            _modelName.value = modelFile.name
            Log.i(TAG, "Wake word model loaded: ${modelFile.name}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "loadModel failed", e)
            _lastError.value = "Falha ao carregar ONNX: ${e.message}"
            _state.value = State.ERROR
            false
        }
    }

    // ------------------------------------------------------------------
    // Detecção contínua
    // ------------------------------------------------------------------

    fun start(onWake: () -> Unit) {
        if (_state.value != State.READY && _state.value != State.LISTENING) {
            Log.w(TAG, "Cannot start: state=${_state.value}")
            return
        }
        stop()
        onDetected = onWake

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            _lastError.value = "AudioRecord não disponível"
            _state.value = State.ERROR
            return
        }

        val bufferSize = maxOf(minBuf, FRAME_SAMPLES * 2)
        try {
            @Suppress("MissingPermission")
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                _lastError.value = "AudioRecord init falhou"
                _state.value = State.ERROR
                return
            }
            audioRecord?.startRecording()
        } catch (e: SecurityException) {
            _lastError.value = "Permissão RECORD_AUDIO negada"
            _state.value = State.ERROR
            return
        } catch (e: Exception) {
            _lastError.value = e.message
            _state.value = State.ERROR
            return
        }

        _state.value = State.LISTENING
        listenJob = CoroutineScope(Dispatchers.Default).launch {
            val shortBuf = ShortArray(FRAME_SAMPLES)
            val floatBuf = FloatArray(FRAME_SAMPLES)
            // Buffer deslizante simples para features (modo simplificado)
            val featureWindow = ArrayDeque<Float>()
            val windowSize = 16 * 96 // típico openWakeWord embedding frame stack

            while (isActive) {
                val read = audioRecord?.read(shortBuf, 0, FRAME_SAMPLES) ?: -1
                if (read <= 0) continue

                // PCM 16-bit → float normalizado
                for (i in 0 until read) {
                    floatBuf[i] = shortBuf[i] / 32768f
                }

                // Modo simplificado: se o classificador aceita áudio cru ou features fixas.
                // Modelos openWakeWord completos esperam embedding [1,16,96].
                // Aqui tentamos inferir com o que temos; o ideal é pipeline completo.
                val score = runInferenceSimplified(floatBuf, read, featureWindow, windowSize)
                _lastScore.value = score

                if (score >= threshold) {
                    val now = System.currentTimeMillis()
                    if (now - lastDetectionTime >= cooldownMs) {
                        lastDetectionTime = now
                        Log.i(TAG, "Wake word DETECTED score=$score")
                        _state.value = State.DETECTED
                        withContext(Dispatchers.Main) {
                            onDetected?.invoke()
                        }
                        // Volta a escutar após cooldown
                        kotlinx.coroutines.delay(cooldownMs)
                        if (isActive) _state.value = State.LISTENING
                    }
                }
            }
        }
        Log.i(TAG, "Wake word listening started (threshold=$threshold)")
    }

    fun stop() {
        listenJob?.cancel()
        listenJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) { }
        audioRecord = null
        if (_state.value == State.LISTENING || _state.value == State.DETECTED) {
            _state.value = if (classifierSession != null) State.READY else State.DISABLED
        }
        onDetected = null
    }

    /**
     * Inferência simplificada.
     * Modelos openWakeWord completos precisam de melspectrogram + embedding.
     * Quando apenas o classificador está presente, usamos uma janela de energia/features
     * brutas como fallback para desenvolvimento. Com pipeline completo (3 ONNX),
     * substitua esta função pela cadeia oficial.
     */
    private fun runInferenceSimplified(
        samples: FloatArray,
        n: Int,
        window: ArrayDeque<Float>,
        windowSize: Int
    ): Float {
        val session = classifierSession ?: return 0f
        val env = ortEnv ?: return 0f

        // Acumula RMS como feature simples (placeholder)
        var sumSq = 0f
        for (i in 0 until n) sumSq += samples[i] * samples[i]
        val rms = sqrt(sumSq / n)
        window.addLast(rms)
        while (window.size > windowSize) window.removeFirst()
        if (window.size < 16) return 0f

        return try {
            // Tenta descobrir o nome e shape da entrada
            val inputName = session.inputNames.firstOrNull() ?: return 0f
            val info = session.inputInfo[inputName]?.info
            // Para classificador típico openWakeWord: input "onnx::Flatten_0" ou "x" shape [1, N]
            // Usamos um vetor de features derivadas
            val feats = FloatArray(16) { i ->
                val idx = window.size - 16 + i
                if (idx >= 0) window.elementAt(idx) else 0f
            }
            val shape = longArrayOf(1, 16)
            val buffer = FloatBuffer.wrap(feats)
            OnnxTensor.createTensor(env, buffer, shape).use { tensor ->
                session.run(mapOf(inputName to tensor)).use { result ->
                    val out = result[0].value
                    when (out) {
                        is Array<*> -> {
                            @Suppress("UNCHECKED_CAST")
                            val arr = out as Array<FloatArray>
                            arr[0].maxOrNull() ?: 0f
                        }
                        is FloatArray -> out.maxOrNull() ?: 0f
                        else -> 0f
                    }
                }
            }
        } catch (e: Exception) {
            // Modelo com shape diferente — score 0 até pipeline completo
            Log.v(TAG, "inference shape mismatch (expected until full pipeline): ${e.message}")
            0f
        }
    }

    fun setEnabled(enabled: Boolean) {
        if (!enabled) {
            stop()
            if (_state.value != State.ERROR) _state.value = State.DISABLED
        } else if (classifierSession != null) {
            _state.value = State.READY
        }
    }

    fun release() {
        stop()
        releaseSessions()
        _state.value = State.DISABLED
    }

    private fun releaseSessions() {
        try { classifierSession?.close() } catch (_: Exception) { }
        classifierSession = null
        // OrtEnvironment é singleton — não fechar globalmente
    }

    companion object {
        private const val TAG = "WakeWordDetector"
        const val CLASSIFIER_NAME = "hey_dev_ai.onnx"
        const val SAMPLE_RATE = 16000
        const val FRAME_MS = 80
        val FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS / 1000 // 1280 samples
    }
}
