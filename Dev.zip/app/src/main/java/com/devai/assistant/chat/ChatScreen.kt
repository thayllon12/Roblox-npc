package com.devai.assistant.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.devai.assistant.ui.theme.Cyan
import com.devai.assistant.ui.theme.DeepBlack
import com.devai.assistant.ui.theme.GlassBorder
import com.devai.assistant.ui.theme.GlassMedium
import com.devai.assistant.ui.theme.NavyDark
import com.devai.assistant.ui.theme.NavyMid
import com.devai.assistant.ui.theme.TextMuted
import com.devai.assistant.ui.theme.TextPrimary
import com.devai.assistant.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    uid: String,
    onOpenVoice: () -> Unit,
    vm: ChatViewModel = viewModel()
) {
    LaunchedEffect(uid) { vm.start(uid) }

    val conversations by vm.conversations.collectAsState()
    val messages by vm.messages.collectAsState()
    val currentId by vm.currentId.collectAsState()
    val sending by vm.sending.collectAsState()
    val error by vm.error.collectAsState()

    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var showKeyDialog by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Conversation?>(null) }

    LaunchedEffect(error) {
        error?.let {
            snackbar.showSnackbar(it)
            vm.clearError()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = NavyDark) {
                Sidebar(
                    conversations = conversations,
                    currentId = currentId,
                    onNew = {
                        vm.newChat()
                        scope.launch { drawer.close() }
                    },
                    onSelect = {
                        vm.openConversation(it)
                        scope.launch { drawer.close() }
                    },
                    onRename = { renaming = it },
                    onDelete = { vm.delete(it.id) }
                )
            }
        }
    ) {
        Scaffold(
            containerColor = DeepBlack,
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepBlack),
                    title = { Text("DEV AI", color = TextPrimary) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Filled.Menu, "Abrir menu", tint = TextPrimary)
                        }
                    },
                    actions = {
                        IconButton(onClick = onOpenVoice) {
                            Icon(Icons.Filled.Mic, "Assistente de voz", tint = TextPrimary)
                        }
                        IconButton(onClick = { showKeyDialog = true }) {
                            Icon(Icons.Filled.Settings, "Configurações", tint = TextPrimary)
                        }
                    }
                )
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                MessageList(
                    messages = messages,
                    sending = sending,
                    modifier = Modifier.weight(1f)
                )
                Composer(
                    sending = sending,
                    onSend = { vm.send(it) },
                    onStop = { vm.stop() }
                )
            }
        }
    }

    if (showKeyDialog) {
        var key by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showKeyDialog = false },
            title = { Text("Chave da API Gemini") },
            text = {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    placeholder = { Text("Cole sua chave do Google AI Studio") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (key.isNotBlank()) vm.saveApiKey(key.trim())
                    showKeyDialog = false
                }) { Text("Salvar") }
            },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false }) { Text("Cancelar") }
            }
        )
    }

    renaming?.let { conv ->
        var name by remember(conv.id) { mutableStateOf(conv.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renomear conversa") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.rename(conv.id, name.trim())
                    renaming = null
                }) { Text("Salvar") }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun Sidebar(
    conversations: List<Conversation>,
    currentId: String?,
    onNew: () -> Unit,
    onSelect: (String) -> Unit,
    onRename: (Conversation) -> Unit,
    onDelete: (Conversation) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Button(
            onClick = onNew,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = DeepBlack)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Nova conversa")
        }
        Spacer(Modifier.height(16.dp))
        if (conversations.isEmpty()) {
            Text("Nenhuma conversa ainda", color = TextMuted)
        }
        LazyColumn {
            items(conversations, key = { it.id }) { conv ->
                val selected = conv.id == currentId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (selected) GlassMedium else Color.Transparent, RoundedCornerShape(10.dp))
                        .clickable { onSelect(conv.id) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = conv.title,
                        modifier = Modifier.weight(1f),
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = { onRename(conv) }) {
                        Icon(Icons.Filled.Edit, "Renomear", tint = TextSecondary)
                    }
                    IconButton(onClick = { onDelete(conv) }) {
                        Icon(Icons.Filled.Delete, "Excluir", tint = TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageList(
    messages: List<StoredMessage>,
    sending: Boolean,
    modifier: Modifier
) {
    if (messages.isEmpty() && !sending) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "Como posso ajudar?",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
        }
        return
    }
    val count = messages.size + if (sending) 1 else 0
    val listState = rememberLazyListState()
    LaunchedEffect(count) {
        if (count > 0) listState.animateScrollToItem(count - 1)
    }
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        state = listState,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(messages, key = { it.id }) { MessageBubble(it) }
        if (sending) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = Cyan
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Pensando…", color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(msg: StoredMessage) {
    val isUser = msg.role == "user"
    val clipboard = LocalClipboardManager.current
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            shape = RoundedCornerShape(18.dp),
            color = if (isUser) NavyMid else NavyDark,
            border = BorderStroke(1.dp, GlassBorder)
        ) {
            SelectionContainer {
                Text(
                    text = msg.text,
                    modifier = Modifier.padding(12.dp),
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
        if (!isUser) {
            TextButton(onClick = { clipboard.setText(AnnotatedString(msg.text)) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Copiar", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun Composer(
    sending: Boolean,
    onSend: (String) -> Unit,
    onStop: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    Row(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Mensagem para o DEV AI") },
            shape = RoundedCornerShape(24.dp),
            maxLines = 5,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Cyan,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = Cyan
            )
        )
        Spacer(Modifier.width(8.dp))
        if (sending) {
            FilledIconButton(
                onClick = onStop,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = GlassMedium, contentColor = TextPrimary)
            ) { Icon(Icons.Filled.Stop, "Interromper") }
        } else {
            FilledIconButton(
                onClick = {
                    if (text.isNotBlank()) {
                        onSend(text.trim())
                        text = ""
                    }
                },
                enabled = text.isNotBlank(),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Cyan, contentColor = DeepBlack)
            ) { Icon(Icons.Filled.Send, "Enviar") }
        }
    }
}
