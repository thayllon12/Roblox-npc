package com.devai.assistant.storage

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/** Persistência na nuvem (Cloud Firestore). Cada usuário grava apenas no próprio documento. */
class CloudRepository {

    private val db = FirebaseFirestore.getInstance()

    suspend fun saveUserProfile(user: FirebaseUser) {
        val data = hashMapOf<String, Any?>(
            "uid" to user.uid,
            "name" to user.displayName,
            "email" to user.email,
            "photoUrl" to user.photoUrl?.toString(),
            "lastLoginAt" to FieldValue.serverTimestamp()
        )
        db.collection("users").document(user.uid)
            .set(data, SetOptions.merge())
            .await()
    }
}
