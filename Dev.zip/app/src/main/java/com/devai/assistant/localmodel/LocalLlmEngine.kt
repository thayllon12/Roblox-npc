package com.devai.assistant.localmodel

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID

/**
 * Motor de IA local baseado em llama.cpp.
 *
 * Responsabilidades:
 * - Importar arquivos GGUF (via URI ou path)
 * - Carregar / descarregar modelo
 * - Executar inferência em background
 * - Expor estado para a UI
 * - Gerenciar memória e interrupção
 *
 * NÃO mistura UI, rede ou áudio nesta classe.
 */
class LocalLlmEngine(private val context: Context) {

    enum class State {
        UNINITIALIZED,
        READY,          // backend ok, nenhum modelo carregado
        LOADING_MODEL,
        MODEL_LOADED,
        GENERATING,
        ERROR
    }

    data class GenerationParams(
        val temperature: Float = 0.7f,
        val maxTokens: Int = 512,
        val topP: Float = 0.9f,
        val contextSize: Int = 2048
    )

    private val _state = MutableStateFlow(State.UNINITIALIZED)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _currentModel = MutableStateFlow<ModelInfo?>(null)
    val currentModel: StateFlow<ModelInfo?> = _currentModel.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val modelsDir: File by lazy {
        File(context.filesDir, "models").also { it.mkdirs() }
    }

    private var params = GenerationParams()

    // ------------------------------------------------------------------
    // Inicialização
    // ------------------------------------------------------------------

    suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        if (_state.value != State.UNINITIALIZED && _state.value != State.ERROR) {
            return@withContext true
        }
        try {
            LlamaNative.ensureLoaded()
            val libDir = context.applicationInfo.nativeLibraryDir
            val ok = LlamaNative.initBackend(libDir)
            if (ok) {
                _state.value = State.READY
                _lastError.value = null
                Log.i(TAG, "Backend initialized")
            } else {
                _state.value = State.ERROR
                _lastError.value = "Falha ao inicializar backend llama.cpp"
            }
            ok
        } catch (e: Exception) {
            Log.e(TAG, "initialize failed", e)
            _state.value = State.ERROR
            _lastError.value = e.message ?: "Erro desconhecido"
            false
        }
    }

    // ------------------------------------------------------------------
    // Importação de GGUF
    // ------------------------------------------------------------------

    /**
     * Copia um arquivo GGUF para o diretório interno do app.
     * @param sourceFile arquivo já acessível (ex.: obtido via SAF)
     * @param displayName nome amigável (opcional)
     */
    suspend fun importGguf(sourceFile: File, displayName: String? = null): ModelInfo? =
        withContext(Dispatchers.IO) {
            if (!sourceFile.exists() || !sourceFile.canRead()) {
                _lastError.value = "Arquivo inacessível"
                return@withContext null
            }
            if (!sourceFile.name.lowercase().endsWith(".gguf")) {
                _lastError.value = "O arquivo precisa ter extensão .gguf"
                return@withContext null
            }

            // Validação mínima de cabeçalho GGUF (magic "GGUF")
            sourceFile.inputStream().use { input ->
                val magic = ByteArray(4)
                if (input.read(magic) != 4 || String(magic) != "GGUF") {
                    _lastError.value = "Arquivo não é um GGUF válido (magic incorreto)"
                    return@withContext null
                }
            }

            val id = UUID.randomUUID().toString().take(8)
            val safeName = (displayName ?: sourceFile.nameWithoutExtension)
                .replace(Regex("[^a-zA-Z0-9._-]"), "_")
                .take(64)
            val dest = File(modelsDir, "${safeName}_$id.gguf")

            try {
                sourceFile.copyTo(dest, overwrite = true)
            } catch (e: Exception) {
                _lastError.value = "Falha ao copiar modelo: ${e.message}"
                return@withContext null
            }

            val info = ModelInfo(
                id = id,
                displayName = displayName ?: sourceFile.name,
                filePath = dest.absolutePath,
                sizeBytes = dest.length()
            )
            Log.i(TAG, "Imported model: ${info.displayName} (${info.formattedSize()})")
            info
        }

    /**
     * Instala o modelo padrão Qwen3 0.6B Q8_0 automaticamente.
     * O arquivo é baixado para um .part privado, validado pelo cabeçalho GGUF
     * e promovido atomicamente. A operação respeita cancelamento de coroutine.
     */
    suspend fun downloadDefaultModel(
        onProgress: (downloaded: Long, total: Long) -> Unit = { _, _ -> }
    ): ModelInfo? = withContext(Dispatchers.IO) {
        val target = File(modelsDir, DEFAULT_MODEL_FILE)
        if (target.isFile && isValidGguf(target)) {
            return@withContext ModelInfo(
                id = target.nameWithoutExtension.takeLast(8),
                displayName = DEFAULT_MODEL_NAME,
                filePath = target.absolutePath,
                sizeBytes = target.length()
            )
        }

        val partial = File(modelsDir, "$DEFAULT_MODEL_FILE.part")
        var connection: HttpURLConnection? = null
        try {
            partial.delete()
            connection = (URL(DEFAULT_MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 90_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "DEV-AI-ASSISTANT-Android")
                connect()
            }
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Download Qwen: HTTP ${connection.responseCode}")
            }
            val total = connection.contentLengthLong
            val digest = MessageDigest.getInstance("SHA-256")
            connection.inputStream.use { input ->
                FileOutputStream(partial).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    var downloaded = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                        downloaded += count
                        onProgress(downloaded, total)
                    }
                    output.fd.sync()
                }
            }
            val actualSha256 = digest.digest().joinToString("") { "%02x".format(it) }
            if (actualSha256 != DEFAULT_MODEL_SHA256) {
                throw SecurityException("A verificação SHA-256 do modelo Qwen falhou; download descartado.")
            }
            if (!isValidGguf(partial) || partial.length() < MIN_DEFAULT_MODEL_BYTES) {
                throw IllegalStateException("O arquivo recebido não parece ser um GGUF Qwen válido.")
            }
            if (target.exists() && !target.delete()) {
                throw IllegalStateException("Não foi possível substituir o modelo anterior.")
            }
            if (!partial.renameTo(target)) {
                partial.copyTo(target, overwrite = true)
                partial.delete()
            }
            ModelInfo(
                id = target.nameWithoutExtension.takeLast(8),
                displayName = DEFAULT_MODEL_NAME,
                filePath = target.absolutePath,
                sizeBytes = target.length()
            ).also {
                _lastError.value = null
                Log.i(TAG, "Default Qwen installed: ${it.formattedSize()}")
            }
        } catch (cancelled: CancellationException) {
            partial.delete()
            throw cancelled
        } catch (e: Exception) {
            partial.delete()
            Log.e(TAG, "downloadDefaultModel failed", e)
            _lastError.value = e.message ?: "Falha ao baixar Qwen"
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun isValidGguf(file: File): Boolean {
        if (!file.isFile || file.length() < 4) return false
        return try {
            file.inputStream().use { input ->
                val magic = ByteArray(4)
                input.read(magic) == 4 && String(magic, Charsets.US_ASCII) == "GGUF"
            }
        } catch (_: Exception) { false }
    }

    /**
     * Lista modelos já importados no diretório interno.
     */
    fun listImportedModels(): List<ModelInfo> {
        return modelsDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".gguf", ignoreCase = true) }
            ?.map { file ->
                ModelInfo(
                    id = file.nameWithoutExtension.takeLast(8),
                    displayName = if (file.name.equals(DEFAULT_MODEL_FILE, ignoreCase = true)) {
                        DEFAULT_MODEL_NAME
                    } else {
                        file.nameWithoutExtension.dropLast(9).ifEmpty { file.name }
                    },
                    filePath = file.absolutePath,
                    sizeBytes = file.length()
                )
            }
            ?.sortedByDescending { it.importedAt }
            ?: emptyList()
    }

    /**
     * Remove um modelo do armazenamento interno.
     * Se for o modelo carregado, descarrega primeiro.
     */
    suspend fun removeModel(info: ModelInfo): Boolean = withContext(Dispatchers.IO) {
        if (_currentModel.value?.filePath == info.filePath) {
            unload()
        }
        val file = File(info.filePath)
        val deleted = file.exists() && file.delete()
        if (!deleted) {
            _lastError.value = "Não foi possível remover o arquivo"
        }
        deleted
    }

    // ------------------------------------------------------------------
    // Carregamento / descarregamento
    // ------------------------------------------------------------------

    suspend fun load(info: ModelInfo, contextSize: Int = params.contextSize): Boolean =
        withContext(Dispatchers.IO) {
            if (_currentModel.value?.filePath == info.filePath && LlamaNative.isModelLoaded()) {
                return@withContext true
            }
            if (!info.exists) {
                _lastError.value = "Arquivo do modelo não encontrado"
                _state.value = State.ERROR
                return@withContext false
            }

            _state.value = State.LOADING_MODEL
            _lastError.value = null

            // Descarrega modelo anterior se houver
            if (LlamaNative.isModelLoaded()) {
                LlamaNative.unloadModel()
            }

            val ok = LlamaNative.loadModel(
                modelPath = info.filePath,
                nCtx = contextSize.coerceIn(512, 8192),
                nGpuLayers = 0 // CPU only por estabilidade em mobile
            )

            if (ok) {
                _currentModel.value = info
                _state.value = State.MODEL_LOADED
                params = params.copy(contextSize = contextSize)
                Log.i(TAG, "Model loaded: ${info.displayName}")
            } else {
                _currentModel.value = null
                _state.value = State.ERROR
                _lastError.value = "Falha ao carregar o modelo (verifique RAM e formato GGUF)"
            }
            ok
        }

    suspend fun unload() = withContext(Dispatchers.IO) {
        LlamaNative.unloadModel()
        _currentModel.value = null
        if (_state.value != State.UNINITIALIZED && _state.value != State.ERROR) {
            _state.value = State.READY
        }
    }

    // ------------------------------------------------------------------
    // Inferência
    // ------------------------------------------------------------------

    /**
     * Gera resposta. Executa em Dispatchers.Default.
     * Pode ser interrompida com [stopGeneration].
     */
    suspend fun generate(
        prompt: String,
        temperature: Float = params.temperature,
        maxTokens: Int = params.maxTokens,
        topP: Float = params.topP
    ): String? = withContext(Dispatchers.Default) {
        if (!LlamaNative.isModelLoaded()) {
            _lastError.value = "Nenhum modelo carregado"
            return@withContext null
        }

        _state.value = State.GENERATING
        _lastError.value = null

        try {
            val result = LlamaNative.generate(
                prompt = prompt,
                temperature = temperature.coerceIn(0.0f, 2.0f),
                maxTokens = maxTokens.coerceIn(16, 2048),
                topP = topP.coerceIn(0.0f, 1.0f)
            )
            if (result == null) {
                _lastError.value = "Geração falhou"
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "generate error", e)
            _lastError.value = e.message
            null
        } finally {
            _state.value = if (LlamaNative.isModelLoaded()) State.MODEL_LOADED else State.READY
        }
    }

    fun stopGeneration() {
        LlamaNative.requestStop()
    }

    fun updateParams(newParams: GenerationParams) {
        params = newParams
    }

    fun getParams(): GenerationParams = params

    // ------------------------------------------------------------------
    // Liberação final
    // ------------------------------------------------------------------

    suspend fun release() = withContext(Dispatchers.IO) {
        LlamaNative.unloadModel()
        LlamaNative.freeBackend()
        _currentModel.value = null
        _state.value = State.UNINITIALIZED
    }

    companion object {
        private const val TAG = "LocalLlmEngine"
        const val DEFAULT_MODEL_NAME = "Qwen3 0.6B Q8_0"
        const val DEFAULT_MODEL_FILE = "Qwen3-0.6B-Q8_0.gguf"
        const val DEFAULT_MODEL_URL = "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/8e42d41f70cb6c571f58c3f31bd9287b372d97cc/Qwen3-0.6B-Q8_0.gguf"
        const val DEFAULT_MODEL_SHA256 = "12fae8b8f78f0360b498d04c8db7d33aff29ab7d8080231f93a17c18119e6735"
        private const val MIN_DEFAULT_MODEL_BYTES = 100L * 1024L * 1024L
    }
}
