package com.devai.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

/**
 * Wrapper do Text-to-Speech nativo do Android, priorizando português brasileiro.
 */
class TtsEngine(context: Context) : TextToSpeech.OnInitListener {

    enum class State { UNINITIALIZED, READY, SPEAKING, ERROR }

    private val _state = MutableStateFlow(State.UNINITIALIZED)
    val state: StateFlow<State> = _state.asStateFlow()

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var speechRate = 1.0f
    private var pitch = 1.0f
    private var enabled = true

    private var onDoneCallback: (() -> Unit)? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            Log.e(TAG, "TTS init failed")
            _state.value = State.ERROR
            return
        }

        val engine = tts ?: return
        // Preferência: pt-BR → pt → default
        val result = when {
            engine.isLanguageAvailable(Locale("pt", "BR")) >= TextToSpeech.LANG_AVAILABLE ->
                engine.setLanguage(Locale("pt", "BR"))
            engine.isLanguageAvailable(Locale("pt")) >= TextToSpeech.LANG_AVAILABLE ->
                engine.setLanguage(Locale("pt"))
            else ->
                engine.setLanguage(Locale.getDefault())
        }

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.w(TAG, "Portuguese not fully supported, using default")
        }

        engine.setSpeechRate(speechRate)
        engine.setPitch(pitch)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _state.value = State.SPEAKING
            }

            override fun onDone(utteranceId: String?) {
                _state.value = State.READY
                onDoneCallback?.invoke()
                onDoneCallback = null
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _state.value = State.READY
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _state.value = State.READY
            }
        })

        _state.value = State.READY
        Log.i(TAG, "TTS ready")
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!enabled || text.isBlank()) {
            onDone?.invoke()
            return
        }
        val engine = tts
        if (engine == null || _state.value == State.UNINITIALIZED || _state.value == State.ERROR) {
            onDone?.invoke()
            return
        }
        onDoneCallback = onDone
        val id = UUID.randomUUID().toString()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() {
        tts?.stop()
        _state.value = if (_state.value != State.ERROR) State.READY else State.ERROR
        onDoneCallback = null
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (!value) stop()
    }

    fun isEnabled(): Boolean = enabled

    fun setSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(speechRate)
    }

    fun setPitch(value: Float) {
        pitch = value.coerceIn(0.5f, 2.0f)
        tts?.setPitch(pitch)
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        _state.value = State.UNINITIALIZED
    }

    companion object {
        private const val TAG = "TtsEngine"
    }
}
