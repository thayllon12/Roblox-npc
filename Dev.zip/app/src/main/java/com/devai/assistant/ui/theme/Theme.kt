package com.devai.assistant.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DevAiDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = DeepBlack,
    primaryContainer = NavyMid,
    onPrimaryContainer = CyanBright,
    secondary = Cyan,
    onSecondary = DeepBlack,
    secondaryContainer = Navy,
    onSecondaryContainer = TextPrimary,
    tertiary = CyanBright,
    background = DeepBlack,
    onBackground = TextPrimary,
    surface = NavyDark,
    onSurface = TextPrimary,
    surfaceVariant = Navy,
    onSurfaceVariant = TextSecondary,
    error = ErrorRed,
    onError = Color.White,
    outline = GlassBorder,
    outlineVariant = GlassMedium
)

@Composable
fun DevAiTheme(
    darkTheme: Boolean = true, // Always dark / futuristic
    content: @Composable () -> Unit
) {
    val colorScheme = DevAiDarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DeepBlack.toArgb()
            window.navigationBarColor = DeepBlack.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DevAiTypography,
        content = content
    )
}
