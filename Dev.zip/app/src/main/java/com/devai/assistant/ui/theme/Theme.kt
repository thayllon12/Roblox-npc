package com.devai.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Cyan,
    onPrimary = DeepBlack,
    background = DeepBlack,
    onBackground = TextPrimary,
    surface = NavyDark,
    onSurface = TextPrimary,
    surfaceVariant = NavyMid,
    onSurfaceVariant = TextSecondary,
    outline = TextMuted,
    outlineVariant = GlassBorder,
    error = ErrorRed
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0A7EA4),
    onPrimary = Color.White,
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111827),
    surface = Color(0xFFF7F8FA),
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFF0F2F5),
    onSurfaceVariant = Color(0xFF5B6675),
    outline = Color(0xFF9AA3AF),
    outlineVariant = Color(0xFFD5DAE1),
    error = Color(0xFFD93A4F)
)

/** Tema claro ou escuro. Por padrão segue o tema do sistema. */
@Composable
fun DevAiTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}
