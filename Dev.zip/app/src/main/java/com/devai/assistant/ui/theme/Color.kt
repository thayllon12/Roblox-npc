package com.devai.assistant.ui.theme

import androidx.compose.ui.graphics.Color

// Core palette - Deep Black / Navy / Electric Blue / Cyan
val DeepBlack = Color(0xFF05050A)
val NavyDark = Color(0xFF0A1220)
val Navy = Color(0xFF0F1C2E)
val NavyMid = Color(0xFF15253A)
val ElectricBlue = Color(0xFF00B4FF)
val ElectricBlueDim = Color(0xFF0088CC)
val Cyan = Color(0xFF00E5FF)
val CyanBright = Color(0xFF40F0FF)

val GlassLight = Color(0x22FFFFFF)
val GlassMedium = Color(0x33FFFFFF)
val GlassBorder = Color(0x44A0D8FF)

val TextPrimary = Color(0xFFE8F4FF)
val TextSecondary = Color(0xFF8BA3B8)
val TextMuted = Color(0xFF5A6F82)

val ErrorRed = Color(0xFFFF4D6A)
val SuccessGreen = Color(0xFF00E676)
val OrbGlow = Color(0x6600B4FF)

// Gradients base colors
val GradientStart = Color(0xFF00B4FF)
val GradientMid = Color(0xFF0077FF)
val GradientEnd = Color(0xFF00E5FF)
