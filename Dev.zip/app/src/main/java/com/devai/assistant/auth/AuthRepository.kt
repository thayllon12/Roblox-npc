package com.devai.assistant.auth

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await

/** Login com Google (Credential Manager) autenticado no Firebase Auth. */
class AuthRepository {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    suspend fun signInWithGoogle(activity: Activity): FirebaseUser {
        val webClientId = resolveWebClientId(activity)

        val googleOption = GetGoogleIdOption.Builder()
            .setServerClientId(webClientId)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()

        val result = CredentialManager.create(activity).getCredential(activity, request)
        val credential = result.credential

        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            throw IllegalStateException("Tipo de credencial Google não suportado.")
        }

        val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)

        return auth.signInWithCredential(firebaseCredential).await().user
            ?: throw IllegalStateException("O Firebase não retornou o usuário autenticado.")
    }

    fun signOut() {
        auth.signOut()
    }

    private fun resolveWebClientId(activity: Activity): String {
        // Gerado pelo plugin google-services somente se o provedor Google estiver ativo no Firebase.
        val resId = activity.resources.getIdentifier(
            "default_web_client_id", "string", activity.packageName
        )
        if (resId == 0) {
            throw IllegalStateException(
                "Login Google não configurado: ative o provedor Google no Firebase " +
                    "e substitua o app/google-services.json pelo arquivo novo."
            )
        }
        return activity.getString(resId)
    }
}
