package com.devai.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.graphics.BitmapFactory
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.core.app.NotificationCompat
import com.devai.assistant.MainActivity
import com.devai.assistant.R
import com.devai.assistant.DevAiApplication
import com.devai.assistant.localmodel.LocalLlmEngine
import com.devai.assistant.voice.VoiceAssistantController
import com.devai.assistant.overlay.OverlayService
import com.devai.assistant.storage.SettingsRepository
import kotlinx.coroutines.flow.first

/**
 * Foreground Service para manter o assistente de voz ativo em segundo plano.
 * Tipo: microphone (Android 14+ exige foregroundServiceType).
 */
class AssistantForegroundService : Service() {

    private var voiceController: VoiceAssistantController? = null
    private var llmEngine: LocalLlmEngine? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        Log.i(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val notification = buildNotification("Aguardando \"Hey Dev AI\"")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                startVoiceLoop()
            }
        }
        return START_STICKY
    }

    private fun startVoiceLoop() {
        if (voiceController != null) return
        val engine = (application as DevAiApplication).llmEngine
        llmEngine = engine
        serviceScope.launch {
            val backendReady = engine.initialize()
            if (!backendReady) {
                Log.e(TAG, "Backend local indisponível: ${engine.lastError.value}")
                updateStatus("Motor de IA indisponível")
                stopSelf()
                return@launch
            }
            val qwenFile = java.io.File(filesDir, "models/${LocalLlmEngine.DEFAULT_MODEL_FILE}")
            val model = if (qwenFile.isFile) {
                com.devai.assistant.localmodel.ModelInfo(
                    id = qwenFile.nameWithoutExtension.takeLast(8),
                    displayName = LocalLlmEngine.DEFAULT_MODEL_NAME,
                    filePath = qwenFile.absolutePath,
                    sizeBytes = qwenFile.length()
                )
            } else {
                updateStatus("Baixando modelo Qwen")
                engine.downloadDefaultModel { downloaded, total ->
                    val mb = downloaded / (1024 * 1024)
                    val totalMb = if (total > 0) total / (1024 * 1024) else 0
                    updateStatus(if (totalMb > 0) "Baixando Qwen: $mb/$totalMb MB" else "Baixando Qwen: $mb MB")
                }
            }
            if (model == null || !engine.load(model)) {
                Log.e(TAG, "Não foi possível carregar Qwen: ${engine.lastError.value}")
                updateStatus("Modelo local indisponível")
                stopSelf()
                return@launch
            }
            val controller = VoiceAssistantController(applicationContext, engine)
            voiceController = controller
            if (!controller.recognizer.isModelInstalled()) {
                updateStatus("Baixando reconhecimento PT-BR")
                val installed = controller.recognizer.downloadAndInstallModel()
                if (!installed) {
                    Log.e(TAG, "Vosk indisponível: ${controller.recognizer.lastError.value}")
                    updateStatus("Reconhecimento de voz indisponível")
                    stopSelf()
                    return@launch
                }
            } else {
                controller.recognizer.loadModel()
            }
            val preferences = SettingsRepository(applicationContext)
            val overlayEnabled = preferences.overlayEnabled.first()
            if (overlayEnabled && Settings.canDrawOverlays(applicationContext)) {
                controller.onWakeDetected = { OverlayService.showAssistant(applicationContext) }
            }
            val ttsEnabled = preferences.ttsEnabled.first()
            val wakeEnabled = preferences.wakeWordEnabled.first()
            val ttsRate = preferences.ttsRate.first()
            controller.setTtsEnabled(ttsEnabled)
            controller.setTtsRate(ttsRate)
            controller.setWakeWordEnabled(wakeEnabled)
            updateStatus(if (wakeEnabled) "Assistente de voz ativo" else "Serviço ativo; palavra de ativação desligada")
            if (wakeEnabled) withContext(Dispatchers.Main) { controller.startWakeWordListening() }
            Log.i(TAG, "Voice loop started; wakeWord=$wakeEnabled")
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "DEV AI Assistente",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Serviço de escuta contínua do assistente"
            setShowBadge(false)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(status: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DEV AI ASSISTANT")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.devex_logo))
            .setContentIntent(openIntent)
            .addAction(0, "Parar", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    fun updateStatus(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        voiceController?.release()
        voiceController = null
        // O motor é compartilhado com a tela principal; não liberar llama.cpp
        // ao encerrar somente o serviço de microfone.
        llmEngine = null
        serviceScope.cancel()
        Log.i(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "AssistantFgService"
        private const val CHANNEL_ID = "dev_ai_assistant_channel"
        private const val NOTIFICATION_ID = 4201
        const val ACTION_STOP = "com.devai.assistant.STOP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, AssistantForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, AssistantForegroundService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
