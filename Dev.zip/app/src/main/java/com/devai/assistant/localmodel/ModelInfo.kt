package com.devai.assistant.localmodel

import java.io.File

/**
 * Metadados de um modelo GGUF importado pelo usuário.
 */
data class ModelInfo(
    val id: String,
    val displayName: String,
    val filePath: String,
    val sizeBytes: Long,
    val importedAt: Long = System.currentTimeMillis()
) {
    val sizeMb: Double get() = sizeBytes / (1024.0 * 1024.0)

    val exists: Boolean get() = File(filePath).exists()

    fun formattedSize(): String {
        return when {
            sizeBytes >= 1_000_000_000 -> "%.1f GB".format(sizeBytes / 1e9)
            sizeBytes >= 1_000_000 -> "%.0f MB".format(sizeBytes / 1e6)
            else -> "%.0f KB".format(sizeBytes / 1e3)
        }
    }
}
