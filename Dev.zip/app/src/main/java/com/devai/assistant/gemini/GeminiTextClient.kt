package com.devai.assistant.gemini

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Cliente de texto Gemini via generateContent. O Live WebSocket fica reservado
 * para sessões de áudio bidirecionais; não deve ser usado para um turno simples de texto. */
class GeminiTextClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generate(apiKey: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Configure a API Key do Gemini." }
        val modelId = model.trim().removePrefix("models/")
        require(modelId.matches(Regex("[A-Za-z0-9._-]{3,100}"))) { "ID de modelo Gemini inválido." }

        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 512)
            })
        }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent")
            .header("x-goog-api-key", apiKey.trim())
            .header("Content-Type", "application/json")
            .post(body)
            .build()

        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching {
                    JSONObject(raw).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                throw IOException("Gemini HTTP ${response.code}: ${detail.ifBlank { response.message.ifBlank { "falha na solicitação" } }}")
            }
            val json = JSONObject(raw)
            val candidates = json.optJSONArray("candidates")
                ?: throw IOException("Gemini não retornou candidatos. Verifique o modelo e a chave.")
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IOException("Resposta Gemini sem conteúdo de texto.")
            val answer = buildString {
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i)
                    if (part != null) append(part.optString("text", ""))
                }
            }.trim()
            if (answer.isBlank()) throw IOException("Gemini retornou uma resposta vazia.")
            answer
        }
    }
}
