package com.devai.assistant.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.devai.assistant.MainActivity
import com.devai.assistant.ui.theme.ElectricBlue
import com.devai.assistant.ui.theme.Cyan
import kotlin.math.abs

/**
 * Orb flutuante sobre outros aplicativos (SYSTEM_ALERT_WINDOW).
 * Arrastável + toque abre o assistente.
 */
class OverlayService : Service() {

    private var expanded = mutableStateOf(false)
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_WAKE) expanded.value = true
        return START_STICKY
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = 18
            y = 90
        }

        val composeView = ComposeView(this).apply {
            setContent {
                FloatingOrb(
                    expanded = expanded.value,
                    onClick = {
                        val intent = Intent(this@OverlayService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(intent)
                    },
                    onCollapse = { expanded.value = false }
                )
            }
        }

        // Lifecycle owners mínimos para Compose em Service
        val lifecycleOwner = OverlayLifecycleOwner()
        composeView.setViewTreeLifecycleOwner(lifecycleOwner)
        composeView.setViewTreeViewModelStoreOwner(lifecycleOwner)
        composeView.setViewTreeSavedStateRegistryOwner(lifecycleOwner)

        overlayView = FrameLayout(this).apply {
            addView(composeView)
            setOnTouchListener { _, event ->
                if (expanded.value) false else handleTouch(event)
            }
        }

        try {
            windowManager?.addView(overlayView, params)
            Log.i(TAG, "Overlay shown")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add overlay: ${e.message}")
            stopSelf()
        }
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        val p = params ?: return false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = p.x
                initialY = p.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - initialTouchX).toInt()
                val dy = (event.rawY - initialTouchY).toInt()
                if (abs(dx) > 8 || abs(dy) > 8) moved = true
                p.x = initialX + dx
                p.y = initialY + dy
                windowManager?.updateViewLayout(overlayView, p)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    overlayView?.performClick()
                }
                return true
            }
        }
        return false
    }

    override fun onDestroy() {
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
        Log.i(TAG, "Overlay removed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "OverlayService"

        private const val ACTION_WAKE = "com.devai.assistant.overlay.SHOW_ASSISTANT"

        fun start(context: Context) {
            context.startService(Intent(context, OverlayService::class.java))
        }

        fun showAssistant(context: Context) {
            context.startService(Intent(context, OverlayService::class.java).setAction(ACTION_WAKE))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}

@Composable
private fun FloatingOrb(expanded: Boolean, onClick: () -> Unit, onCollapse: () -> Unit) {
    if (expanded) {
        Surface(
            modifier = Modifier.width(292.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xF01B1D22),
            shadowElevation = 18.dp
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Cyan, ElectricBlue, Color(0xFF10213D)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("D", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("DEV AI", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Ouvindo você…", color = Cyan, fontSize = 12.sp)
                    }
                    TextButton(onClick = onCollapse) { Text("Fechar", color = Color.LightGray) }
                }
                Spacer(Modifier.height(10.dp))
                Text("Sua palavra de ativação foi reconhecida.", color = Color.White, fontSize = 14.sp)
                TextButton(onClick = onClick) { Text("Abrir conversa", color = Cyan) }
            }
        }
    } else {
        Box(
            modifier = Modifier.size(64.dp).clip(CircleShape)
                .background(Brush.radialGradient(colors = listOf(Cyan.copy(alpha = 0.9f), ElectricBlue, Color(0xFF0A1628))))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text("D", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        }
    }
}
