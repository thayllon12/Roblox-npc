package com.devai.assistant.auth

import android.app.Activity
import android.app.Application
import android.util.Log
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.devai.assistant.storage.CloudRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException

sealed interface AuthState {
    data object SignedOut : AuthState
    data object Loading : AuthState
    data class SignedIn(val uid: String, val name: String?) : AuthState
    data class Error(val message: String) : AuthState
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AuthRepository()
    private val cloud = CloudRepository()

    private val _state = MutableStateFlow<AuthState>(
        repo.currentUser?.let { AuthState.SignedIn(it.uid, it.displayName) } ?: AuthState.SignedOut
    )
    val state: StateFlow<AuthState> = _state.asStateFlow()

    fun signIn(activity: Activity) {
        if (_state.value == AuthState.Loading) return
        viewModelScope.launch {
            _state.value = AuthState.Loading
            try {
                val user = repo.signInWithGoogle(activity)
                _state.value = AuthState.SignedIn(user.uid, user.displayName)
                try {
                    cloud.saveUserProfile(user)
                } catch (e: Exception) {
                    Log.w(TAG, "Login ok, mas falhou ao salvar perfil no Firestore", e)
                }
            } catch (e: GetCredentialCancellationException) {
                _state.value = AuthState.Error("Login cancelado.")
            } catch (e: NoCredentialException) {
                _state.value = AuthState.Error(
                    "O Google não liberou o login deste app. Confira o SHA-1 do certificado de debug no Firebase e baixe o google-services.json novo."
                )
            } catch (e: Exception) {
                Log.e(TAG, "Falha no login Google", e)
                _state.value = AuthState.Error(friendlyMessage(e))
            }
        }
    }

    private fun friendlyMessage(e: Exception): String = when (e) {
        is IOException -> "Sem conexão com a internet. Verifique sua rede e tente novamente."
        is IllegalStateException -> e.message ?: "Não foi possível entrar."
        else -> "Não foi possível entrar. Tente novamente."
    }

    companion object {
        private const val TAG = "AuthViewModel"
    }
}
