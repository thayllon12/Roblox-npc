package com.devai.assistant.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.devai.assistant.ui.theme.Cyan
import com.devai.assistant.ui.theme.DeepBlack
import com.devai.assistant.ui.theme.ErrorRed

@Composable
fun LoginScreen(state: AuthState, onGoogleSignIn: () -> Unit) {
    val loading = state is AuthState.Loading
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "DEV AI",
                style = MaterialTheme.typography.headlineMedium,
                color = Cyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Entre com sua conta Google para continuar",
                style = MaterialTheme.typography.bodyLarge,
                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onGoogleSignIn,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Cyan,
                    contentColor = DeepBlack
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = DeepBlack
                    )
                } else {
                    Text("Continuar com Google", fontWeight = FontWeight.SemiBold)
                }
            }
            if (state is AuthState.Error) {
                Text(
                    text = state.message,
                    color = ErrorRed,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
