package com.devai.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.devai.assistant.storage.SettingsRepository
import com.devai.assistant.gemini.GeminiTextClient
import android.widget.Toast
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import com.devai.assistant.ui.screens.MainScreen
import com.devai.assistant.ui.screens.MainViewModel
import com.devai.assistant.ui.screens.SettingsScreen
import com.devai.assistant.ui.theme.DevAiTheme

class MainActivity : ComponentActivity() {

    private lateinit var settings: SettingsRepository

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results handled by UI state if needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        settings = SettingsRepository(applicationContext)
        requestNeededPermissions()

        setContent {
            DevAiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = androidx.compose.ui.graphics.Color.Transparent
                ) {
                    val assistantViewModel: MainViewModel = viewModel()
                    val modelStatus by assistantViewModel.statusMessage.collectAsState()
                    val modelBusy by assistantViewModel.isBusy.collectAsState()
                    var showSettings by remember { mutableStateOf(false) }
                    if (showSettings) {
                        SettingsScreen(
                            settings = settings,
                            onBack = { showSettings = false },
                            onTestGemini = { apiKey -> testGeminiConnection(apiKey) },
                            onTtsEnabled = { assistantViewModel.setTtsEnabled(it) },
                            onWakeWordEnabled = { assistantViewModel.setWakeWordEnabled(it) },
                            onTtsRateChange = { assistantViewModel.setTtsRate(it) },
                            onImportModel = { assistantViewModel.importFromUri(it) },
                            onDownloadModel = { assistantViewModel.downloadModelFromUrl(it) },
                            modelStatus = modelStatus,
                            modelBusy = modelBusy
                        )
                    } else {
                        MainScreen(
                            onOpenSettings = { showSettings = true },
                            viewModel = assistantViewModel
                        )
                    }
                }
            }
        }
    }


    private fun testGeminiConnection(apiKey: String) {
        lifecycleScope.launch {
            try {
                val model = settings.geminiModel.first()
                val response = GeminiTextClient().generate(
                    apiKey,
                    model,
                    "Responda somente: conexão Gemini funcionando."
                )
                Toast.makeText(
                    this@MainActivity,
                    "Gemini conectado: ${response.take(100)}",
                    Toast.LENGTH_LONG
                ).show()
            } catch (error: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "Falha Gemini: ${error.message ?: "erro desconhecido"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }
}
