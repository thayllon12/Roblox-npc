package com.devai.assistant.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dev_ai_settings")

/**
 * Persistência de preferências + API Key protegida (Android Keystore via EncryptedSharedPreferences).
 */
class SettingsRepository(private val context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "dev_ai_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // ---------- DataStore keys ----------
    private object Keys {
        val PROVIDER = stringPreferencesKey("ai_provider")           // "qwen" | "gemini"
        val FALLBACK_ENABLED = booleanPreferencesKey("fallback_to_qwen")
        val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val WAKE_THRESHOLD = floatPreferencesKey("wake_threshold")
        val TEMPERATURE = floatPreferencesKey("llm_temperature")
        val MAX_TOKENS = stringPreferencesKey("llm_max_tokens")
        val CONTEXT_SIZE = stringPreferencesKey("llm_context_size")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val SERVICE_ENABLED = booleanPreferencesKey("service_enabled")
        val SELECTED_GGUF = stringPreferencesKey("selected_gguf_path")
    }

    // ---------- Flows ----------
    val provider: Flow<String> = context.dataStore.data.map { it[Keys.PROVIDER] ?: "qwen" }
    val fallbackEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.FALLBACK_ENABLED] ?: true }
    val ttsEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.TTS_ENABLED] ?: true }
    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.WAKE_WORD_ENABLED] ?: true }
    val ttsRate: Flow<Float> = context.dataStore.data.map { it[Keys.TTS_RATE] ?: 1.0f }
    val wakeThreshold: Flow<Float> = context.dataStore.data.map { it[Keys.WAKE_THRESHOLD] ?: 0.55f }
    val temperature: Flow<Float> = context.dataStore.data.map { it[Keys.TEMPERATURE] ?: 0.7f }
    val maxTokens: Flow<Int> = context.dataStore.data.map { (it[Keys.MAX_TOKENS] ?: "512").toIntOrNull() ?: 512 }
    val contextSize: Flow<Int> = context.dataStore.data.map { (it[Keys.CONTEXT_SIZE] ?: "2048").toIntOrNull() ?: 2048 }
    val geminiModel: Flow<String> = context.dataStore.data.map { it[Keys.GEMINI_MODEL] ?: "gemini-3.8-live" }
    val overlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.OVERLAY_ENABLED] ?: false }
    val serviceEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.SERVICE_ENABLED] ?: false }
    val selectedGgufPath: Flow<String?> = context.dataStore.data.map { it[Keys.SELECTED_GGUF] }

    // ---------- API Key (encrypted) ----------
    fun getApiKey(): String? = encryptedPrefs.getString("gemini_api_key", null)

    fun saveApiKey(key: String) {
        encryptedPrefs.edit().putString("gemini_api_key", key.trim()).apply()
    }

    fun clearApiKey() {
        encryptedPrefs.edit().remove("gemini_api_key").apply()
    }

    fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()

    // ---------- Writers ----------
    suspend fun setProvider(value: String) {
        context.dataStore.edit { it[Keys.PROVIDER] = value }
    }

    suspend fun setFallbackEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.FALLBACK_ENABLED] = value }
    }

    suspend fun setTtsEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.TTS_ENABLED] = value }
    }

    suspend fun setWakeWordEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.WAKE_WORD_ENABLED] = value }
    }

    suspend fun setTtsRate(value: Float) {
        context.dataStore.edit { it[Keys.TTS_RATE] = value.coerceIn(0.5f, 2.0f) }
    }

    suspend fun setWakeThreshold(value: Float) {
        context.dataStore.edit { it[Keys.WAKE_THRESHOLD] = value.coerceIn(0.2f, 0.9f) }
    }

    suspend fun setTemperature(value: Float) {
        context.dataStore.edit { it[Keys.TEMPERATURE] = value.coerceIn(0.1f, 1.5f) }
    }

    suspend fun setMaxTokens(value: Int) {
        context.dataStore.edit { it[Keys.MAX_TOKENS] = value.coerceIn(64, 4096).toString() }
    }

    suspend fun setContextSize(value: Int) {
        context.dataStore.edit { it[Keys.CONTEXT_SIZE] = value.coerceIn(512, 8192).toString() }
    }

    suspend fun setGeminiModel(value: String) {
        context.dataStore.edit { it[Keys.GEMINI_MODEL] = value }
    }

    suspend fun setOverlayEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.OVERLAY_ENABLED] = value }
    }

    suspend fun setServiceEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.SERVICE_ENABLED] = value }
    }

    suspend fun setSelectedGgufPath(path: String?) {
        context.dataStore.edit {
            if (path == null) it.remove(Keys.SELECTED_GGUF)
            else it[Keys.SELECTED_GGUF] = path
        }
    }
}
