package com.devai.assistant.gemini

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Cliente Gemini Live (áudio/texto em tempo real) via WebSocket.
 *
 * Modelo padrão atual (2026): gemini-3.8-live
 * Documentação: https://ai.google.dev/gemini-api/docs/live
 *
 * Nota: A API Live oficial usa autenticação por API Key no query param
 * ou header. Áudio de entrada = PCM 16-bit little-endian 16 kHz.
 * Áudio de saída = PCM 24 kHz.
 *
 * Esta implementação cobre:
 * - Conexão / reconexão
 * - Setup de sessão
 * - Envio de texto e de áudio PCM
 * - Recebimento de texto + áudio
 * - Encerramento limpo
 * - Tratamento de erros de autenticação e rede
 */
class GeminiLiveClient {

    enum class ConnectionState {
        DISCONNECTED,
        CONNECTING,
        CONNECTED,
        SESSION_ACTIVE,
        ERROR
    }

    data class LiveMessage(
        val text: String? = null,
        val audioPcm24k: ByteArray? = null,
        val isFinal: Boolean = false,
        val turnComplete: Boolean = false
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var webSocket: WebSocket? = null
    private var reconnectJob: Job? = null

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _messages = MutableStateFlow<LiveMessage?>(null)
    val messages: StateFlow<LiveMessage?> = _messages.asStateFlow()

    private var apiKey: String? = null
    private var modelName: String = "gemini-3.8-live"
    private val intentionalClose = AtomicBoolean(false)

    var onAudioChunk: ((ByteArray) -> Unit)? = null
    var onText: ((String, Boolean) -> Unit)? = null
    var onTurnComplete: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    fun configure(apiKey: String, model: String = "gemini-3.8-live") {
        this.apiKey = apiKey.trim()
        this.modelName = model
    }

    fun connect() {
        val key = apiKey
        if (key.isNullOrBlank()) {
            _lastError.value = "API Key não configurada"
            _state.value = ConnectionState.ERROR
            onError?.invoke(_lastError.value!!)
            return
        }

        intentionalClose.set(false)
        _state.value = ConnectionState.CONNECTING
        _lastError.value = null

        // Endpoint oficial Gemini Live (Developer API)
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"

        val request = Request.Builder()
            .url(url)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket aberto")
                _state.value = ConnectionState.CONNECTED
                sendSetup()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // Alguns frames podem vir binários; tratamos como texto se possível
                handleServerMessage(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(TAG, "Closing: $code $reason")
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(TAG, "Closed: $code $reason")
                _state.value = ConnectionState.DISCONNECTED
                if (!intentionalClose.get()) {
                    scheduleReconnect()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val msg = t.message ?: "Falha de conexão"
                Log.e(TAG, "Failure: $msg", t)
                _lastError.value = msg
                _state.value = ConnectionState.ERROR
                onError?.invoke(msg)
                if (!intentionalClose.get()) {
                    scheduleReconnect()
                }
            }
        })
    }

    private fun sendSetup() {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", "models/$modelName")
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO").put("TEXT"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", "Puck")
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text",
                        "Você é o DEV AI ASSISTANT, um assistente pessoal de voz prestativo, " +
                        "conciso e natural em português brasileiro. Responda de forma clara e útil."
                    )))
                })
            })
        }
        webSocket?.send(setup.toString())
        Log.i(TAG, "Setup enviado ($modelName); aguardando confirmação do servidor")
    }

    /** Conecta, aguarda setupComplete, envia um turno de texto e aguarda a resposta final. */
    suspend fun generateTextOnce(apiKey: String, model: String, prompt: String): String =
        withContext(Dispatchers.IO) {
            val answer = StringBuilder()
            val completed = CompletableDeferred<String>()
            configure(apiKey, model)
            onText = { text, _ -> synchronized(answer) { answer.append(text) } }
            onTurnComplete = {
                if (!completed.isCompleted) {
                    val text = synchronized(answer) { answer.toString() }
                    completed.complete(text)
                }
            }
            onError = { message ->
                if (!completed.isCompleted) completed.completeExceptionally(IllegalStateException(message))
            }
            try {
                connect()
                val stateNow = withTimeout(30_000) {
                    state.first { it == ConnectionState.SESSION_ACTIVE || it == ConnectionState.ERROR }
                }
                if (stateNow != ConnectionState.SESSION_ACTIVE) {
                    throw IllegalStateException(lastError.value ?: "Gemini não confirmou a sessão")
                }
                sendText(prompt)
                withTimeout(60_000) { completed.await() }
            } finally {
                disconnect()
            }
        }

    fun sendText(text: String) {
        if (_state.value != ConnectionState.SESSION_ACTIVE) return
        val msg = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }))
                put("turnComplete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    /**
     * Envia chunk de áudio PCM 16-bit LE 16 kHz.
     */
    fun sendAudioPcm16k(pcm: ByteArray) {
        if (_state.value != ConnectionState.SESSION_ACTIVE) return
        val b64 = android.util.Base64.encodeToString(pcm, android.util.Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(msg.toString())
    }

    fun endUserTurn() {
        if (_state.value != ConnectionState.SESSION_ACTIVE) return
        val msg = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turnComplete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    private fun handleServerMessage(raw: String) {
        try {
            val json = JSONObject(raw)

            if (json.has("setupComplete")) {
                Log.i(TAG, "Setup complete")
                _state.value = ConnectionState.SESSION_ACTIVE
                _lastError.value = null
                return
            }

            if (json.has("serverContent")) {
                val sc = json.getJSONObject("serverContent")
                val modelTurn = sc.optJSONObject("modelTurn")
                var textAcc = ""
                var audio: ByteArray? = null

                if (modelTurn != null) {
                    val parts = modelTurn.optJSONArray("parts") ?: JSONArray()
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) {
                            textAcc += part.getString("text")
                        }
                        if (part.has("inlineData")) {
                            val data = part.getJSONObject("inlineData")
                            val mime = data.optString("mimeType", "")
                            if (mime.startsWith("audio/")) {
                                val b64 = data.getString("data")
                                audio = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                            }
                        }
                    }
                }

                val turnComplete = sc.optBoolean("turnComplete", false)
                val interrupted = sc.optBoolean("interrupted", false)

                if (textAcc.isNotEmpty()) {
                    onText?.invoke(textAcc, turnComplete)
                }
                if (audio != null) {
                    onAudioChunk?.invoke(audio)
                }
                if (turnComplete) {
                    onTurnComplete?.invoke()
                }

                _messages.value = LiveMessage(
                    text = textAcc.ifEmpty { null },
                    audioPcm24k = audio,
                    isFinal = turnComplete,
                    turnComplete = turnComplete
                )
            }

            if (json.has("error")) {
                val err = json.getJSONObject("error")
                val message = err.optString("message", "Erro desconhecido do Gemini")
                _lastError.value = message
                _state.value = ConnectionState.ERROR
                onError?.invoke(message)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Parse error: ${e.message}")
        }
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            kotlinx.coroutines.delay(3000)
            if (isActive && !intentionalClose.get() && _state.value != ConnectionState.CONNECTED) {
                Log.i(TAG, "Tentando reconectar…")
                connect()
            }
        }
    }

    fun disconnect() {
        intentionalClose.set(true)
        reconnectJob?.cancel()
        webSocket?.close(1000, "Client closed")
        webSocket = null
        _state.value = ConnectionState.DISCONNECTED
    }

    fun release() {
        disconnect()
        scope.cancel()
    }

    companion object {
        private const val TAG = "GeminiLiveClient"
    }
}
