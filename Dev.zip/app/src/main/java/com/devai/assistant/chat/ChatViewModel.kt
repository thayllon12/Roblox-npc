package com.devai.assistant.chat

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.devai.assistant.gemini.ChatTurn
import com.devai.assistant.gemini.GeminiTextClient
import com.devai.assistant.storage.SettingsRepository
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsRepository(application)
    private val gemini = GeminiTextClient()
    private var repo: ChatRepository? = null
    private var conversationsListener: ListenerRegistration? = null
    private var messagesListener: ListenerRegistration? = null
    private var sendJob: Job? = null

    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _messages = MutableStateFlow<List<StoredMessage>>(emptyList())
    val messages: StateFlow<List<StoredMessage>> = _messages.asStateFlow()

    private val _currentId = MutableStateFlow<String?>(null)
    val currentId: StateFlow<String?> = _currentId.asStateFlow()

    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun start(uid: String) {
        if (repo != null) return
        val r = ChatRepository(uid)
        repo = r
        conversationsListener = r.observeConversations { _conversations.value = it }
    }

    fun openConversation(id: String?) {
        if (_currentId.value == id) return
        _currentId.value = id
        messagesListener?.remove()
        messagesListener = null
        _messages.value = emptyList()
        val r = repo ?: return
        if (id != null) {
            messagesListener = r.observeMessages(id) { _messages.value = it }
        }
    }

    fun newChat() = openConversation(null)

    fun send(text: String) {
        val r = repo ?: return
        if (_sending.value || text.isBlank()) return
        val apiKey = settings.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _error.value = "Configure sua chave da API Gemini no botão de configurações."
            return
        }
        sendJob = viewModelScope.launch {
            _sending.value = true
            try {
                val model = settings.geminiModel.first()
                // Histórico montado antes de gravar, para não duplicar a mensagem atual.
                val history = _messages.value.map {
                    ChatTurn(if (it.role == "model") "model" else "user", it.text)
                } + ChatTurn("user", text)

                val convId = _currentId.value
                    ?: r.createConversation(text.take(40)).also { openConversation(it) }
                r.addMessage(convId, "user", text)

                val answer = gemini.generate(apiKey, model, history)
                r.addMessage(convId, "model", answer)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Falha ao enviar mensagem", e)
                _error.value = e.message ?: "Não foi possível obter a resposta."
            } finally {
                _sending.value = false
            }
        }
    }

    fun stop() {
        sendJob?.cancel()
        _sending.value = false
    }

    fun rename(id: String, title: String) = runOp {
        repo?.rename(id, title.ifBlank { "Nova conversa" })
    }

    fun delete(id: String) = runOp {
        repo?.delete(id)
        if (_currentId.value == id) openConversation(null)
    }

    fun saveApiKey(key: String) {
        settings.saveApiKey(key)
    }

    fun clearError() {
        _error.value = null
    }

    private fun runOp(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                Log.e(TAG, "Falha na operação de conversa", e)
                _error.value = e.message ?: "Operação não concluída."
            }
        }
    }

    override fun onCleared() {
        conversationsListener?.remove()
        messagesListener?.remove()
        super.onCleared()
    }

    companion object {
        private const val TAG = "ChatViewModel"
    }
}
