# Add project specific ProGuard rules here.
# Phase A - minimal rules. Will be expanded in later phases.
