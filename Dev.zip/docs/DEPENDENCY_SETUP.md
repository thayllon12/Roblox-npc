# Instalação automática de dependências

## Compilação

O workflow `.github/workflows/android-build.yml` prepara o ambiente do zero:

- JDK 17;
- Android SDK Platform 35 e Build Tools 35.0.0;
- Android NDK 26.1.10909125;
- CMake 3.22.1;
- Gradle 8.9;
- `llama.cpp` e seus submódulos Git;
- dependências Maven/Gradle declaradas em `app/build.gradle.kts` (Compose, AndroidX, OkHttp, coroutines, Vosk, JNA e ONNX Runtime).

O Gradle baixa os artefatos Maven automaticamente durante `:app:dependencies` e `assembleDebug`.

## Compilação local (Linux/macOS)

Com JDK 17 e Android SDK Command-line Tools instalados e licenciados, execute:

```bash
./scripts/build-android.sh
```

O script instala as plataformas/NDK/CMake requeridas com `sdkmanager`, baixa Gradle 8.9 se não existir no PATH, baixa `llama.cpp` com os submódulos e compila o APK Debug.

## Downloads no primeiro uso do aplicativo

- Qwen3 0.6B Q8_0: baixado de Hugging Face para `filesDir/models/`, validado por SHA-256 e pelo magic GGUF e instalado em arquivo privado. O download é feito apenas se o arquivo padrão não existir/for inválido.
- Vosk PT-BR small 0.3: baixado do servidor oficial Vosk, extraído em armazenamento privado e validado pelos arquivos `am/final.mdl` e `conf/model.conf`.

Os downloads dos modelos precisam de conexão com a internet e espaço livre suficiente. O Qwen Q8_0 ocupa aproximadamente 805 MB; o tamanho real é informado pelo servidor durante o download.

## Wake phrase

O fluxo `Hey Dev`, `Ok Dev`, `Okay Dev` e `Ei Dev` usa detecção de frase pelo reconhecimento Vosk PT-BR, não um classificador ONNX personalizado. O classificador ONNX de wake word não é fornecido nem treinado neste projeto. O runtime ONNX permanece como dependência para a funcionalidade opcional de importação de classificador.

## Gemini Live

O cliente WebSocket já está no código, mas exige uma API key válida fornecida pelo usuário. A chave é armazenada usando `EncryptedSharedPreferences`/Android Keystore. O uso de Gemini requer internet e pode estar sujeito a disponibilidade/modelos liberados pela API do Google.
