# Reconhecimento de voz — Vosk PT-BR + TTS

## Componentes

| Classe | Função |
|---|---|
| `VoskSpeechRecognizer` | Download/extração do modelo, captura e transcrição |
| `TtsEngine` | Text-to-Speech nativo Android, priorizando pt-BR |
| `VoiceAssistantController` | Orquestra transcrição, provedor de IA, resposta e TTS |

## Modelo

O aplicativo baixa automaticamente `vosk-model-small-pt-0.3` do servidor oficial Vosk, extrai para o armazenamento privado e verifica `am/final.mdl` e `conf/model.conf`. Não é necessário importar ZIP manualmente.

## Fluxo

1. Conceda a permissão de microfone.
2. O app instala o modelo Vosk se estiver ausente.
3. Toque em **Falar agora** para transcrição manual, ou ative a frase de ativação nas configurações.
4. O texto é enviado ao Qwen local ou ao Gemini Live, conforme o provedor selecionado.
5. A resposta é exibida e, se habilitado, falada pelo TTS do Android.

## Observações

- O TTS usa o mecanismo instalado no Android; vozes e dados de idioma são gerenciados pelo sistema.
- O tamanho e a velocidade do download Vosk são informados durante a instalação.
- O reconhecimento depende do modelo small PT-BR e do ruído/qualidade do microfone.
- Não foi executado teste físico de áudio nesta sessão.
