# Ativação por frase — Hey Dev / Ok Dev

## Implementação atual

O fluxo de ativação usa o próprio Vosk PT-BR para transcrever pequenas falas e procura as frases normalizadas:

- “Hey Dev”
- “Ei Dev”
- “Ok Dev”
- “Okay Dev”

Quando uma frase é reconhecida, o controlador inicia a captura do comando. Após a resposta, ele rearma o reconhecimento, inclusive após timeout/silêncio.

## Limitações

- Isso é detecção por transcrição de fala, não um detector acústico dedicado de baixa latência.
- Falsos positivos e falsos negativos dependem do modelo Vosk, sotaque, ruído e duração da fala.
- O classificador ONNX `hey_dev_ai.onnx` não é fornecido nem treinado neste projeto. `WakeWordDetector` é um módulo opcional de importação ONNX e não deve ser apresentado como funcional sem um modelo treinado e validado.
- A escuta em segundo plano só deve funcionar com permissão de microfone e serviço de primeiro plano visível.

## Testes necessários em aparelho

- Repetir cada frase com diferentes distâncias e ruído ambiente.
- Testar frases parecidas para medir disparos indevidos.
- Confirmar que a escuta recomeça após silêncio, comando e fala do TTS.
- Medir consumo de bateria e comportamento do fabricante Android.
