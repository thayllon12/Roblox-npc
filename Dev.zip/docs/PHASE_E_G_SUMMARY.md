# Gemini Live, serviço e configurações

## Gemini Live

- Cliente WebSocket usa endpoint `v1beta`.
- Modelo padrão configurável: `gemini-3.8-live`.
- A API Key é armazenada por `EncryptedSharedPreferences`/Android Keystore.
- A tela de configurações executa teste de handshake e permite editar o ID do modelo.
- O controlador de voz pode enviar a transcrição como turno de texto ao Gemini e usar Qwen como fallback quando habilitado; a resposta textual é falada pelo TTS local.
- O fluxo de conversa de texto não equivale a streaming de áudio bidirecional contínuo.

## Serviço e overlay

- Serviço de primeiro plano com tipo `microphone`, notificação persistente e ação para parar.
- O serviço compartilha a instância do motor local com a Activity, evitando inicialização/liberação duplicada do llama.cpp.
- O serviço aplica as preferências de TTS, velocidade e wake phrase.
- Overlay requer autorização especial do Android.

## Configurações

- Preferências persistidas por DataStore.
- API Key protegida pelo Android Keystore.
- Controles de TTS, wake phrase, modelo Live, provedor, fallback, overlay e serviço.

## Pendências de validação

- Executar build real no GitHub Actions.
- Testar conexão Gemini com uma chave válida e modelo habilitado.
- Testar áudio e microfone em aparelho físico.
- Verificar o ciclo de vida do serviço em Android 14/15+ e em fabricantes com gestão agressiva de bateria.
