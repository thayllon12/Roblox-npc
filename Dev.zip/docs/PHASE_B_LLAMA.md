# Backend local — llama.cpp + Qwen GGUF

## Arquitetura

- `CMakeLists.txt` exige o código real do `llama.cpp`; não existe build silencioso em STUB.
- `scripts/prepare-llama.sh` baixa a revisão fixada e os submódulos necessários.
- `llama_jni.cpp` expõe inicialização, carregamento GGUF, geração, cancelamento e liberação.
- `LocalLlmEngine` gerencia estado, armazenamento privado e inferência fora da thread principal.

## Instalação do modelo

Na primeira inicialização, quando o backend nativo estiver disponível, o app baixa Qwen3 0.6B Q8_0 automaticamente. O arquivo é guardado em `filesDir/models/`, validado pelo cabeçalho GGUF e SHA-256 e não é baixado novamente se o arquivo padrão já estiver presente e válido.

- URL e revisão: Hugging Face `Qwen/Qwen3-0.6B-GGUF`.
- Arquivo: `Qwen3-0.6B-Q8_0.gguf`.
- Tamanho publicado na revisão fixada: aproximadamente 805 MB.
- SHA-256 esperado: `12fae8b8f78f0360b498d04c8db7d33aff29ab7d8080231f93a17c18119e6735`.

## Build

O workflow instala JDK 17, Android SDK 35, NDK 26.1.10909125, CMake 3.22.1 e Gradle 8.9, baixa `llama.cpp` e executa `assembleDebug`. O build falha se o backend nativo não puder ser preparado.

## Limitações ainda não verificadas

- A compilação CMake/NDK e a compatibilidade final do JNI com a revisão fixada precisam ser confirmadas pelo GitHub Actions.
- Inferência, consumo de RAM e desempenho precisam de teste em aparelho arm64 real.
- A geração retorna a resposta completa; não há streaming de tokens para a UI.
