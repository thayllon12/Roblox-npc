extends Node2D
## Endless segment-based world generator for Leon Rush.

@export var segment_width: float = 900.0
@export var spawn_ahead: int = 4
@export var despawn_behind: float = 1400.0
@export var ground_y: float = 420.0

var segments: Array[Node2D] = []
var next_spawn_x: float = -200.0
var player: Node2D = null
var current_biome: String = "jungle"
var difficulty: float = 0.0
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()

func start(player_ref: Node2D) -> void:
	player = player_ref
	next_spawn_x = -200.0
	_clear_segments()
	for i in spawn_ahead + 2:
		_spawn_segment()

func _process(_delta: float) -> void:
	if not player or not GameManager.is_playing():
		return
	# Spawn new segments ahead of the player
	while next_spawn_x < player.global_position.x + segment_width * spawn_ahead:
		_spawn_segment()
	_cleanup_segments()
	# Feed difficulty from GameManager
	difficulty = GameManager.difficulty_level

func _spawn_segment() -> void:
	var segment := _create_segment()
	segment.position.x = next_spawn_x
	add_child(segment)
	segments.append(segment)
	next_spawn_x += segment_width

func _create_segment() -> Node2D:
	var seg := Node2D.new()
	seg.name = "Segment_%d" % int(next_spawn_x)

	# --- Ground visual ---
	var ground_color := _get_biome_ground_color()
	var ground := ColorRect.new()
	ground.color = ground_color
	ground.size = Vector2(segment_width + 40, 200)
	ground.position = Vector2(-20, ground_y)
	seg.add_child(ground)

	# Secondary ground strip (depth)
	var ground2 := ColorRect.new()
	ground2.color = ground_color.darkened(0.15)
	ground2.size = Vector2(segment_width + 40, 80)
	ground2.position = Vector2(-20, ground_y + 40)
	seg.add_child(ground2)

	# --- Physics floor ---
	var body := StaticBody2D.new()
	body.collision_layer = 8  # ground
	body.collision_mask = 0
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(segment_width + 40, 60)
	shape.shape = rect
	shape.position = Vector2(segment_width * 0.5, ground_y + 30)
	body.add_child(shape)
	seg.add_child(body)

	# Decor + gameplay content
	_add_decor(seg)
	_populate_gameplay(seg)

	return seg

func _get_biome_ground_color() -> Color:
	match current_biome:
		"jungle":
			return Color(0.22, 0.48, 0.22)
		"savanna":
			return Color(0.55, 0.48, 0.25)
		"cave":
			return Color(0.28, 0.26, 0.32)
		"volcanic":
			return Color(0.25, 0.15, 0.12)
		"ruins":
			return Color(0.4, 0.38, 0.32)
		_:
			return Color(0.25, 0.5, 0.25)

func _add_decor(seg: Node2D) -> void:
	# Simple background trees / rocks as colored rectangles
	var count := rng.randi_range(2, 5)
	for i in count:
		var decor := ColorRect.new()
		var h := rng.randf_range(40, 110)
		var w := rng.randf_range(18, 40)
		decor.size = Vector2(w, h)
		decor.position = Vector2(rng.randf_range(40, segment_width - 60), ground_y - h)
		match current_biome:
			"jungle":
				decor.color = Color(0.12, 0.35, 0.15, 0.9)
			"savanna":
				decor.color = Color(0.45, 0.35, 0.18, 0.85)
			"cave":
				decor.color = Color(0.35, 0.32, 0.4, 0.9)
			_:
				decor.color = Color(0.2, 0.3, 0.18, 0.8)
		seg.add_child(decor)

func _populate_gameplay(seg: Node2D) -> void:
	var dens: float = clampf(0.45 + difficulty * 0.08, 0.4, 0.85)

	# --- Meat patterns ---
	var pattern := rng.randi_range(0, 5)
	match pattern:
		0: # horizontal line
			for i in 6:
				_spawn_meat(seg, Vector2(120 + i * 75, ground_y - 70), Meat.MeatType.COMMON)
		1: # jump arc
			for i in 6:
				var t := i / 5.0
				var x := 160.0 + i * 70
				var y := ground_y - 70 - sin(t * PI) * 110
				_spawn_meat(seg, Vector2(x, y), Meat.MeatType.COMMON)
		2: # low (slide) line
			for i in 5:
				_spawn_meat(seg, Vector2(150 + i * 80, ground_y - 28), Meat.MeatType.COMMON)
		3: # golden cluster
			_spawn_meat(seg, Vector2(420, ground_y - 90), Meat.MeatType.GOLDEN)
			_spawn_meat(seg, Vector2(460, ground_y - 110), Meat.MeatType.GOLDEN)
			_spawn_meat(seg, Vector2(500, ground_y - 90), Meat.MeatType.COMMON)
		4: # rare high
			_spawn_meat(seg, Vector2(380, ground_y - 160), Meat.MeatType.RARE)
		_:
			# mixed
			for i in 4:
				_spawn_meat(seg, Vector2(180 + i * 90, ground_y - 65 - (i % 2) * 30), Meat.MeatType.COMMON)

	# --- Obstacles ---
	if rng.randf() < dens:
		var obs_x := rng.randf_range(280, segment_width - 180)
		var is_low := rng.randf() < 0.38
		_spawn_obstacle(seg, Vector2(obs_x, ground_y), is_low)

	# Chance of second obstacle on higher difficulty
	if difficulty > 1.5 and rng.randf() < 0.35:
		var obs_x2 := rng.randf_range(500, segment_width - 120)
		_spawn_obstacle(seg, Vector2(obs_x2, ground_y), rng.randf() < 0.5)

	# --- Power-ups (rarer) ---
	if rng.randf() < 0.18 + min(difficulty * 0.02, 0.12):
		var pu_x := rng.randf_range(200, segment_width - 150)
		var pu_y := ground_y - rng.randf_range(80, 150)
		_spawn_powerup(seg, Vector2(pu_x, pu_y))

func _spawn_meat(parent: Node2D, local_pos: Vector2, type: Meat.MeatType) -> void:
	var meat := Area2D.new()
	meat.set_script(load("res://scripts/gameplay/meat.gd"))
	meat.position = local_pos
	meat.meat_type = type
	meat.collision_layer = 4
	meat.collision_mask = 1

	var tex_name := "common"
	match type:
		Meat.MeatType.COMMON: tex_name = "common"
		Meat.MeatType.GOLDEN: tex_name = "golden"
		Meat.MeatType.RARE: tex_name = "rare"
		Meat.MeatType.SPECIAL: tex_name = "special"
		Meat.MeatType.ENERGY: tex_name = "energy"
	var tex_path: String = "res://assets/collectibles/meat_%s.png" % tex_name
	var spr := Sprite2D.new()
	spr.name = "Sprite2D"
	if ResourceLoader.exists(tex_path):
		spr.texture = load(tex_path)
	spr.centered = true
	meat.add_child(spr)

	var col := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 16
	col.shape = circle
	meat.add_child(col)

	var parts := GPUParticles2D.new()
	parts.name = "CollectParticles"
	parts.emitting = false
	parts.amount = 8
	parts.lifetime = 0.35
	meat.add_child(parts)

	parent.add_child(meat)

func _spawn_obstacle(parent: Node2D, local_pos: Vector2, low: bool) -> void:
	var obs := Area2D.new()
	obs.set_script(load("res://scripts/gameplay/obstacle.gd"))
	obs.position = local_pos
	obs.can_slide_under = low
	obs.collision_layer = 2
	obs.collision_mask = 1
	var kind := rng.randi_range(0, 3)
	var tex_names := ["rock", "log", "thorns", "crystal"]
	if low:
		tex_names = ["low_barrier", "log", "thorns", "rock"]

	var col := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	if low:
		rect.size = Vector2(56, 28)
		col.position = Vector2(0, -14)
	else:
		rect.size = Vector2(42, 72)
		col.position = Vector2(0, -36)
	col.shape = rect
	obs.add_child(col)

	var tex_path: String = "res://assets/obstacles/%s.png" % tex_names[kind]
	var spr := Sprite2D.new()
	if ResourceLoader.exists(tex_path):
		spr.texture = load(tex_path)
	spr.centered = true
	spr.position = Vector2(0, col.position.y)
	if not low:
		spr.scale = Vector2(1.3, 1.6)
	else:
		spr.scale = Vector2(1.4, 1.2)
	obs.add_child(spr)
	parent.add_child(obs)

func _spawn_powerup(parent: Node2D, local_pos: Vector2) -> void:
	var pu := Area2D.new()
	pu.set_script(load("res://scripts/gameplay/powerup.gd"))
	pu.position = local_pos
	pu.collision_layer = 16  # powerups layer (optional)
	pu.collision_mask = 1

	# Random type (shield and magnet a bit more common)
	var roll := rng.randf()
	if roll < 0.22:
		pu.powerup_type = PowerUp.PowerUpType.SHIELD
	elif roll < 0.40:
		pu.powerup_type = PowerUp.PowerUpType.MEAT_MAGNET
	elif roll < 0.55:
		pu.powerup_type = PowerUp.PowerUpType.SPEED_BOOST
	elif roll < 0.70:
		pu.powerup_type = PowerUp.PowerUpType.MEAT_MULTIPLIER
	elif roll < 0.85:
		pu.powerup_type = PowerUp.PowerUpType.MEGA_JUMP
	else:
		pu.powerup_type = PowerUp.PowerUpType.INVINCIBILITY

	var type_str: String = PowerUp.type_to_string(pu.powerup_type)
	var tex_path: String = "res://assets/powerups/%s.png" % type_str
	var spr := Sprite2D.new()
	spr.name = "Visual"
	if ResourceLoader.exists(tex_path):
		spr.texture = load(tex_path)
	spr.centered = true
	spr.scale = Vector2(1.4, 1.4)
	pu.add_child(spr)

	var col := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 18
	col.shape = circle
	pu.add_child(col)

	parent.add_child(pu)

func _cleanup_segments() -> void:
	if not player:
		return
	var to_remove: Array[Node2D] = []
	for seg in segments:
		if is_instance_valid(seg) and seg.global_position.x + segment_width < player.global_position.x - despawn_behind:
			to_remove.append(seg)
	for seg in to_remove:
		segments.erase(seg)
		seg.queue_free()

func _clear_segments() -> void:
	for seg in segments:
		if is_instance_valid(seg):
			seg.queue_free()
	segments.clear()

func set_difficulty(value: float) -> void:
	difficulty = value

func change_biome(biome: String) -> void:
	if biome == current_biome:
		return
	current_biome = biome
	EventBus.biome_changed.emit(biome)
