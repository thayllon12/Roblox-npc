# LEON RUSH

Endless runner 2D mobile game starring **Leon**, an original cartoon lion.

Run through wild biomes, jump, slide, collect meat, grab power-ups, unlock skins and beat your records.

---

## Features

- Automatic running with swipe controls (jump / slide)
- Collectible meat (common, golden, rare…)
- 6 power-ups: Magnet, Shield, Speed Boost, Multiplier, Invincibility, Mega Jump
- 5 biomes with seamless transitions (Jungle, Savanna, Cave, Volcanic, Ruins)
- Progressive difficulty
- Shop with unlockable skins (paid with meat)
- Missions with rewards
- Local save (records, meat, skins, settings, missions)
- Main Menu · Shop · Missions · Settings · Pause · Game Over
- Android APK export pipeline via GitHub Actions (Godot 4.3 + Android SDK + export templates)

---

## Tech

| Item | Value |
|------|--------|
| Engine | Godot **4.3+** |
| Language | GDScript (typed) |
| Target | Android (landscape) |
| Package | `com.leonrush.game` |
| Renderer | Mobile / Compatibility |

---

## How to open

1. Install [Godot 4.3+](https://godotengine.org/download)
2. Open the folder `LEON-RUSH`
3. Press **F5** (main scene = Main Menu)

### Desktop controls

| Key | Action |
|-----|--------|
| Space / W | Jump |
| S / Down | Slide |
| E | Special (reserved) |
| Esc | Pause |

### Mobile

- Swipe **up** → Jump  
- Swipe **down** → Slide  

---

## Project structure

```
LEON-RUSH/
├── project.godot
├── README.md
├── ASSET_LICENSES.md
├── CHANGELOG.md
├── assets/
├── scenes/          # main, player, ui, world…
├── scripts/         # core, player, gameplay, procedural, progression, save, audio, ui
├── resources/
└── .github/workflows/android-build.yml
```

---

## Android / GitHub Actions

Workflow: `.github/workflows/android-build.yml`

- Triggers on push to `main` / `master` or manual dispatch
- Installs Java 17 and Android SDK packages
- Downloads Godot 4.3 and matching Android export templates
- Imports the project and validates GDScript before exporting
- Creates a temporary Android debug keystore for CI builds
- Exports `build/LeonRush.apk` and uploads it as `leon-rush-android-apk`

To build: push the project to a GitHub repository, open **Actions → Build Android APK**, and download the artifact from a successful run. The CI debug keystore is temporary; use a private release keystore stored in GitHub Secrets before publishing a production release.

### Local export (Godot editor)

1. Install the Android export templates matching your Godot version.
2. Install Android SDK and configure it in Editor Settings → Export → Android.
3. Create an Android preset with package `com.leonrush.game`.
4. Configure a signing keystore.
5. Export APK / AAB.

---

## Adding content

- **New obstacle**: extend `scripts/gameplay/obstacle.gd` or spawn variants in `world_generator.gd`
- **New biome**: add name to `biome_manager.gd` thresholds + colors, handle in `world_generator.change_biome`
- **New skin**: append entry in `scripts/progression/shop_data.gd` `SKINS` array
- **New mission**: append to `MISSION_DEFS` in `mission_manager.gd`

Always document third-party assets in `ASSET_LICENSES.md` (CC0 preferred).

---

## Status

**v1.0.0 — Feature-complete playable build**

All core systems from the production spec are implemented and connected:

Gameplay loop · Power-ups · Biomes · Shop · Missions · Settings · Save · UI flow · Android workflow

Art and audio are still **placeholders** (colored shapes / procedural). Replace with CC0 or original assets without changing architecture.

---

## License

Original code and design for LEON RUSH: MIT (or as noted per file).  
Third-party assets: see `ASSET_LICENSES.md`.
